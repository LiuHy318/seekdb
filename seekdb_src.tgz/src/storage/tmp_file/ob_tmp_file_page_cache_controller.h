/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_TMP_FILE_OB_TMP_FILE_PAGE_CACHE_CONTROLLER_H_
#define OCEANBASE_STORAGE_TMP_FILE_OB_TMP_FILE_PAGE_CACHE_CONTROLLER_H_

#include "storage/tmp_file/ob_tmp_file_thread_wrapper.h"
#include "storage/tmp_file/ob_tmp_file_flush_manager.h"

namespace oceanbase
{
namespace tmp_file
{
class ObTmpFilePageCacheController
{
public:
  ObTmpFilePageCacheController(ObTmpFileBlockManager &tmp_file_block_manager)
    : is_inited_(false),
      flush_all_data_(false),
      disk_usage_limit_(0),
      tmp_file_block_manager_(tmp_file_block_manager),
      task_allocator_(),
      write_buffer_pool_(),
      flush_priority_mgr_(),
      evict_mgr_(),
      flush_mgr_(*this),
      flush_thread_(write_buffer_pool_, flush_mgr_, task_allocator_, tmp_file_block_manager_),
      swap_thread_(write_buffer_pool_, evict_mgr_, flush_thread_, *this)
  {
  }
  ~ObTmpFilePageCacheController() {}
public:
  static const int64_t FLUSH_FAST_INTERVAL = 5;     // 5ms
  static const int64_t FLUSH_INTERVAL = 1000;       // 1s
  static const int64_t SWAP_FAST_INTERVAL = 5;      // 5ms
  static const int64_t SWAP_INTERVAL = 1000;        // 1s
  static const int64_t REFRESH_CONFIG_INTERVAL = 10 * 1000 * 1000;  // 10s
  virtual int init();
  int start();
  void stop();
  void wait();
  void destroy();
  ObIAllocator &get_task_allocator() { return task_allocator_; }
  ObTmpWriteBufferPool &get_write_buffer_pool() { return write_buffer_pool_; }
  ObTmpFileFlushManager &get_flush_task_mgr() { return flush_mgr_; }
  ObTmpFileEvictionManager &get_eviction_manager() { return evict_mgr_; }
  ObTmpFileFlushPriorityManager &get_flush_priority_mgr() { return flush_priority_mgr_; }
  ObTmpFileBlockManager &get_tmp_file_block_manager() { return tmp_file_block_manager_; }
  OB_INLINE bool is_flush_all_data() { return ATOMIC_LOAD(&flush_all_data_); }
  OB_INLINE void set_flush_all_data(bool flush_all_data) { ATOMIC_STORE(&flush_all_data_, flush_all_data); }
  OB_INLINE int64_t get_disk_usage_limit() const { return ATOMIC_LOAD(&disk_usage_limit_); }
  virtual int invoke_swap_and_wait(int64_t expect_swap_size, int64_t timeout_ms = ObTmpFileSwapJob::DEFAULT_TIMEOUT_MS);
  void refresh_disk_usage_limit();
private:
  int swap_job_enqueue_(ObTmpFileSwapJob *swap_job);
  int free_swap_job_(ObTmpFileSwapJob *swap_job);
  DISALLOW_COPY_AND_ASSIGN(ObTmpFilePageCacheController);
private:
  bool is_inited_;
  bool flush_all_data_;                   // set to true to flush all pages when shrinking write buffer pool
  int64_t disk_usage_limit_;              // Periodically refreshed from runtime configuration.
  ObTmpFileBlockManager &tmp_file_block_manager_;    // ref to ObTmpFileBlockManager
  ObFIFOAllocator task_allocator_;        // used by flush_mgr_ to allocate flush tasks
  ObTmpWriteBufferPool write_buffer_pool_;
  ObTmpFileFlushPriorityManager flush_priority_mgr_;
  ObTmpFileEvictionManager evict_mgr_;    // maintain evict lists and evict pages from write buffer pool
  ObTmpFileFlushManager flush_mgr_;       // maintain flush lists and generate flush tasks
  ObTmpFileFlushThread flush_thread_;             // flush thread
  ObTmpFileSwapThread swap_thread_;               // swap thread
};

}  // end namespace tmp_file
}  // end namespace oceanbase
#endif // OCEANBASE_STORAGE_TMP_FILE_OB_TMP_FILE_PAGE_CACHE_CONTROLLER_H_
