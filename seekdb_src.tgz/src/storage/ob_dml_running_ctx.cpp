/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define USING_LOG_PREFIX STORAGE

#include "storage/ob_dml_running_ctx.h"
#include "storage/ob_table_dml_param.h"
#include "storage/tablet/ob_tablet.h"
#include "storage/memtable/ob_memtable_context.h"
#include "storage/tx/ob_tx_ctx.h"

namespace oceanbase
{
using namespace common;
using namespace share;
using namespace blocksstable;
namespace storage
{
ObDMLRunningCtx::ObDMLRunningCtx(
    ObStoreCtx &store_ctx,
    const ObDMLBaseParam &dml_param,
    common::ObIAllocator &allocator,
    const blocksstable::ObDmlFlag dml_flag,
    const bool is_need_check_old_row)
  : store_ctx_(store_ctx),
    dml_param_(dml_param),
    allocator_(allocator),
    dml_flag_(dml_flag),
    relative_table_(),
    col_map_(nullptr),
    col_descs_(nullptr),
    column_ids_(nullptr),
    datum_row_(),
    cmp_funcs_(),
    is_need_check_old_row_(is_need_check_old_row),
    is_udf_(false),
    has_lob_rowkey_(false),
    lob_dml_ctx_(),
    main_table_rowkey_col_flag_(allocator),
    schema_guard_(share::schema::ObSchemaMgrItem::MOD_RELATIVE_TABLE),
    is_inited_(false)
{
}

ObDMLRunningCtx::~ObDMLRunningCtx()
{
  main_table_rowkey_col_flag_.reset();
}

int ObDMLRunningCtx::init(
    const common::ObIArray<uint64_t> *column_ids,
    const common::ObIArray<uint64_t> *upd_col_ids,
    ObMultiVersionSchemaService *schema_service,
    ObTabletHandle &tablet_handle)
{
  int ret = OB_SUCCESS;

  if (IS_INIT) {
    ret = OB_INIT_TWICE;
    LOG_WARN("init twice", K(ret));
  } else if (OB_UNLIKELY(!store_ctx_.is_valid())
      || OB_UNLIKELY(!dml_param_.is_valid())
      || OB_ISNULL(dml_param_.table_param_)
      || OB_ISNULL(schema_service)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid argument", K(ret), K(store_ctx_),
        K(dml_param_), KP(schema_service));
  } else {

    const uint64_t table_id = dml_param_.table_param_->get_data_table().get_table_id();
    const int64_t version = dml_param_.schema_version_;
    const int64_t runtime_schema_version = dml_param_.runtime_schema_version_;
    if (dml_param_.check_schema_version_ && OB_FAIL(check_schema_version(*schema_service, table_id,
        runtime_schema_version, version, tablet_handle))) {
      LOG_WARN("failed to check schema version", K(ret), K(runtime_schema_version), K(table_id), K(version));
    }
  }

  if (OB_FAIL(ret)) {
    // do nothing
  } else if (OB_FAIL(prepare_relative_table(
      dml_param_.table_param_->get_data_table(),
      tablet_handle,
      store_ctx_.mvcc_acc_ctx_.get_snapshot_version()))) {
  } else if (NULL != column_ids && OB_FAIL(prepare_column_info(*column_ids))) {
    LOG_WARN("fail to get column descriptions and column map", K(ret), K(*column_ids));
  } else if (is_need_check_old_row_ && OB_FAIL(check_need_old_row_legitimacy())) {
    LOG_WARN("fail to get flag of checking old row legitimacy", K(ret));
  } else if (is_need_check_old_row_ && OB_FAIL(init_cmp_funcs())) {
    LOG_WARN("fail to init compare functions", K(ret));
  } else {
    store_ctx_.mvcc_acc_ctx_.mem_ctx_->set_table_version(dml_param_.schema_version_);
    store_ctx_.table_version_ = dml_param_.schema_version_;
    column_ids_ = column_ids;
    // Propagate async-index flag to the transaction context so that the log block header
    // carries HAS_ASYNC_INDEX, enabling Change Stream Fetcher fast filtering.
    if (OB_UNLIKELY(dml_param_.has_async_index_)) {
      transaction::ObTxCtx *tx_ctx = store_ctx_.mvcc_acc_ctx_.mem_ctx_->get_trans_ctx();
      if (OB_NOT_NULL(tx_ctx)) {
        tx_ctx->set_has_async_index_redo();
      }
    }
    is_inited_ = true;
  }

  if (IS_NOT_INIT) {
    relative_table_.destroy();
  }
  return ret;
}


int ObDMLRunningCtx::prepare_relative_table(
    const share::schema::ObTableSchemaParam &schema,
    ObTabletHandle &tablet_handle,
    const SCN &read_snapshot)
{
  int ret = OB_SUCCESS;
  if (OB_FAIL(relative_table_.init(&schema, tablet_handle.get_obj()->get_tablet_meta().tablet_id_,
      schema.is_storage_index_table() && !schema.can_read_index()))) {
  } else if (OB_FAIL(relative_table_.tablet_iter_.set_tablet_handle(tablet_handle))) {
  } else if (OB_FAIL(relative_table_.tablet_iter_.refresh_read_tables_from_tablet(
      read_snapshot.get_val_for_tx(), 
      relative_table_.allow_not_ready(), 
      false/*major_sstable_only*/))) {
  } else if (schema.get_read_info().need_truncate_filter() &&
      OB_FAIL(relative_table_.prepare_truncate_part_filter(allocator_, read_snapshot.get_val_for_tx()))) {
    LOG_WARN("failed to prepare truncate part filter", K(ret));
  }
  return ret;
}

int ObDMLRunningCtx::prepare_column_info(const common::ObIArray<uint64_t> &column_ids)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(column_ids.count() <= 0)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid argument", K(column_ids), K(relative_table_));
  } else {
    col_descs_ = &(dml_param_.table_param_->get_col_descs());
    if (col_descs_->count() <= 0) {
      ret = OB_ERR_UNEXPECTED;
      LOG_WARN("col desc is empty", K(ret));
    } else if (ObDmlFlag::DF_UPDATE == dml_flag_) {
      col_map_ = &(dml_param_.table_param_->get_col_map());
    }
    if (OB_SUCC(ret)) {
      for (int64_t i = 0; OB_SUCC(ret) && i < relative_table_.get_rowkey_column_num(); ++i) {
        if (col_descs_->at(i).col_type_.is_lob_storage()) {
          has_lob_rowkey_ = true;
          break;
        }
      }
      if (relative_table_.is_index_table()) {
        if (OB_FAIL(main_table_rowkey_col_flag_.init(col_descs_->count()))) {
        }
        for (int64_t i = 0; OB_SUCC(ret) && i < col_descs_->count(); ++i) {
          bool is_main_table_rowkey_col = false;
          const ObColumnParam *column = dml_param_.table_param_->get_data_table().get_column(col_descs_->at(i).col_id_);
          if (OB_ISNULL(column)) {
            ret = OB_ERR_UNEXPECTED;
            LOG_WARN("column is null", K(ret), K(i), KP(column), K(col_descs_->at(i)));  
          } else if (OB_FAIL(main_table_rowkey_col_flag_.push_back(column->is_data_table_rowkey()))) {
          }
        }
      }
    }
  }
  return ret;
}

int ObDMLRunningCtx::check_need_old_row_legitimacy()
{
  int ret = OB_SUCCESS;
  is_need_check_old_row_ = false;

  if (OB_FAIL(relative_table_.has_udf_column(is_need_check_old_row_))) {
  } else if (is_need_check_old_row_) {
    is_udf_ = true;
  } else if (GCONF.enable_defensive_check()) {
    is_need_check_old_row_ = true;
    if ((relative_table_.is_index_table() && !relative_table_.can_read_index())
        || dml_param_.is_main_table_in_fts_ddl_ ) {
      // We should not check old row because domain row may be generated instead of scanned
      // from domain table when:
      // 1) index can not be read during building index
      // 2) or schema shows index ready, but fts ddl is on going when dml start snapshot
      is_need_check_old_row_ = false;
    }
    if (ObDmlFlag::DF_LOCK == dml_flag_) {
      is_need_check_old_row_ = false;
    }
  }
  return ret;
}

int ObDMLRunningCtx::init_cmp_funcs()
{
  int ret = OB_SUCCESS; 
  const common::ObIArray<share::schema::ObColDesc> &col_descs = dml_param_.table_param_->get_col_descs();
  int64_t column_cnt = col_descs.count();
  if (OB_UNLIKELY(column_cnt < 0 || column_cnt > OB_ROW_MAX_COLUMNS_COUNT)) {
    ret = OB_INVALID_ARGUMENT;
    STORAGE_LOG(WARN, "Invalid argument to init compare functions", K(ret), K(column_cnt), K(col_descs));
  } else if (OB_FAIL(cmp_funcs_.init(column_cnt, allocator_))) {
  } else {
    ObCmpFunc cmp_func;
    for (int64_t i = 0; OB_SUCC(ret) && i < col_descs.count(); i++) {
      const share::schema::ObColDesc &col_desc = col_descs.at(i);
      //TODO @hanhui support desc rowkey
      bool is_ascending = true || col_desc.col_order_ == ObOrderType::ASC;
      bool has_lob_header = is_lob_storage(col_desc.col_type_.get_type());
      ObPrecision precision = PRECISION_UNKNOWN_YET;
      if (col_desc.col_type_.is_decimal_int()) {
        precision = col_desc.col_type_.get_stored_precision();
        OB_ASSERT(precision != PRECISION_UNKNOWN_YET);
      }
      common::ObDatumBasicFuncs *basic_funcs = ObDatumFuncs::get_basic_func(col_desc.col_type_.get_type(),
                                                                        col_desc.col_type_.get_collation_type(),
                                                                        col_desc.col_type_.get_scale(),
                                                                        has_lob_header,
                                                                        precision);
      if (OB_UNLIKELY(nullptr == basic_funcs || nullptr == basic_funcs->null_last_cmp_)) {
        ret = OB_ERR_SYS;
        STORAGE_LOG(ERROR, "Unexpected null basic funcs", K(ret), K(col_desc));
      } else {
        if (is_ascending) {
          cmp_func.cmp_func_ = basic_funcs->null_first_cmp_;
          if (OB_FAIL(cmp_funcs_.push_back(ObStorageDatumCmpFunc(cmp_func)))) {
          }
        } else {
          ret = OB_ERR_SYS;
          STORAGE_LOG(WARN, "Unsupported desc column order", K(ret), K(col_desc), K(i));
        }
      }
    }
  }
  return ret;
}

int ObDMLRunningCtx::check_schema_version(
    share::schema::ObMultiVersionSchemaService &schema_service,
    const uint64_t table_id,
    const int64_t runtime_schema_version,
    const int64_t table_version,
    ObTabletHandle &tablet_handle)
{
  int ret = OB_SUCCESS;
  const ObTableSchema *table_schema = nullptr;
  bool check_formal = !is_inner_table(table_id);
  int tmp_ret = check_runtime_schema_version(schema_service, table_id, runtime_schema_version);
  if (OB_SUCCESS == tmp_ret) {
    // The runtime-wide check passed, so no table-level schema check is needed.
  } else if (OB_FAIL(schema_service.get_runtime_schema_guard(schema_guard_))) {
  } else if (check_formal && OB_FAIL(schema_guard_.check_formal_guard())) {
    LOG_WARN("schema_guard is not formal", K(ret));
  } else if (OB_FAIL(schema_guard_.get_table_schema( table_id, table_schema))) {
  } else if (OB_ISNULL(table_schema)) {
    ret = OB_SCHEMA_ERROR;
    LOG_WARN("failed to get schema", K(ret));
  } else if (table_version != table_schema->get_schema_version()) {
    ret = OB_SCHEMA_EAGAIN;
    LOG_WARN("table version mismatch", K(ret), K(table_id), K(table_version), K(table_schema->get_schema_version()));
  }
  if (OB_SUCC(ret)) {
    if (OB_FAIL(tablet_handle.get_obj()->check_schema_version_with_cache(table_version))) {
    }
  }
  return ret;
}

int ObDMLRunningCtx::check_runtime_schema_version(
    share::schema::ObMultiVersionSchemaService &schema_service,
    const uint64_t table_id,
    const int64_t runtime_schema_version)
{
  int ret = OB_SUCCESS;
  int64_t latest_runtime_schema_version = -1;
  if (is_inner_table(table_id)) {
    //inner table can't skip table schema check
    ret = OB_SCHEMA_EAGAIN;
  } else if (runtime_schema_version > 0
             && OB_FAIL(schema_service.get_runtime_refreshed_schema_version(latest_runtime_schema_version))) {
    LOG_WARN("failed to get refreshed runtime schema version", K(ret), K(runtime_schema_version));
  } else if (runtime_schema_version < 0 || latest_runtime_schema_version < 0) {
    ret = OB_SCHEMA_EAGAIN;
  } else if (!share::schema::ObSchemaService::is_formal_version(latest_runtime_schema_version)) {
    ret = OB_SCHEMA_EAGAIN;
    LOG_INFO("local schema_version is not formal, try again", K(ret),
             K(runtime_schema_version), K(latest_runtime_schema_version));
  } else if (latest_runtime_schema_version > 0
             && runtime_schema_version == latest_runtime_schema_version) {
    // no schema change, do nothing
    ret = OB_SUCCESS;
  } else {
    ret = OB_SCHEMA_EAGAIN;
    LOG_INFO("need check table schema version", K(ret),
             K(runtime_schema_version), K(latest_runtime_schema_version));
  }
  return ret;
}
} // namespace storage
} // namespace oceanbase
