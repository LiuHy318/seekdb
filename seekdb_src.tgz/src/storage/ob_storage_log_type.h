/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_STORAGE_LOG_TYPE_
#define OCEANBASE_STORAGE_OB_STORAGE_LOG_TYPE_

#include <stdint.h>

namespace oceanbase
{
namespace storage
{
enum ObStorageLogType
{
  //attention:!!!
  //you should modify storage_log_type_to_string() below at the same when adding new log type
  // If you add a new log type, also update external log consumers such as liboblog.
  //OB as supporting support
  OB_LOG_UNKNOWN = 0,

  OB_LOG_TRANS_REDO = 0x1,
  OB_LOG_TRANS_PREPARE = 0x2,
  OB_LOG_TRANS_REDO_WITH_PREPARE = 0x3,
  OB_LOG_TRANS_COMMIT = 0x4,
  OB_LOG_TRANS_PREPARE_WITH_COMMIT = 0x6,
  OB_LOG_TRANS_REDO_WITH_PREPARE_WITH_COMMIT = 0x7,
  OB_LOG_TRANS_ABORT = 0x8,
  OB_LOG_TRANS_CLEAR = 0x10,
  OB_LOG_TRANS_PREPARE_WITH_COMMIT_WITH_CLEAR = 0x16,
  OB_LOG_TRANS_REDO_WITH_PREPARE_WITH_COMMIT_WITH_CLEAR = 0x17,
  OB_LOG_SP_TRANS_REDO = 0x20,
  OB_LOG_SP_TRANS_COMMIT = 0x40,
  OB_LOG_SP_TRANS_ABORT = 0x80,
 
  OB_LOG_SP_ELR_TRANS_COMMIT = 0x100,

  //for OB_START_MEMBERSHIP
  OB_LOG_START_MEMBERSHIP_STORAGE = 0x148,

  OB_LOG_MUTATOR = 0x200,
  OB_LOG_TRANS_STATE = 0x400,
  OB_LOG_MUTATOR_WITH_STATE = 0x600,
  OB_LOG_MUTATOR_ABORT = 0x800,
  OB_LOG_TRANS_PRE_COMMIT = 0x1000,
  OB_LOG_TRANS_RECORD = 0x2000,

  OB_LOG_TRANS_AGGRE = 9999,
  OB_LOG_TRANS_MAX = 10000,

  OB_LOG_FREEZE_PREPARE = 10001,
  OB_LOG_FREEZE_COMMIT = 10002,
  OB_LOG_FREEZE_ABORT = 10003,
  OB_LOG_MINOR_FREEZE = 10004,
  OB_LOG_MAJOR_FREEZE = 10005,

  OB_LOG_STORAGE_SCHEMA = 11005,

  OB_LOG_TRANS_CHECKPOINT = 12000,

  // do offline log
  OB_LOG_OFFLINE_PARTITION = 20001,
  OB_LOG_OFFLINE_PARTITION_V2= 20002,// added since 2.2.6
  // for test
  OB_LOG_TEST = 30000,

  OB_LOG_ADD_PARTITION_TO_PG = 40007,
  OB_LOG_REMOVE_PARTITION_FROM_PG = 40008,
  OB_PARTITION_SCHEMA_VERSION_CHANGE_LOG = 40009,

  OB_LOG_DDL_REDO_LOG = 60001,
  OB_LOG_DDL_COMMIT_LOG = 60002,
};

class ObStorageLogTypeToString
{
public:
  static const char *storage_log_type_to_string(const int64_t log_type) {
    const char *log_type_str = nullptr;
    switch (log_type) {
      case storage::OB_LOG_UNKNOWN:
        log_type_str = "UNKNOWN";
        break;
      case OB_LOG_TRANS_REDO:
        log_type_str = "TRANS_REDO";
        break;
      case OB_LOG_TRANS_PREPARE:
        log_type_str = "TRANS_PREPARE";
        break;
      case OB_LOG_TRANS_REDO_WITH_PREPARE:
        log_type_str = "TRANS_REDO_WITH_PREPARE";
        break;
      case OB_LOG_TRANS_COMMIT:
        log_type_str = "TRANS_COMMIT";
        break;
      case OB_LOG_TRANS_PREPARE_WITH_COMMIT:
        log_type_str = "TRANS_PREPARE_WITH_COMMIT";
        break;
      case OB_LOG_TRANS_REDO_WITH_PREPARE_WITH_COMMIT:
        log_type_str = "TRANS_REDO_WITH_PREPARE_WITH_COMMIT";
        break;
      case OB_LOG_TRANS_ABORT:
        log_type_str = "TRANS_ABORT";
        break;
      case OB_LOG_TRANS_CLEAR:
        log_type_str = "TRANS_CLEAR";
        break;
      case OB_LOG_TRANS_PREPARE_WITH_COMMIT_WITH_CLEAR:
        log_type_str = "TRANS_PREPARE_WITH_COMMIT_WITH_CLEAR";
        break;
      case OB_LOG_TRANS_REDO_WITH_PREPARE_WITH_COMMIT_WITH_CLEAR:
        log_type_str = "TRANS_REDO_WITH_PREPARE_WITH_COMMIT_WITH_CLEAR";
        break;
      case OB_LOG_SP_TRANS_REDO:
        log_type_str = "SP_TRANS_REDO";
        break;
      case OB_LOG_SP_TRANS_COMMIT:
        log_type_str = "SP_TRANS_COMMIT";
        break;
      case OB_LOG_SP_TRANS_ABORT:
        log_type_str = "SP_TRANS_ABORT";
        break;
      case OB_LOG_SP_ELR_TRANS_COMMIT:
        log_type_str = "SP_ELR_TRANS_COMMIT";
        break;
      case OB_LOG_START_MEMBERSHIP_STORAGE:
        log_type_str = "START_MEMBERSHIP_STORAGE";
        break;
      case OB_LOG_MUTATOR:
        log_type_str = "MUTATOR";
        break;
      case OB_LOG_TRANS_STATE:
        log_type_str = "TRANS_STATE";
        break;
      case OB_LOG_MUTATOR_WITH_STATE:
        log_type_str = "MUTATOR_WITH_STATE";
        break;
      case OB_LOG_MUTATOR_ABORT:
        log_type_str = "MUTATOR_ABORT";
        break;
      case OB_LOG_TRANS_PRE_COMMIT:
        log_type_str = "TRANS_PRE_COMMIT";
        break;
      case OB_LOG_TRANS_AGGRE:
        log_type_str = "OB_LOG_TRANS_AGGRE";
        break;
      case OB_LOG_TRANS_MAX:
        log_type_str = "TRANS_MAX";
        break;
      case OB_LOG_FREEZE_PREPARE:
        log_type_str = "FREEZE_PREPARE";
        break;
      case OB_LOG_FREEZE_COMMIT:
        log_type_str = "FREEZE_COMMIT";
        break;
      case OB_LOG_FREEZE_ABORT:
        log_type_str = "FREEZE_ABORT";
        break;
      case OB_LOG_MINOR_FREEZE:
        log_type_str = "LOG_MINOR_FREEZE";
        break;
      case OB_LOG_MAJOR_FREEZE:
        log_type_str = "MAJOR_FREEZE";
        break;
      case OB_LOG_STORAGE_SCHEMA:
        log_type_str = "OB_LOG_STORAGE_SCHEMA";
        break;
      case OB_LOG_TRANS_CHECKPOINT:
        log_type_str = "TRANS_CHECKPOINT";
        break;
      case OB_LOG_OFFLINE_PARTITION:
        log_type_str = "OFFLINE_PARTITION";
        break;
      case OB_LOG_OFFLINE_PARTITION_V2:
        log_type_str = "OFFLINE_PARTITION_V2";
        break;
      case OB_LOG_TEST:
        log_type_str = "TEST";
        break;
      case OB_LOG_ADD_PARTITION_TO_PG:
        log_type_str = "ADD_PARTITION_TO_PG";
        break;
      case OB_LOG_REMOVE_PARTITION_FROM_PG:
        log_type_str = "REMOVE_PARTITION_FROM_PG";
        break;
      case OB_PARTITION_SCHEMA_VERSION_CHANGE_LOG:
        log_type_str = "OB_PARTITION_SCHEMA_VERSION_CHANGE_LOG";
        break;
      case OB_LOG_DDL_REDO_LOG:
        log_type_str = "OB_LOG_DDL_REDO_LOG";
        break;
      case OB_LOG_DDL_COMMIT_LOG:
        log_type_str = "OB_LOG_DDL_COMMIT_LOG";
        break;
      case OB_LOG_TRANS_RECORD:
        log_type_str = "TRANS_RECORD";
        break;
      default:
        log_type_str = "INVALID_LOG_TYPE";
        break;
    }
    return log_type_str;
  }
};
class ObStorageLogTypeChecker
{
public:
  static bool is_trans_log(const int64_t log_type)
  {
  return (OB_LOG_TRANS_REDO == log_type ||
          OB_LOG_TRANS_PREPARE == log_type ||
          OB_LOG_TRANS_REDO_WITH_PREPARE == log_type ||
          OB_LOG_TRANS_COMMIT == log_type ||
          OB_LOG_TRANS_PREPARE_WITH_COMMIT == log_type ||
          OB_LOG_TRANS_REDO_WITH_PREPARE_WITH_COMMIT == log_type ||
          OB_LOG_TRANS_PREPARE_WITH_COMMIT_WITH_CLEAR == log_type ||
          OB_LOG_TRANS_REDO_WITH_PREPARE_WITH_COMMIT_WITH_CLEAR == log_type ||
          OB_LOG_TRANS_ABORT == log_type ||
          OB_LOG_TRANS_CLEAR == log_type ||
          OB_LOG_SP_TRANS_REDO == log_type ||
          OB_LOG_SP_TRANS_COMMIT == log_type ||
          OB_LOG_SP_ELR_TRANS_COMMIT == log_type ||
          OB_LOG_SP_TRANS_ABORT == log_type ||
          OB_LOG_TRANS_STATE == log_type ||
          OB_LOG_MUTATOR == log_type ||
          OB_LOG_MUTATOR_WITH_STATE == log_type ||
          OB_LOG_MUTATOR_ABORT == log_type ||
          OB_LOG_TRANS_AGGRE == log_type ||
          OB_LOG_TRANS_RECORD == log_type);
  }
  static bool is_trans_abort_log(const int64_t log_type)
  {
    return OB_LOG_TRANS_ABORT == log_type
      || OB_LOG_SP_TRANS_ABORT == log_type
      || OB_LOG_MUTATOR_ABORT == log_type;
  }
  static bool is_trans_commit_log(const int64_t log_type)
  {
    return OB_LOG_TRANS_COMMIT == log_type
      || OB_LOG_SP_TRANS_COMMIT == log_type;
  }
  static bool is_trans_redo_log(const int64_t log_type)
  {
    return OB_LOG_TRANS_REDO == log_type
      || OB_LOG_SP_TRANS_REDO == log_type;
  }
  static bool has_trans_mutator(const int64_t log_type)
  {
    return OB_LOG_TRANS_REDO == log_type ||
      OB_LOG_TRANS_REDO_WITH_PREPARE == log_type ||
      OB_LOG_TRANS_REDO_WITH_PREPARE_WITH_COMMIT == log_type ||
      OB_LOG_TRANS_REDO_WITH_PREPARE_WITH_COMMIT_WITH_CLEAR == log_type ||
      OB_LOG_SP_TRANS_REDO == log_type ||
      OB_LOG_SP_TRANS_COMMIT == log_type ||
      OB_LOG_SP_ELR_TRANS_COMMIT == log_type ||
      OB_LOG_MUTATOR == log_type ||
      OB_LOG_MUTATOR_WITH_STATE == log_type;
  }
  static bool is_freeze_log(const int64_t log_type)
  {
    return (OB_LOG_MAJOR_FREEZE == log_type
        || OB_LOG_FREEZE_PREPARE == log_type
        || OB_LOG_FREEZE_COMMIT == log_type
        || OB_LOG_FREEZE_ABORT == log_type
        || OB_LOG_MINOR_FREEZE == log_type);
  }
  static bool is_test_log(const int64_t log_type)
  {
    return OB_LOG_TEST == log_type;
  }
  static bool is_offline_partition_log(const int64_t log_type)
  {
    return (OB_LOG_OFFLINE_PARTITION == log_type || OB_LOG_OFFLINE_PARTITION_V2 == log_type);
  }
  static bool is_offline_partition_log_old(const int64_t log_type)
  {
    return OB_LOG_OFFLINE_PARTITION == log_type;
  }
  static bool is_offline_partition_log_new(const int64_t log_type)
  {
    return OB_LOG_OFFLINE_PARTITION_V2 == log_type;
  }
  static bool is_checkpoint_log(const int64_t log_type)
  {
    return (OB_LOG_TRANS_CHECKPOINT == log_type);
  }

  static bool is_start_membership_log(const int64_t log_type)
  {
    return (OB_LOG_START_MEMBERSHIP_STORAGE == log_type);
  }

  static bool is_add_partition_to_pg_log(const int64_t log_type)
  {
    return (OB_LOG_ADD_PARTITION_TO_PG == log_type);
  }

  static bool is_ddl_log(const int64_t log_type)
  {
    return (OB_LOG_DDL_REDO_LOG == log_type || OB_LOG_DDL_COMMIT_LOG == log_type);
  }

  static bool is_remove_partition_from_pg_log(const int64_t log_type)
  {
    return (OB_LOG_REMOVE_PARTITION_FROM_PG == log_type);
  }

  static bool is_schema_version_change_log(const int64_t log_type)
  {
    return (OB_PARTITION_SCHEMA_VERSION_CHANGE_LOG == log_type);
  }

  static bool is_partition_meta_log(const int64_t log_type)
  {
    return (OB_LOG_STORAGE_SCHEMA == log_type);
  }

  static bool is_log_replica_need_replay_log(const int64_t log_type) 
  {
    // L replica only replay offline partition log
    return is_offline_partition_log(log_type);
  }
  static bool is_pre_barrier_required_log(const int64_t log_type)
  {

    return (OB_LOG_START_MEMBERSHIP_STORAGE == log_type
            || is_offline_partition_log(log_type)
            || is_partition_meta_log(log_type)
            || is_remove_partition_from_pg_log(log_type));
  }

  static bool is_post_barrier_required_log(const int64_t log_type)
  {
    return (is_start_membership_log(log_type)
            || is_partition_meta_log(log_type)
            || is_add_partition_to_pg_log(log_type));
  }

  static bool is_valid_log_type(const int64_t log_type)
  {
    return is_trans_log(log_type)
           || is_test_log(log_type)
           || is_freeze_log(log_type)
           || is_offline_partition_log(log_type)
           || is_start_membership_log(log_type)
           || is_checkpoint_log(log_type)
           || is_partition_meta_log(log_type)
           || is_add_partition_to_pg_log(log_type)
           || is_remove_partition_from_pg_log(log_type)
           || is_schema_version_change_log(log_type)
           || is_ddl_log(log_type);
  }
};

class ObTransLogType
{
public:
  static bool is_valid(const int64_t log_type)
  {
    return ObStorageLogTypeChecker::is_trans_log(log_type);
  }
};

inline bool need_update_trans_version(const int64_t log_type)
{
  return OB_LOG_TRANS_REDO == log_type ||
         OB_LOG_TRANS_PREPARE == log_type ||
         OB_LOG_TRANS_REDO_WITH_PREPARE == log_type ||
         OB_LOG_TRANS_PREPARE_WITH_COMMIT == log_type ||
         OB_LOG_TRANS_REDO_WITH_PREPARE_WITH_COMMIT == log_type ||
         OB_LOG_TRANS_PREPARE_WITH_COMMIT_WITH_CLEAR == log_type ||
         OB_LOG_TRANS_REDO_WITH_PREPARE_WITH_COMMIT_WITH_CLEAR == log_type ||
         OB_LOG_SP_TRANS_REDO == log_type ||
         OB_LOG_SP_TRANS_COMMIT == log_type ||
         OB_LOG_SP_ELR_TRANS_COMMIT == log_type;
}

inline bool need_carry_base_ts(const int64_t log_type)
{
  return OB_LOG_TRANS_COMMIT == log_type ||
         OB_LOG_TRANS_CLEAR == log_type;
}

} // namespace storage
} // namespace oceanbase

#endif // OCEANBASE_STORAGE_OB_STORAGE_LOG_TYPE_
