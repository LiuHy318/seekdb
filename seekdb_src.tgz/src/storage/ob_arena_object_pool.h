/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_TRANSACTION_OB_ARENA_OBJ_POOL_
#define OCEANBASE_TRANSACTION_OB_ARENA_OBJ_POOL_

#include <stdint.h>
#include "lib/allocator/ob_allocator.h"
#include "lib/lock/ob_spin_rwlock.h"
#include "lib/utility/ob_print_utils.h"

namespace oceanbase
{
namespace transaction
{

template <typename T, int64_t OBJ_NUM>
class ObArenaObjPool
{
public:
  ObArenaObjPool(common::ObIAllocator &allocator)
   : allocator_(allocator),
     alloc_count_(0),
     free_count_(0) {}
  ObArenaObjPool() = delete;
  void *alloc();
  void free(void *obj);
  void reset();
  TO_STRING_KV(K_(alloc_count), K_(free_count));
private:
  common::ObIAllocator &allocator_;
  int64_t alloc_count_;
  int64_t free_count_;
  // only used one time.
  char obj_pool_[sizeof(T) * OBJ_NUM];

};

template <typename T, int64_t OBJ_NUM>
void *ObArenaObjPool<T, OBJ_NUM>::alloc()
{
  void *ptr = nullptr;
  int64_t allocated_count = ATOMIC_FAA(&alloc_count_, 1);
  if (allocated_count < OBJ_NUM) {
    int64_t pos = sizeof(T) * allocated_count;
    ptr = &obj_pool_[pos];
  } else {
    const int64_t size = sizeof(T);
    ptr = allocator_.alloc(size);
  }

  if (OB_ISNULL(ptr)) {
    ATOMIC_DEC(&alloc_count_);
    STORAGE_LOG_RET(ERROR, common::OB_ALLOCATE_MEMORY_FAILED, "obj alloc error, no memory", K(*this), K(lbt()));
  } else {
    STORAGE_LOG(DEBUG, "obj alloc succ", K(*this), KP(ptr), K(lbt()));
  }

  return ptr;
}

template <typename T, int64_t OBJ_NUM>
void ObArenaObjPool<T, OBJ_NUM>::free(void *obj)
{
  bool need_free = true;
  if (OB_ISNULL(obj)) {
    STORAGE_LOG_RET(ERROR, common::OB_ERR_UNEXPECTED, "obj is null, unexpected error", KP(obj), K(*this), K(lbt()));
  } else {
    STORAGE_LOG(DEBUG, "object free succ", KP(obj), K(*this), K(lbt()));
    ATOMIC_INC(&free_count_);
    for (int i = 0; need_free && i < OBJ_NUM; i++) {
      int64_t pos = sizeof(T) * i;
      if (obj == &obj_pool_[pos]) {
        // no need free.
        need_free = false;
      }
    }
    if (need_free) {
      allocator_.free(obj);
    }
  }
}

template <typename T, int64_t OBJ_NUM>
void ObArenaObjPool<T, OBJ_NUM>::reset()
{
  if (OB_UNLIKELY(alloc_count_ != free_count_)) {
    STORAGE_LOG_RET(ERROR, common::OB_ERR_UNEXPECTED, "object alloc and free count not match", K(*this));
  }
  OB_SAFE_ASSERT(alloc_count_ == free_count_);

  alloc_count_ = 0;
  free_count_ = 0;
}

}  // namespace transaction
}  // namespace oceanbase

#endif
