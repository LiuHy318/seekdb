/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_DML_RUNNING_CTX
#define OCEANBASE_STORAGE_OB_DML_RUNNING_CTX

#include "lib/container/ob_iarray.h"
#include "storage/ob_i_store.h"
#include "storage/ob_relative_table.h"
#include "share/scn.h"
#include "storage/lob/ob_lob_tablet_dml.h"

namespace oceanbase
{
namespace common
{
class ObIAllocator;
}

namespace share
{
namespace schema
{
class ObMultiVersionSchemaService;
}
}

namespace storage
{
class ObTablet;
struct ObDMLBaseParam;
class ObRelativeTable;
class ObSingleRowGetter;

struct ObDMLRunningCtx
{
public:
  ObDMLRunningCtx(
    ObStoreCtx &store_ctx,
    const ObDMLBaseParam &dml_param,
    common::ObIAllocator &allocator,
    const blocksstable::ObDmlFlag dml_flag,
    const bool is_need_check_old_row = false);
  ~ObDMLRunningCtx();

  int init(
      const common::ObIArray<uint64_t> *column_ids,
      const common::ObIArray<uint64_t> *upd_col_ids,
      ObMultiVersionSchemaService *schema_service,
      ObTabletHandle &tablet_handle);
  OB_INLINE bool is_main_table_rowkey_col(const int16_t col_idx)
  {
    return main_table_rowkey_col_flag_.count() > 0 && main_table_rowkey_col_flag_.at(col_idx);
  }
private:
  int prepare_column_info(const common::ObIArray<uint64_t> &column_ids);
  int prepare_relative_table(
      const share::schema::ObTableSchemaParam &schema,
      ObTabletHandle &tablet_handle,
      const share::SCN &read_snapshot);
  int check_need_old_row_legitimacy();
  int init_cmp_funcs();
  int check_schema_version(share::schema::ObMultiVersionSchemaService &schema_service,
                           const uint64_t table_id,
                           const int64_t runtime_schema_version,
                           const int64_t table_version,
                           ObTabletHandle &tablet_handle);
  int check_runtime_schema_version(
      share::schema::ObMultiVersionSchemaService &schema_service,
      const uint64_t table_id,
      const int64_t runtime_schema_version);

public:
  ObStoreCtx &store_ctx_;
  const ObDMLBaseParam &dml_param_;
  common::ObIAllocator &allocator_;
  const blocksstable::ObDmlFlag dml_flag_;
  ObRelativeTable relative_table_;
  const share::schema::ColumnMap *col_map_;
  const ObColDescIArray *col_descs_;
  const common::ObIArray<uint64_t> *column_ids_;
  blocksstable::ObDatumRow datum_row_;
  blocksstable::ObStoreCmpFuncs cmp_funcs_;
  bool is_need_check_old_row_;
  bool is_udf_;
  bool has_lob_rowkey_;
  ObLobTabletDmlCtx lob_dml_ctx_;
  common::ObFixedArray<bool, common::ObIAllocator> main_table_rowkey_col_flag_;

private:
  share::schema::ObSchemaGetterGuard schema_guard_;
  bool is_inited_;
};
} // namespace storage
} // namespace oceanbase

#endif // OCEANBASE_STORAGE_OB_DML_RUNNING_CTX
