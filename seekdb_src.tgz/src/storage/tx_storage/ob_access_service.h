/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_DATA_ACCESS_SERVICE_
#define OCEANBASE_STORAGE_OB_DATA_ACCESS_SERVICE_

#include "data_plane/access/ob_tablet_scan.h"
#include "share/ob_est_row_count_record.h"
#include "data_plane/ob_i_dml_service.h"
#include "data_plane/ob_i_optimizer_storage_service.h"
#include "data_plane/ob_i_range_service.h"
#include "data_plane/ob_i_storage_estimator.h"
#include "data_plane/ob_i_write_context_service.h"
#include "storage/ls/ob_ls_tablet_service.h"
#include "storage/access/ob_table_scan_range.h"

namespace oceanbase
{
namespace common {
class ObTabletID;
class ObNewRowIterator;
}
namespace transaction
{
class ObTxDesc;
}
namespace storage
{
struct ObDMLBaseParam;
class ObLSService;
class ObStoreCtx;

class ObStoreCtxGuard
{
public:
  ObStoreCtxGuard() : is_inited_(false), ls_(nullptr), init_ts_(0)
  {
  }
  ~ObStoreCtxGuard()
  {
    reset();
  }
  int init(ObLS *ls);
  void reset();
  ObStoreCtx &get_store_ctx() { return ctx_; }
  ObLS *get_ls() const { return ls_; }
private:
  bool is_inited_;
  ObStoreCtx ctx_;
  ObLS *ls_;
  int64_t init_ts_;

  DISALLOW_COPY_AND_ASSIGN(ObStoreCtxGuard);
};

class ObAccessService : public common::ObITabletScan,
                        public data_plane::ObIDmlService,
                        public data_plane::ObIOptimizerStorageService,
                        public data_plane::ObIRangeService,
                        public data_plane::ObIStorageEstimator,
                        public data_plane::ObIWriteContextService
{
public:
  ObAccessService();
  virtual ~ObAccessService();
  int init(ObLSService *ls_service);
  static int server_module_init(ObAccessService* &access_service);

  void destroy();
public:
  // pre_check_lock
  // @param [in] tx_desc, the trans context.
  // @param [in] param, contain all the check parameters.
  int pre_check_lock(
      transaction::ObTxDesc &tx_desc,
      const transaction::tablelock::ObLockParam &param);
  // lock obj
  // @param [in] tx_desc, the trans context.
  // @param [in] param, contain all the lock parameters.
  int lock_obj(
      transaction::ObTxDesc &tx_desc,
      const transaction::tablelock::ObLockParam &param);
  // unlock obj
  // @param [in] tx_desc, the trans context.
  // @param [in] param, contain all the unlock parameters.
  int unlock_obj(
      transaction::ObTxDesc &tx_desc,
      const transaction::tablelock::ObLockParam &param);
  // replace lock of obj
  // @param [in] tx_desc, the trans context.
  // @param [in] lock_param, contain all the parameters of previous lock, and lock_owner / lock_mode of new lock
  int replace_obj_lock(
      transaction::ObTxDesc &tx_desc,
      const transaction::tablelock::ObReplaceLockParam &lock_param);
  int add_lock_into_queue(transaction::ObTxDesc &tx_desc,
                          const transaction::tablelock::ObLockParam &param);
  // ObITabletScan interface
  virtual int table_scan(
      ObVTableScanParam &vparam,
      ObNewRowIterator *&result) override;
  virtual int table_rescan(
      ObVTableScanParam &vparam,
      ObNewRowIterator *result) override;
  virtual int table_advance_scan(ObVTableScanParam &vparam, ObNewRowIterator *result) override;
  virtual int reuse_scan_iter(const bool switch_param, common::ObNewRowIterator *iter) override;
  virtual int revert_scan_iter(common::ObNewRowIterator *iter) override;
  virtual int get_multi_ranges_cost(
      const common::ObTabletID &tablet_id,
      const int64_t timeout_us,
      const common::ObIArray<common::ObStoreRange> &ranges,
      int64_t &total_size) override;
  virtual int split_multi_ranges(
      const common::ObTabletID &tablet_id,
      const int64_t timeout_us,
      const common::ObIArray<ObStoreRange> &ranges,
      const int64_t expected_task_count,
      common::ObIAllocator &allocator,
      common::ObArrayArray<ObStoreRange> &multi_range_split_array) override;
  int get_write_store_ctx_guard(
      const int64_t timeout,
      transaction::ObTxDesc &tx_desc,
      const transaction::ObTxReadSnapshot &snapshot,
      const int16_t branch_id,
      concurrent_control::ObWriteFlag &write_flag,
      ObStoreCtxGuard &ctx_guard,
      const transaction::ObTxSEQ &spec_seq_no = transaction::ObTxSEQ::INVL());
  int acquire_write_context(
      const int64_t timeout,
      transaction::ObTxDesc &tx_desc,
      const transaction::ObTxReadSnapshot &snapshot,
      const int16_t branch_id,
      concurrent_control::ObWriteFlag &write_flag,
      data_plane::ObWriteContext &write_context) override;

  // DML interface
  int prepare_execution(
      const data_plane::ObDmlWriteSpec &write_spec,
      const data_plane::ObDmlTablePlan &table_plan,
      const transaction::ObTxReadSnapshot &snapshot,
      common::ObIAllocator &allocator,
      const data_plane::ObWriteContext &write_context,
      const concurrent_control::ObWriteFlag &write_flag,
      data_plane::ObDmlExecution &execution) override;
  int delete_rows(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const data_plane::ObDmlExecution &execution,
      const common::ObIArray<uint64_t> &column_ids,
      blocksstable::ObDatumRowIterator *row_iter,
      int64_t &affected_rows) override;
  int put_rows(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const data_plane::ObDmlExecution &execution,
      const common::ObIArray<uint64_t> &column_ids,
      blocksstable::ObDatumRowIterator *row_iter,
      int64_t &affected_rows) override;
  int insert_rows(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const data_plane::ObDmlExecution &execution,
      const common::ObIArray<uint64_t> &column_ids,
      blocksstable::ObDatumRowIterator *row_iter,
      int64_t &affected_rows) override;
  int insert_rows_fetch_duplicates(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const data_plane::ObDmlExecution &execution,
      const common::ObIArray<uint64_t> &column_ids,
      const common::ObIArray<uint64_t> &duplicated_column_ids,
      blocksstable::ObDatumRowIterator *row_iter,
      const data_plane::ObDuplicateReturnMode return_mode,
      int64_t &affected_rows,
      blocksstable::ObDatumRowIterator *&duplicated_rows) override;
  void free_duplicate_rows_iterator(
      blocksstable::ObDatumRowIterator *iterator) override;
  int update_rows(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const data_plane::ObDmlExecution &execution,
      const common::ObIArray<uint64_t> &column_ids,
      const common::ObIArray<uint64_t> &updated_column_ids,
      blocksstable::ObDatumRowIterator *row_iter,
      int64_t &affected_rows) override;
  int lock_rows(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const data_plane::ObDmlExecution &execution,
      const int64_t abs_lock_timeout,
      const data_plane::ObRowLockMode lock_mode,
      blocksstable::ObDatumRowIterator *row_iter,
      int64_t &affected_rows) override;

  // Concrete overloads remain available to Storage-owned jobs.
  int delete_rows(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const ObDMLBaseParam &dml_param,
      const common::ObIArray<uint64_t> &column_ids,
      blocksstable::ObDatumRowIterator *row_iter,
      int64_t &affected_rows);
  int put_rows(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const ObDMLBaseParam &dml_param,
      const common::ObIArray<uint64_t> &column_ids,
      blocksstable::ObDatumRowIterator *row_iter,
      int64_t &affected_rows);
  int insert_rows(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const ObDMLBaseParam &dml_param,
      const common::ObIArray<uint64_t> &column_ids,
      blocksstable::ObDatumRowIterator *row_iter,
      int64_t &affected_rows);
  int insert_rows_with_fetch_dup(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const ObDMLBaseParam &dml_param,
      const common::ObIArray<uint64_t> &column_ids,
      const common::ObIArray<uint64_t> &duplicated_column_ids,
      blocksstable::ObDatumRowIterator *row_iter,
      const ObInsertFlag flag,
      int64_t &affected_rows,
      blocksstable::ObDatumRowIterator *&duplicated_rows);
  int update_rows(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const ObDMLBaseParam &dml_param,
      const common::ObIArray<uint64_t> &column_ids,
      const common::ObIArray< uint64_t> &updated_column_ids,
      blocksstable::ObDatumRowIterator *row_iter,
      int64_t &affected_rows);
  int lock_rows(
      const common::ObTabletID &tablet_id,
      transaction::ObTxDesc &tx_desc,
      const ObDMLBaseParam &dml_param,
      const int64_t abs_lock_timeout, /* -1: undefined, 0: nowait */
      const ObLockFlag lock_flag,
      blocksstable::ObDatumRowIterator *row_iter,
      int64_t &affected_rows);
  int estimate_row_count(
      const ObTableScanParam &param,
      const ObTableScanRange &scan_range,
      const int64_t timeout_us,
      ObIArray<ObEstRowCountRecord> &est_records,
      int64_t &logical_row_count,
      int64_t &physical_row_count) const;
  int estimate_row_count_for_batch(
      ObTableScanParam &param,
      const common::ObSimpleBatch &batch,
      common::ObIAllocator &allocator,
      const int64_t timeout_us,
      common::ObIArray<common::ObEstRowCountRecord> &est_records,
      int64_t &logical_row_count,
      int64_t &physical_row_count) const override;
  int estimate_block_count_and_row_count(
      const common::ObTabletID &tablet_id,
      const int64_t timeout_us,
      int64_t &macro_block_count,
      int64_t &micro_block_count,
      int64_t &sstable_row_count,
      int64_t &memtable_row_count) const override;
  int get_latest_tablet_row_count_delta(
      const common::ObTabletID &tablet_id,
      int64_t &row_count_delta) const override;
  int run_io_benchmark(
      common::ObIAllocator &allocator,
      int64_t &disk_random_read_speed,
      int64_t &disk_sequential_read_speed) const override;


  int inner_tablet_scan(
      const common::ObTabletID &tablet_id,
      ObTableScanParam &param,
      ObNewRowIterator *&result);

  int scan_block_stat(ObBlockStatScanParam &scan_param, ObBlockStatIterator &iter);

protected:
  int check_memstore_limit_(bool &is_out_of_mem);
  int get_write_store_ctx_guard_(
      const int64_t timeout,
      transaction::ObTxDesc &tx_desc,
      const transaction::ObTxReadSnapshot &snapshot,
      const int16_t branch_id,
      const concurrent_control::ObWriteFlag write_flag,
      ObStoreCtxGuard &ctx_guard,
      const transaction::ObTxSEQ &spec_seq_no = transaction::ObTxSEQ::INVL());
  int check_read_allowed_(
      const common::ObTabletID &tablet_id,
      const ObStoreAccessType access_type,
      const ObTableScanParam &scan_param,
      ObTabletHandle &tablet_handle,
      ObStoreCtxGuard &ctx_guard,
      share::SCN user_specified_snapshot);
  int check_write_allowed_(
      const common::ObTabletID &tablet_id,
      const ObStoreAccessType access_type,
      const ObDMLBaseParam &dml_param,
      const int64_t lock_wait_timeout_ts,
      transaction::ObTxDesc &tx_desc,
      ObTabletHandle &tablet_handle,
      ObStoreCtxGuard &ctx_guard);
  int construct_store_ctx_other_variables_(
      ObLS &ls,
      const common::ObTabletID &tablet_id,
      const int64_t timeout,
      const share::SCN &snapshot,
      ObTabletHandle &tablet_handle,
      ObStoreCtxGuard &ctx_guard);
  static OB_INLINE int64_t get_lock_wait_timeout_(const int64_t abs_lock_timeout, const int64_t stmt_timeout)
  {
    return (abs_lock_timeout < 0 ? stmt_timeout : (abs_lock_timeout > stmt_timeout ? stmt_timeout : abs_lock_timeout));
  }

private:
  int do_table_scan_(
      const common::ObTabletID &data_tablet_id,
      ObTableScanParam &param,
      ObNewRowIterator *&result);

private:
  bool is_inited_;
  ObLSService *ls_svr_;
};

}
}
#endif
