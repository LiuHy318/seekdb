/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEABASE_STORAGE_OB_EMPTY_SHELL_TASK_
#define OCEABASE_STORAGE_OB_EMPTY_SHELL_TASK_

#include "lib/oblog/ob_log.h"
#include "lib/task/ob_timer.h"
#include "share/scn.h"
#include "storage/tablet/ob_tablet_create_delete_mds_user_data.h"
#include "storage/meta_mem/ob_tablet_handle.h"

namespace oceanbase
{
namespace storage
{
namespace checkpoint
{

class ObTabletGCService;
class ObTabletEmptyShellHandler
{
public:
  friend class ObEmptyShellTask;
public:
  ObTabletEmptyShellHandler();
  ~ObTabletEmptyShellHandler();
  int init(storage::ObLS *ls);
  void reset();

  bool check_stop() { return ATOMIC_LOAD(&stopped_) == true; }
  int offline();
  void online();
  bool get_empty_shell_trigger() const;
  void set_empty_shell_trigger(bool is_trigger);
  TO_STRING_KV(K_(is_inited), K_(is_trigger), K_(stopped));

private:
  void set_stop() { ATOMIC_STORE(&stopped_, true); }
  void set_start() { ATOMIC_STORE(&stopped_, false); }
  bool is_finish() { obsys::ObWLockGuard lock(wait_lock_, false); return lock.acquired(); }
  int check_candidate_tablet_(const ObTablet &tablet, bool &can_become_shell, bool &need_retry);
  int get_empty_shell_tablet_ids(common::ObTabletIDArray &empty_shell_tablet_ids, bool &need_retry);
  int update_tablets_to_empty_shell(ObLS *ls, const common::ObIArray<common::ObTabletID> &tablet_ids);
public:
  obsys::ObRWLock wait_lock_;

private:
  storage::ObLS *ls_;
  bool is_trigger_;
  bool stopped_;
  bool is_inited_;
};


class ObEmptyShellTask : public common::ObTimerTask
{
public:
  static const int64_t GC_EMPTY_TABLET_SHELL_INTERVAL;
  static const int64_t GLOBAL_EMPTY_CHECK_INTERVAL_TIMES;
  ObEmptyShellTask(ObTabletGCService &tablet_gc_service)
    : tablet_gc_service_(tablet_gc_service)
  {}
  virtual ~ObEmptyShellTask() {}
  virtual void runTimerTask();
private:
  ObTabletGCService &tablet_gc_service_;
};

} // checkpoint
} // storage
} // oceanbase

#endif
