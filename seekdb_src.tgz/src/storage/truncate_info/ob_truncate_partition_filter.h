/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_TRUNCATE_PARTITION_FILTER_
#define OCEANBASE_STORAGE_OB_TRUNCATE_PARTITION_FILTER_

#include "lib/allocator/ob_allocator.h"
#include "common/ob_common_types.h"
#include "data_plane/truncate_info/ob_truncate_info.h"
#include "ob_mds_info_distinct_mgr.h"

namespace oceanbase
{
namespace blocksstable
{
class ObDatumRow;
}

namespace share
{
namespace schema
{
struct ObColDesc;
}
}

namespace storage
{

class ObTruncateFilterEvaluator;

}
namespace sql
{
class ObPushdownFilterExecutor;
class ObExternalPushdownFilterRuntime;
}
namespace storage
{

enum class ObTruncateFilterType : uint8_t
{
  NORMAL_FILTER = 0,
  BASE_VERSION_FILTER,
  EMPTY_FILTER,
  FILTER_TYPE_MAX,
};

class ObTruncatePartitionFilter {
public:
  ObTruncatePartitionFilter();
  ~ObTruncatePartitionFilter();
  // for query and dml
  int init(
      ObTablet &tablet,
      const common::ObIArray<share::schema::ObColDesc> &cols_desc,
      const common::ObIArray<share::schema::ObColumnParam *> *cols_param,
      const common::ObVersionRange &read_version_range,
      const bool has_truncate_flag,
      const bool has_truncate_info,
      ObIAllocator &outer_allocator);
  // for compaction
  int init(
      const int64_t schema_rowkey_cnt,
      const common::ObIArray<share::schema::ObColDesc> &cols_desc,
      const common::ObIArray<share::schema::ObColumnParam *> *cols_param,
      const ObMdsInfoDistinctMgr &mds_info_mgr);
  int switch_info(
      ObTablet &tablet,
      const common::ObIArray<share::schema::ObColDesc> &cols_desc,
      const common::ObIArray<share::schema::ObColumnParam *> *cols_param,
      const common::ObVersionRange &read_version_range,
      const bool has_truncate_flag,
      const bool has_truncate_info);
  void reuse();
  bool is_valid() const { return is_inited_; }
  // this interface is thread safe
  int filter(
      const blocksstable::ObDatumRow &row,
      bool &filtered,
      const bool check_filter = true,
      const bool check_version = false);
  int check_filter_row_complete(const blocksstable::ObDatumRow &row, bool &complete);
  int combine_to_filter_tree(sql::ObPushdownFilterExecutor *&root_filter);
  OB_INLINE common::ObIAllocator *get_outer_allocator()
  {
    return outer_allocator_;
  }
  OB_INLINE bool need_combined_to_pd_filter() const
  {
    return is_normal_filter() && !has_combined_to_pd_filter_;
  }
  OB_INLINE bool is_valid_filter() const
  {
    return is_normal_filter() || is_base_version_filter();
  }
  OB_INLINE bool is_normal_filter() const
  {
    return ObTruncateFilterType::NORMAL_FILTER == filter_type_;
  }
  OB_INLINE bool is_base_version_filter() const
  {
    return ObTruncateFilterType::BASE_VERSION_FILTER == filter_type_;
  }
  OB_INLINE void set_empty()
  {
    filter_type_ = ObTruncateFilterType::EMPTY_FILTER;
  }
  void uncombined_from_pd_filter();
  TO_STRING_KV(K_(is_inited), K_(filter_type), K_(schema_rowkey_cnt), K_(base_version), K_(has_combined_to_pd_filter),
               K_(mds_info_mgr), K_(truncate_info_array), KP_(evaluator), KP_(pushdown_runtime), KP_(outer_allocator));
private:
  int init_truncate_filter(
      const int64_t schema_rowkey_cnt,
      const common::ObIArray<share::schema::ObColDesc> &cols_desc,
      const common::ObIArray<share::schema::ObColumnParam *> *cols_param,
      const ObTruncateInfoArray &array);
  int init_column_idxs(const ObTruncateInfoArray &array);
  int init_column_idxs(const ObPartKeyIdxArray &key_idx_array);
  int do_normal_filter(const blocksstable::ObDatumRow &row, bool &filtered);
  int do_base_version_filter(const blocksstable::ObDatumRow &row, bool &filtered);
  static const int64_t COLUMN_IDX_CNT = 4;
  bool is_inited_;
  ObTruncateFilterType filter_type_;
  int64_t schema_rowkey_cnt_;
  int64_t base_version_;
  bool has_combined_to_pd_filter_;
  ObArenaAllocator filter_allocator_;
  ObArenaAllocator truncate_info_allocator_;
  ObMdsInfoDistinctMgr mds_info_mgr_;
  ObTruncateInfoArray truncate_info_array_;
  ObTruncateFilterEvaluator *evaluator_;
  sql::ObExternalPushdownFilterRuntime *pushdown_runtime_;
  common::ObIAllocator *outer_allocator_;
  // record all column idx needed for part_key or sub_part_key
  ObSEArray<uint64_t, COLUMN_IDX_CNT> ref_column_idxs_;
private:
  DISALLOW_COPY_AND_ASSIGN(ObTruncatePartitionFilter);
};

struct ObTruncatePartitionFilterFactory
{
  static int build_truncate_partition_filter(
      ObTablet &tablet,
      const common::ObIArray<share::schema::ObColDesc> &cols_desc,
      const common::ObIArray<share::schema::ObColumnParam *> *cols_param,
      const common::ObVersionRange &read_version_range,
      ObIAllocator *outer_allocator,
      ObTruncatePartitionFilter *&truncate_part_filter);
  static void destroy_truncate_partition_filter(ObTruncatePartitionFilter *&truncate_part_filter);
};

}
}

#endif
