/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define USING_LOG_PREFIX SHARE_SCHEMA

#include "ob_table_dml_param.h"

#include "data_plane/access/ob_dml_table_plan.h"
#include "data_plane/fts/ob_doc_id.h"
#include "data_plane/vector/ob_vector_index_schema.h"
#include "storage/access/ob_dml_table_plan_access.h"
#include "storage/ob_i_store.h"
#include "object/ob_object.h"
#include "share/schema/ob_schema_getter_guard.h"

namespace oceanbase
{
using namespace common;
namespace share
{
namespace schema
{
// ------ ObTableSchemaParam ------ //
ObTableSchemaParam::ObTableSchemaParam(ObIAllocator &allocator)
  : allocator_(allocator),
    table_id_(OB_INVALID_ID),
    schema_version_(OB_INVALID_VERSION),
    table_type_(MAX_TABLE_TYPE),
    index_type_(INDEX_TYPE_IS_NOT),
    index_status_(INDEX_STATUS_NOT_FOUND),
    shadow_rowkey_column_num_(0),
    doc_id_col_id_(OB_INVALID_ID),
    fulltext_col_id_(OB_INVALID_ID),
    spatial_geo_col_id_(OB_INVALID_ID),
    spatial_cellid_col_id_(OB_INVALID_ID),
    spatial_mbr_col_id_(OB_INVALID_ID),
    index_name_(),
    fts_parser_name_(),
    fts_parser_properties_(),
    columns_(allocator),
    col_map_(allocator),
    pk_name_(),
    read_info_(),
    lob_inrow_threshold_(OB_DEFAULT_LOB_INROW_THRESHOLD),
    multivalue_col_id_(OB_INVALID_ID),
    multivalue_arr_col_id_(OB_INVALID_ID),
    data_table_rowkey_column_num_(0),
    vec_id_col_id_(OB_INVALID_ID),
    vec_index_param_(),
    vec_dim_(0),
    vec_vector_col_id_(OB_INVALID_ID),
    inc_pk_doc_id_col_id_(OB_INVALID_ID),
    vec_chunk_col_id_(OB_INVALID_ID),
    vec_embedded_col_id_(OB_INVALID_ID),
    has_async_index_(false)
{
}

ObTableSchemaParam::~ObTableSchemaParam()
{
  reset();
}

void ObTableSchemaParam::reset()
{
  table_id_ = OB_INVALID_ID;
  schema_version_ = OB_INVALID_VERSION;
  table_type_ = MAX_TABLE_TYPE;
  index_type_ = INDEX_TYPE_IS_NOT;
  index_status_ = INDEX_STATUS_NOT_FOUND;
  shadow_rowkey_column_num_ = 0;
  doc_id_col_id_ = OB_INVALID_ID;
  fulltext_col_id_ = OB_INVALID_ID;
  spatial_geo_col_id_ = OB_INVALID_ID;
  spatial_cellid_col_id_ = OB_INVALID_ID;
  spatial_mbr_col_id_ = OB_INVALID_ID;
  index_name_.reset();
  fts_parser_name_.reset();
  fts_parser_properties_.reset();
  columns_.reset();
  col_map_.clear();
  pk_name_.reset();
  read_info_.reset();
  lob_inrow_threshold_ = OB_DEFAULT_LOB_INROW_THRESHOLD;
  multivalue_col_id_ = OB_INVALID_ID;
  multivalue_arr_col_id_ = OB_INVALID_ID;
  data_table_rowkey_column_num_ =0 ;
  vec_id_col_id_ = OB_INVALID_ID;
  vec_chunk_col_id_ = OB_INVALID_ID;
  vec_embedded_col_id_ = OB_INVALID_ID;
  vec_index_param_.reset();
  vec_dim_ = 0;
  vec_vector_col_id_ = OB_INVALID_ID;
  inc_pk_doc_id_col_id_ = OB_INVALID_ID;
  has_async_index_ = false;
}

int ObTableSchemaParam::convert(const ObTableSchema *schema)
{
  int ret = OB_SUCCESS;
  static const int64_t COMMON_COLUMN_NUM = 16;
  ObSEArray<ObColumnParam *, COMMON_COLUMN_NUM> tmp_cols;
  ObSEArray<ObColDesc, COMMON_COLUMN_NUM> all_column_ids;
  ObSEArray<ObColDesc, COMMON_COLUMN_NUM> tmp_col_descs;
  ObSEArray<int32_t, COMMON_COLUMN_NUM> tmp_cols_index;
  if (OB_ISNULL(schema)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("schema is NULL", K(ret), KP(schema));
  } else {
    table_id_ = schema->get_table_id();
    schema_version_ = schema->get_schema_version();
    table_type_ = schema->get_table_type();
    lob_inrow_threshold_ = schema->get_lob_inrow_threshold();
  }

  if (OB_SUCC(ret) && schema->is_user_table() && schema->is_table_with_pk()) {
    ObString tmp_pk_name;
    if (OB_FAIL(schema->get_pk_constraint_name(tmp_pk_name))) {
    } else if (OB_FAIL(ob_write_string(allocator_, tmp_pk_name, pk_name_))) {
    }
  }

  if(OB_SUCC(ret) && schema->is_index_table()) {
    index_type_ = schema->get_index_type();
    index_status_ = schema->get_index_status();
    shadow_rowkey_column_num_ = schema->get_shadow_rowkey_column_num();
    ObString tmp_name;

    if (schema->is_spatial_index()) {
      if (OB_FAIL(schema->get_spatial_geo_column_id(spatial_geo_col_id_))) {
      } else if (OB_FAIL(schema->get_index_info().get_spatial_cellid_col_id(spatial_cellid_col_id_))) {
      } else if (OB_FAIL(schema->get_index_info().get_spatial_mbr_col_id(spatial_mbr_col_id_))) {
      }
    } else if (schema->is_fts_index_aux() || schema->is_fts_doc_word_aux()) {
      ObDocIDType doc_id_type;
      uint64_t docid_col_id;
      if (OB_FAIL(schema->get_fulltext_typed_col_ids(docid_col_id, doc_id_type, fulltext_col_id_))) {
      } else if (OB_UNLIKELY(!ObDocIDUtils::is_docid_col_id_valid(docid_col_id)
                             || fulltext_col_id_ <= OB_APP_MIN_COLUMN_ID || OB_INVALID_ID == fulltext_col_id_)) {
        ret = OB_INVALID_ARGUMENT;
        LOG_WARN("invalid doc id or fulltext column id", K(ret), K(docid_col_id), K(fulltext_col_id_));
      } else if (doc_id_type == ObDocIDType::TABLET_SEQUENCE && FALSE_IT(doc_id_col_id_ = docid_col_id)) {
      } else if (doc_id_type == ObDocIDType::HIDDEN_INC_PK && FALSE_IT(inc_pk_doc_id_col_id_ = docid_col_id)) {
      } else if (OB_FAIL(ob_write_string(allocator_, schema->get_parser_name_str(), fts_parser_name_))) {
      } else if (OB_FAIL(ob_write_string(allocator_, schema->get_parser_property_str(), fts_parser_properties_))) {
      }
    } else if (schema->is_multivalue_index_aux()) {
      for (int64_t i = 0; OB_SUCC(ret) && i < schema->get_column_count(); ++i) {
        const ObColumnSchemaV2 *column_schema = schema->get_column_schema_by_idx(i);
        if (OB_ISNULL(column_schema)) {
          ret = OB_ERR_UNEXPECTED;
          LOG_WARN("unexpected error, column schema is nullptr", K(ret), K(i), KPC(schema));
        } else if (column_schema->is_doc_id_column()) {
          doc_id_col_id_ = column_schema->get_column_id();
        } else if (column_schema->is_multivalue_generated_column()) {
          multivalue_col_id_ = column_schema->get_column_id();
        } else if (column_schema->is_multivalue_generated_array_column()) {
          multivalue_arr_col_id_ = column_schema->get_column_id();
        }
      }
    } else if (schema->is_vec_delta_buffer_type()
              || schema->is_vec_rowkey_vid_type()
              || schema->is_vec_vid_rowkey_type()
              || schema->is_hybrid_vec_index_log_type()
              || schema->is_hybrid_vec_index_embedded_type()) {
      if (schema->is_vec_delta_buffer_type()
        || schema->is_hybrid_vec_index_embedded_type()
        || schema->is_hybrid_vec_index_log_type()) {
        if (OB_FAIL(ob_write_string(allocator_, schema->get_index_params(), vec_index_param_))) {
        } else if (OB_FAIL(data_plane::resolve_vector_index_column_dimension(
                       *schema, vec_dim_))) {
        } else if (vec_dim_ == 0) {
          ret = OB_ERR_UNEXPECTED;
          LOG_WARN("get vector dim is zero, fail to calc", K(ret), K(vec_dim_), KPC(schema), K(schema->get_index_type()));
        }
      }
      for (int64_t i = 0; OB_SUCC(ret) && i < schema->get_column_count(); ++i) {
        const ObColumnSchemaV2 *column_schema = schema->get_column_schema_by_idx(i);
        uint64_t col_id = column_schema->get_column_id();
        if (OB_ISNULL(column_schema)) {
          ret = OB_ERR_UNEXPECTED;
          LOG_WARN("unexpected error, column schema is nullptr", K(ret), K(i), KPC(schema));
        } else if (column_schema->is_vec_hnsw_vid_column()) {
          vec_id_col_id_ = col_id;
        } else if (column_schema->is_hybrid_embedded_vec_column()) {
          vec_embedded_col_id_ = column_schema->get_column_id();
        } else if (schema->is_vec_delta_buffer_type()) {
          if (column_schema->is_vec_hnsw_vector_column()) {
            vec_vector_col_id_ = col_id;
          }
        } else if (schema->is_hybrid_vec_index_log_type()) {
          if (column_schema->get_column_name_str().prefix_match(OB_HYBRID_VEC_CHUNK_VALUE_COLUMN_NAME_PREFIX)) {
            vec_chunk_col_id_ = column_schema->get_column_id();
          }
        }
        if (OB_SUCC(ret) && (schema->is_vec_delta_buffer_type() || schema->is_hybrid_vec_index_log_type()
                              || schema->is_hybrid_vec_index_embedded_type())) {
          if (column_schema->is_hidden_pk_column_id(col_id)) {
            if (vec_id_col_id_ == OB_INVALID_ID) {
              vec_id_col_id_ = col_id;
            } else {
              ret = OB_ERR_UNEXPECTED;
              LOG_WARN("invalid vec id column id", K(ret), K(vec_id_col_id_), K(col_id));
            }
          }
        }
      }
    } else if (schema->is_vec_dim_docid_value_type()) {
      if (OB_FAIL(ob_write_string(allocator_, schema->get_index_params(), vec_index_param_))) {
      }
      for (int64_t i = 0; OB_SUCC(ret) && i < schema->get_column_count(); ++i) {
        const ObColumnSchemaV2 *column_schema = schema->get_column_schema_by_idx(i);
        if (OB_ISNULL(column_schema)) {
          ret = OB_ERR_UNEXPECTED;
          LOG_WARN("unexpected error, column schema is nullptr", K(ret), K(i), KPC(schema));
        } else if (column_schema->is_doc_id_column()) {
          doc_id_col_id_ = column_schema->get_column_id();
        }
      }
    } else if (schema->is_vec_index_id_type()) {
      if (OB_FAIL(ob_write_string(allocator_, schema->get_index_params(), vec_index_param_))) {
      }
    }

    if (OB_FAIL(ret)) {
      // do nothing
    } else if (OB_FAIL(schema->get_index_name(tmp_name))) {
    } else if (OB_FAIL(ob_write_string(allocator_, tmp_name, index_name_))) {
    }
  }

  bool need_truncate_filter = nullptr != schema && schema->is_global_index_table();
  if (OB_FAIL(ret)) {
  } else if (need_truncate_filter) {
    if (OB_FAIL(schema->get_mulit_version_rowkey_column_ids(all_column_ids))) {
    } else if (OB_FAIL(schema->get_column_ids_without_rowkey(all_column_ids, false))) {
    }
  } else if (OB_FAIL(schema->get_column_ids(all_column_ids, false))) {
  }
  int32_t virtual_cols_cnt = 0;
  int64_t schema_rowkey_cnt = schema->get_rowkey_column_num();
  for (int32_t i = 0; OB_SUCC(ret) && i < all_column_ids.count(); ++i) {
    int32_t col_index = OB_INVALID_INDEX;
    const uint64_t column_id = all_column_ids.at(i).col_id_;
    const ObColumnSchemaV2 *column_schema = NULL;
    ObColumnParam *column = NULL;
    if (OB_FAIL(ObTableParam::alloc_column(allocator_, column))) {
    } else if (common::OB_HIDDEN_TRANS_VERSION_COLUMN_ID == column_id ||
               common::OB_HIDDEN_SQL_SEQUENCE_COLUMN_ID == column_id) {
        column->set_column_id(column_id);
        column->set_meta_type(all_column_ids.at(i).col_type_);
        col_index = -1;
    } else if (OB_ISNULL(column_schema = schema->get_column_schema(column_id))) {
      ret = OB_ERR_UNEXPECTED;
      LOG_WARN("The column is NULL", K(schema->get_table_id()), K(column_id), K(i));
    } else if(OB_FAIL(ObTableParam::convert_column_schema_to_param(*column_schema, *column))) {
    } else if (i < schema_rowkey_cnt) {
      col_index = i;
    } else if (nullptr != column_schema && column_schema->is_virtual_generated_column()) {
      col_index = -1;
      virtual_cols_cnt++;
    } else {
      col_index = need_truncate_filter ? i - virtual_cols_cnt - storage::ObMultiVersionRowkeyHelpper::get_extra_rowkey_col_cnt() :
                                         i - virtual_cols_cnt;
    }

    if (FAILEDx(tmp_cols.push_back(column))) {
      LOG_WARN("store tmp column param failed", K(ret));
    } else if (OB_FAIL(tmp_col_descs.push_back(all_column_ids.at(i)))) {
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(tmp_cols_index.push_back(col_index))) {
      }
    }
  }

  if (OB_SUCC(ret)) {
    if (OB_FAIL(columns_.assign(tmp_cols))) {
    } else if (OB_FAIL(read_info_.init(
                allocator_,
                schema->get_column_count(),
                schema_rowkey_cnt,
                tmp_col_descs,
                &tmp_cols_index,
                &tmp_cols,
                nullptr/*cols_extend*/,
                need_truncate_filter))) {
    } else if (!col_map_.is_inited()) {
      if (OB_FAIL(col_map_.init(tmp_cols))) {
      }
    }
  }
  return ret;
}

int ObTableSchemaParam::is_rowkey_column(const uint64_t column_id, bool &is_rowkey) const
{
  int ret = OB_SUCCESS;
  int32_t idx = -1;
  if (OB_FAIL(col_map_.get(column_id, idx)) && OB_HASH_NOT_EXIST != ret) {
    LOG_WARN("get idx from column map fail", K(ret), K(column_id));
  } else {
    is_rowkey = (idx >= 0 && idx < read_info_.get_schema_rowkey_count());
  }
  return ret;
}

int ObTableSchemaParam::is_column_nullable_for_write(const uint64_t column_id,
                                                     bool &is_nullable_for_write) const
{
  int ret = OB_SUCCESS;
  int32_t idx = -1;
  if (OB_FAIL(col_map_.get(column_id, idx)) && OB_HASH_NOT_EXIST != ret) {
    LOG_WARN("get idx from column map fail", K(ret), K(column_id));
  } else if (idx < 0) {
    ret = OB_SCHEMA_ERROR;
    LOG_WARN("column not exist", K(ret), K(column_id));
  } else {
    is_nullable_for_write = columns_.at(idx)->is_nullable_for_write();
  }
  return ret;
}

const ObColumnParam * ObTableSchemaParam::get_column(const uint64_t column_id) const
{
  int ret = OB_SUCCESS;
  const ObColumnParam * ptr = NULL;
  int32_t idx = -1;
  if (OB_FAIL(col_map_.get(column_id, idx)) && OB_HASH_NOT_EXIST != ret) {
    LOG_WARN("get idx from column map fail", K(ret), K(column_id));
  } else if (idx < 0) {
    // do nothing
  } else {
    ptr = get_column_by_idx(idx);
  }
  return ptr;
}

const ObColumnParam * ObTableSchemaParam::get_column_by_idx(const int64_t idx) const
{
  const ObColumnParam * ptr = NULL;
  if (idx < 0 || idx >= columns_.count()) {
    LOG_WARN_RET(OB_INVALID_ARGUMENT, "idx out of range", K(idx), K(columns_.count()), K(lbt()));
  } else {
    ptr = columns_.at(idx);
  }
  return ptr;
}

ObColumnParam * ObTableSchemaParam::get_column_by_idx(const int64_t idx)
{
  ObColumnParam * ptr = NULL;
  if (idx < 0 || idx >= columns_.count()) {
    LOG_WARN_RET(OB_INVALID_ARGUMENT, "idx out of range", K(idx), K(columns_.count()), K(lbt()));
  } else {
    ptr = columns_.at(idx);
  }
  return ptr;
}

const ObColumnParam * ObTableSchemaParam::get_rowkey_column_by_idx(const int64_t idx) const
{
  const ObColumnParam * ptr = NULL;
  if (idx < 0 || idx >= read_info_.get_schema_rowkey_count()) {
    LOG_WARN_RET(OB_INVALID_ARGUMENT, "idx out of range", K(idx), K(read_info_.get_schema_rowkey_count()));
  } else {
    ptr = columns_.at(idx);
  }
  return ptr;
}

int ObTableSchemaParam::get_rowkey_column_ids(ObIArray<ObColDesc> &column_ids) const
{
  int ret = OB_SUCCESS;
  if (!is_valid()) {
    ret = OB_NOT_INIT;
    LOG_WARN("param not inited", K(ret), K(*this));
  } else {
    const ObColumnParam *param = NULL;
    ObColDesc col_desc;
    for (int64_t i = 0; OB_SUCC(ret) && i < read_info_.get_schema_rowkey_count(); ++i) {
      if (OB_ISNULL(param = columns_.at(i))) {
        ret = OB_ERR_UNEXPECTED;
        LOG_WARN("column param is NULL", K(ret), K(i));
      } else {
        col_desc.col_id_ = static_cast<uint32_t>(param->get_column_id());
        col_desc.col_order_ = param->get_column_order();
        col_desc.col_type_ = param->get_meta_type();
        col_desc.col_type_.set_scale(param->get_accuracy().get_scale());
        if (OB_FAIL(column_ids.push_back(col_desc))) {
        }
      }
    }
  }
  return ret;
}

int ObTableSchemaParam::get_rowkey_column_ids(ObIArray<uint64_t> &column_ids) const
{
  int ret = OB_SUCCESS;
  if (!is_valid()) {
    ret = OB_NOT_INIT;
    LOG_WARN("param not inited", K(ret), K(*this));
  } else {
    const ObColumnParam *param = NULL;
    for (int64_t i = 0; OB_SUCC(ret) && i < read_info_.get_schema_rowkey_count(); ++i) {
      if (OB_ISNULL(param = columns_.at(i))) {
        ret = OB_ERR_UNEXPECTED;
        LOG_WARN("column param is NULL", K(ret), K(i));
      } else if (OB_FAIL(column_ids.push_back(param->get_column_id()))) {
      }
    }
  }
  return ret;
}

int ObTableSchemaParam::get_index_name(common::ObString &index_name) const
{
  int ret = OB_SUCCESS;
  if (!is_index_table()) {
    ret = OB_SCHEMA_ERROR;
    LOG_WARN("table is not index table", K(ret), K(table_id_), K(table_type_));
  } else {
    index_name.assign_ptr(index_name_.ptr(), index_name_.length());
  }
  return ret;
}

const ObString &ObTableSchemaParam::get_pk_name() const
{
  return pk_name_;
}

int ObTableSchemaParam::get_typed_doc_id_col_id(uint64_t &doc_id_col_id, ObDocIDType &type) const
{
  int ret = OB_SUCCESS;
  if ((doc_id_col_id_ != OB_INVALID_ID && inc_pk_doc_id_col_id_ != OB_INVALID_ID)
      || (doc_id_col_id_ == OB_INVALID_ID && inc_pk_doc_id_col_id_ == OB_INVALID_ID)) {
    ret = OB_ERR_UNEXPECTED;
    LOG_WARN("One and only one id should be valid", K(ret), K(doc_id_col_id_), K(inc_pk_doc_id_col_id_));
  } else if (doc_id_col_id_ != OB_INVALID_ID) {
    doc_id_col_id = doc_id_col_id_;
    type = ObDocIDType::TABLET_SEQUENCE;
  } else if (inc_pk_doc_id_col_id_ != OB_INVALID_ID) {
    doc_id_col_id = inc_pk_doc_id_col_id_;
    type = ObDocIDType::HIDDEN_INC_PK;
  }
  return ret;
}

int64_t ObTableSchemaParam::to_string(char *buf, const int64_t buf_len) const
{
  int64_t pos = 0;
  J_OBJ_START();
  J_KV(K_(table_id),
       K_(schema_version),
       K_(table_type),
       K_(index_type),
       K_(index_status),
       K_(shadow_rowkey_column_num),
       K_(doc_id_col_id),
       K_(fulltext_col_id),
       K_(index_name),
       K_(fts_parser_name),
       K_(fts_parser_properties),
       K_(pk_name),
       K_(columns),
       K_(read_info),
       K_(lob_inrow_threshold),
       K_(inc_pk_doc_id_col_id));

  J_OBJ_END();
  return pos;
}

OB_DEF_SERIALIZE(ObTableSchemaParam)
{
  int ret = OB_SUCCESS;
  LST_DO_CODE(OB_UNIS_ENCODE,
              table_id_,
              schema_version_,
              table_type_,
              index_type_,
              index_status_,
              shadow_rowkey_column_num_,
              fulltext_col_id_);

  if (OB_SUCC(ret)) {
    if (OB_FAIL(index_name_.serialize(buf, buf_len, pos))) {
    } else if (OB_FAIL(ObTableParam::serialize_columns(columns_, buf, buf_len, pos))) {
    }
  }
  OB_UNIS_ENCODE(read_info_);
  if (OB_SUCC(ret)) {
    if (OB_FAIL(pk_name_.serialize(buf, buf_len, pos))) {
    }
  }
  OB_UNIS_ENCODE(spatial_geo_col_id_);
  OB_UNIS_ENCODE(spatial_cellid_col_id_);
  OB_UNIS_ENCODE(spatial_mbr_col_id_);
  OB_UNIS_ENCODE(lob_inrow_threshold_);
  OB_UNIS_ENCODE(multivalue_col_id_);
  OB_UNIS_ENCODE(multivalue_arr_col_id_);
  OB_UNIS_ENCODE(data_table_rowkey_column_num_);
  OB_UNIS_ENCODE(doc_id_col_id_);
  if (OB_SUCC(ret)) {
    if (OB_FAIL(fts_parser_name_.serialize(buf, buf_len, pos))) {
    }
  }
  OB_UNIS_ENCODE(vec_id_col_id_);
  if (OB_SUCC(ret)) {
    if (OB_FAIL(vec_index_param_.serialize(buf, buf_len, pos))) {
    }
  }
  OB_UNIS_ENCODE(vec_dim_);
  OB_UNIS_ENCODE(vec_vector_col_id_);
  if (FAILEDx(fts_parser_properties_.serialize(buf, buf_len, pos))) {
    LOG_WARN("fail to serialize fts parser properties", K(ret));
  }
  OB_UNIS_ENCODE(inc_pk_doc_id_col_id_);
  OB_UNIS_ENCODE(vec_chunk_col_id_);
  OB_UNIS_ENCODE(vec_embedded_col_id_);
  OB_UNIS_ENCODE(has_async_index_);
  return ret;
}

OB_DEF_DESERIALIZE(ObTableSchemaParam)
{
  int ret = OB_SUCCESS;
  LST_DO_CODE(OB_UNIS_DECODE,
              table_id_,
              schema_version_,
              table_type_,
              index_type_,
              index_status_,
              shadow_rowkey_column_num_,
              fulltext_col_id_);

  if (OB_SUCC(ret)) {
    ObString tmp_name;
    if (OB_FAIL(tmp_name.deserialize(buf, data_len, pos))) {
    } else if (OB_FAIL(ob_write_string(allocator_, tmp_name, index_name_))) {
    } else if (OB_FAIL(ObTableParam::deserialize_columns(buf, data_len, pos, columns_, allocator_))) {
    } else if (!col_map_.is_inited()) {
      if (OB_FAIL(col_map_.init(columns_))) {
      }
    }
  }
  if (OB_SUCC(ret) && OB_FAIL(read_info_.deserialize(allocator_, buf, data_len, pos))) {
    LOG_WARN("Fail to deserialize read_info", K(ret));
  }
  if (OB_SUCC(ret)) {
    ObString tmp_name;
    if (OB_FAIL(tmp_name.deserialize(buf, data_len, pos))) {
    } else if (OB_FAIL(ob_write_string(allocator_, tmp_name, pk_name_))) {
    }
  }
  OB_UNIS_DECODE(spatial_geo_col_id_);
  OB_UNIS_DECODE(spatial_cellid_col_id_);
  OB_UNIS_DECODE(spatial_mbr_col_id_);
  OB_UNIS_DECODE(lob_inrow_threshold_);

  OB_UNIS_DECODE(multivalue_col_id_);
  OB_UNIS_DECODE(multivalue_arr_col_id_);
  OB_UNIS_DECODE(data_table_rowkey_column_num_);
  OB_UNIS_DECODE(doc_id_col_id_);

  if (OB_SUCC(ret)) {
    ObString tmp_name;
    if (OB_FAIL(tmp_name.deserialize(buf, data_len, pos))) {
    } else if (OB_FAIL(ob_write_string(allocator_, tmp_name, fts_parser_name_))) {
    }
  }
  OB_UNIS_DECODE(vec_id_col_id_);
  if (OB_SUCC(ret)) {
    ObString tmp_vec_index_param;
    if (OB_FAIL(tmp_vec_index_param.deserialize(buf, data_len, pos))) {
    } else if (OB_FAIL(ob_write_string(allocator_, tmp_vec_index_param, vec_index_param_))) {
    }
  }
  OB_UNIS_DECODE(vec_dim_);
  OB_UNIS_DECODE(vec_vector_col_id_);
  if (OB_SUCC(ret)) {
    ObString tmp_properties;
    if (OB_FAIL(tmp_properties.deserialize(buf, data_len, pos))) {
    } else if (OB_FAIL(ob_write_string(allocator_, tmp_properties, fts_parser_properties_))) {
    }
  }
  OB_UNIS_DECODE(inc_pk_doc_id_col_id_);
  OB_UNIS_DECODE(vec_chunk_col_id_);
  OB_UNIS_DECODE(vec_embedded_col_id_);
  if (OB_SUCC(ret) && OB_FAIL(serialization::decode_bool(buf, data_len, pos, &has_async_index_))) {
    LOG_WARN("fail to deserialize async index flag", K(ret), K(data_len), K(pos));
  } else if (OB_SUCC(ret) && OB_UNLIKELY(pos != data_len)) {
    ret = OB_VERSION_NOT_MATCH;
    LOG_WARN("table schema param format mismatch", K(ret), K(data_len), K(pos));
  }
  return ret;
}

OB_DEF_SERIALIZE_SIZE(ObTableSchemaParam)
{
  int ret = OB_SUCCESS;
  int64_t len = 0;

  LST_DO_CODE(OB_UNIS_ADD_LEN,
              table_id_,
              schema_version_,
              table_type_,
              index_type_,
              index_status_,
              shadow_rowkey_column_num_,
              fulltext_col_id_);
  len += index_name_.get_serialize_size();

  if (OB_SUCC(ret)) {
    int64_t columns_size = 0;
    if (OB_FAIL(ObTableParam::get_columns_serialize_size(columns_, columns_size))) {
    } else {
      len += columns_size;
    }
  }
  OB_UNIS_ADD_LEN(read_info_);
  len += pk_name_.get_serialize_size();
  OB_UNIS_ADD_LEN(spatial_geo_col_id_);
  OB_UNIS_ADD_LEN(spatial_cellid_col_id_);
  OB_UNIS_ADD_LEN(spatial_mbr_col_id_);
  OB_UNIS_ADD_LEN(lob_inrow_threshold_);

  OB_UNIS_ADD_LEN(multivalue_col_id_);
  OB_UNIS_ADD_LEN(multivalue_arr_col_id_);
  OB_UNIS_ADD_LEN(data_table_rowkey_column_num_);
  OB_UNIS_ADD_LEN(doc_id_col_id_);
  len += fts_parser_name_.get_serialize_size();
  OB_UNIS_ADD_LEN(vec_id_col_id_);
  len += vec_index_param_.get_serialize_size();
  OB_UNIS_ADD_LEN(vec_dim_);
  OB_UNIS_ADD_LEN(vec_vector_col_id_);
  len += fts_parser_properties_.get_serialize_size();
  OB_UNIS_ADD_LEN(inc_pk_doc_id_col_id_);
  OB_UNIS_ADD_LEN(vec_chunk_col_id_);
  OB_UNIS_ADD_LEN(vec_embedded_col_id_);
  OB_UNIS_ADD_LEN(has_async_index_);
  return len;
}

int ObTableSchemaParam::has_udf_column(bool &has_udf) const
{
  int ret = OB_SUCCESS;
  has_udf = false;
  const ObColumnParam *param = nullptr;
  for (int64_t i = 0; OB_SUCC(ret) && i < columns_.count() && !has_udf; ++i) {
    if (OB_ISNULL(param = columns_.at(i))) {
      ret = OB_ERR_UNEXPECTED;
      LOG_WARN("get column failed", K(ret), KP(param));
    } else {
      has_udf = param->is_gen_col_udf_expr();
    }
  }
  return ret;
}

// ------ ObTableDMLParam ------ //
ObTableDMLParam::ObTableDMLParam(common::ObIAllocator &allocator)
  : allocator_(allocator),
    runtime_schema_version_(OB_INVALID_VERSION),
    data_table_(allocator),
    col_descs_(allocator),
    col_map_(allocator)
{
}

ObTableDMLParam::~ObTableDMLParam()
{
  reset();
}

void ObTableDMLParam::reset()
{
  runtime_schema_version_ = OB_INVALID_VERSION;
  data_table_.reset();
}

int ObTableDMLParam::convert(const ObTableSchema *table_schema,
                             const int64_t runtime_schema_version,
                             const common::ObIArray<uint64_t> &column_ids)
{
  int ret = OB_SUCCESS;
  const ObTableSchema *schema = NULL;
  if (OB_ISNULL(table_schema) || OB_INVALID_VERSION == runtime_schema_version) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid argument", K(ret), K(runtime_schema_version), KP(table_schema));
  } else if (OB_FAIL(data_table_.convert(table_schema))) {
  } else if (OB_FAIL(prepare_storage_param(column_ids))) {
  } else {
    runtime_schema_version_ = runtime_schema_version;
  }
  return ret;
}

int64_t ObTableDMLParam::to_string(char *buf, const int64_t buf_len) const
{
  int64_t pos = 0;
  J_OBJ_START();
  J_KV(K_(runtime_schema_version),
       K_(data_table),
       K_(col_descs),
       K_(col_map)
       );
  J_OBJ_END();

  return pos;
}

OB_DEF_SERIALIZE(ObTableDMLParam)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(buf) || buf_len <= 0 || pos < 0) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid arguments", K(ret), KP(buf), K(buf_len), K(pos));
  } else {
    LST_DO_CODE(OB_UNIS_ENCODE, runtime_schema_version_);
  }

  if (OB_SUCC(ret)) {
    if (OB_FAIL(data_table_.serialize(buf, buf_len, pos))) {
    }
  }
  OB_UNIS_ENCODE(col_descs_);
  return ret;
}

OB_DEF_DESERIALIZE(ObTableDMLParam)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(buf) || data_len <= 0 || pos < 0) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid arguments", K(ret), KP(buf), K(data_len), K(pos));
  } else {
    LST_DO_CODE(OB_UNIS_DECODE, runtime_schema_version_);
  }

  if (OB_SUCC(ret)) {
    if (OB_FAIL(data_table_.deserialize(buf, data_len, pos))) {
    }
  }
  OB_UNIS_DECODE(col_descs_);
  if (OB_SUCC(ret) && !col_descs_.empty()) {
    if (OB_FAIL(col_map_.init(col_descs_))) {
    }
  }
  return ret;
}

OB_DEF_SERIALIZE_SIZE(ObTableDMLParam)
{
  int ret = OB_SUCCESS;
  int64_t len = 0;
  int64_t size = 0;
  LST_DO_CODE(OB_UNIS_ADD_LEN, runtime_schema_version_);
  len += data_table_.get_serialize_size();
  OB_UNIS_ADD_LEN(col_descs_);
  return len;
}

int ObTableDMLParam::prepare_storage_param(const ObIArray<uint64_t> &column_ids)
{
  int ret = OB_SUCCESS;
  const int64_t col_cnt = column_ids.count();
  if (col_cnt <= 0 || col_cnt > UINT32_MAX) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid column_ids", K(ret), K(col_cnt));
  } else {
    const ObColumnParam *col_param = nullptr;
    uint64_t column_id = OB_INVALID_ID;
    ObColDesc col_desc;
    col_descs_.set_capacity(static_cast<uint32_t>(col_cnt));
    for (int64_t i = 0; OB_SUCC(ret) && i < col_cnt; ++i) {
      column_id = column_ids.at(i);
      if (nullptr == (col_param = data_table_.get_column(column_id))) {
        ret = OB_INVALID_ARGUMENT;
        LOG_WARN("get column param fail", K(ret), K(column_id), KP(col_param));
      } else {
        col_desc.col_id_ = static_cast<uint32_t>(column_id);
        col_desc.col_type_ = col_param->get_meta_type();
        col_desc.col_type_.set_scale(col_param->get_accuracy().get_scale());
        col_desc.col_order_ = col_param->get_column_order();
        if (OB_FAIL(col_descs_.push_back(col_desc))) {
        }
      }
    }

    // assign
    if (OB_SUCC(ret)) {
      if (OB_FAIL(col_map_.init(col_descs_))) {
      }
    }
  }
  return ret;
}

int ObTableDMLParam::set_data_table_rowkey_tags(share::schema::ObSchemaGetterGuard *guard,
                                                const ObTableSchema *index_schema)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(nullptr == guard || nullptr == index_schema)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid guard or index schema", K(ret), KP(guard), KP(index_schema));
  } else {
    const ObTableSchema *data_table_schema = index_schema;
    common::ObSEArray<uint64_t, 4> data_table_rowkey_cids;
    const common::ObIArray<ObColumnParam *> &columns = data_table_.get_columns();
    if (index_schema->is_index_table()) {
      if (OB_FAIL(guard->get_table_schema( index_schema->get_data_table_id(), data_table_schema))) {
      } else if (OB_ISNULL(data_table_schema)) {
        ret = OB_SCHEMA_ERROR;
        LOG_WARN("data table schema is NULL", K(ret), KP(data_table_schema), K(index_schema->get_data_table_id()));
      }
    }
    if (OB_SUCC(ret)) {
      if (OB_FAIL(data_table_schema->get_rowkey_column_ids(data_table_rowkey_cids))) {
      }
      for (int64_t i = 0; OB_SUCC(ret) && i < columns.count(); ++i) {
        if (OB_ISNULL(columns.at(i))) {
          ret = OB_ERR_UNEXPECTED;
          LOG_WARN("column param is null", K(ret), K(i), KP(columns.at(i)));
        } else {
          const uint64_t col_id = is_shadow_column(columns.at(i)->get_column_id()) ?
                                  columns.at(i)->get_column_id() - OB_MIN_SHADOW_COLUMN_ID :
                                  columns.at(i)->get_column_id();
          columns.at(i)->set_is_data_table_rowkey(has_exist_in_array(data_table_rowkey_cids, col_id));
        }
      }
    }
  }
  return ret;
}

}//namespace oceanbase
}//namespace share
}//namespace schema

namespace oceanbase
{
namespace data_plane
{

class ObStorageDmlTablePlanState final : public ObIDmlTablePlanState
{
public:
  explicit ObStorageDmlTablePlanState(common::ObIAllocator &allocator)
    : allocator_(allocator), legacy_(allocator)
  {}
  virtual ~ObStorageDmlTablePlanState() {}

  void destroy() override
  {
    common::ObIAllocator &allocator = allocator_;
    this->~ObStorageDmlTablePlanState();
    allocator.free(this);
  }
  void reset() override { legacy_.reset(); }
  bool is_valid() const override { return legacy_.is_valid(); }
  int build(const share::schema::ObTableSchema *table_schema,
            const int64_t tenant_schema_version,
            const common::ObIArray<uint64_t> &column_ids) override
  {
    return legacy_.convert(table_schema, tenant_schema_version, column_ids);
  }
  int set_data_table_rowkey_tags(share::schema::ObSchemaGetterGuard *guard,
                                 const share::schema::ObTableSchema *index_schema) override
  {
    return legacy_.set_data_table_rowkey_tags(guard, index_schema);
  }
  int configure_multivalue_index(const int64_t data_table_rowkey_column_num) override
  {
    int ret = common::OB_SUCCESS;
    share::schema::ObTableSchemaParam &table_param = legacy_.get_data_table_ref();
    table_param.set_data_table_rowkey_column_num(data_table_rowkey_column_num);
    const int64_t column_count = table_param.get_column_count();
    for (int64_t i = column_count - 2; common::OB_SUCCESS == ret && i >= 0; --i) {
      share::schema::ObColumnParam *column = table_param.get_column_by_idx(i);
      if (nullptr == column) {
        ret = common::OB_ERR_UNEXPECTED;
      } else {
        column->set_nullable_for_write(true);
      }
    }
    return ret;
  }
  void set_has_async_index(const bool has_async_index) override
  {
    legacy_.get_data_table_ref().set_has_async_index(has_async_index);
  }
  const common::ObIArray<share::schema::ObColDesc> &get_col_descs() const override
  {
    return legacy_.get_col_descs();
  }
  int serialize(char *buf, const int64_t buf_len, int64_t &pos) const override
  {
    return legacy_.serialize(buf, buf_len, pos);
  }
  int deserialize(const char *buf, const int64_t data_len, int64_t &pos) override
  {
    return legacy_.deserialize(buf, data_len, pos);
  }
  int64_t get_serialize_size() const override { return legacy_.get_serialize_size(); }
  int64_t to_string(char *buf, const int64_t buf_len) const override
  {
    return legacy_.to_string(buf, buf_len);
  }

  uint64_t get_table_id() const override { return legacy_.get_data_table().get_table_id(); }
  int64_t get_schema_version() const override { return legacy_.get_data_table().get_schema_version(); }
  share::schema::ObIndexType get_index_type() const override { return legacy_.get_data_table().get_index_type(); }
  int64_t get_rowkey_column_num() const override { return legacy_.get_data_table().get_rowkey_column_num(); }
  int64_t get_data_table_rowkey_column_num() const override
  { return legacy_.get_data_table().get_data_table_rowkey_column_num(); }
  int64_t get_fulltext_col_id() const override { return legacy_.get_data_table().get_fulltext_col_id(); }
  int get_typed_doc_id_col_id(uint64_t &doc_id_col_id, ObDocIDType &type) const override
  { return legacy_.get_data_table().get_typed_doc_id_col_id(doc_id_col_id, type); }
  const common::ObString &get_fts_parser_name() const override
  { return legacy_.get_data_table().get_fts_parser_name(); }
  const common::ObString &get_fts_parser_property() const override
  { return legacy_.get_data_table().get_fts_parser_property(); }
  const common::ObString &get_index_name() const override
  { return legacy_.get_data_table().get_index_name(); }
  uint64_t get_spatial_geo_col_id() const override
  { return legacy_.get_data_table().get_spatial_geo_col_id(); }
  int64_t get_multivalue_col_id() const override
  { return legacy_.get_data_table().get_multivalue_col_id(); }
  int64_t get_multivalue_array_col_id() const override
  { return legacy_.get_data_table().get_multivalue_array_col_id(); }
  int64_t get_vec_id_col_id() const override { return legacy_.get_data_table().get_vec_id_col_id(); }
  int64_t get_vec_chunk_col_id() const override { return legacy_.get_data_table().get_vec_chunk_col_id(); }
  int64_t get_embedded_vec_col_id() const override { return legacy_.get_data_table().get_embedded_vec_col_id(); }
  int64_t get_vec_vector_col_id() const override { return legacy_.get_data_table().get_vec_vector_col_id(); }
  common::ObString get_vec_index_param() const override { return legacy_.get_data_table().get_vec_index_param(); }

#define OB_STORAGE_DML_TABLE_BOOL_METHOD(METHOD) \
  bool METHOD() const override { return legacy_.get_data_table().METHOD(); }
  OB_STORAGE_DML_TABLE_BOOL_METHOD(has_async_index)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(can_read_index)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_storage_index_table)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_unique_index)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_domain_index)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_spatial_index)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_fts_index)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_fts_index_aux)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_fts_doc_word_aux)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_multivalue_index)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_multivalue_index_aux)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_index_local_storage)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_vector_delta_buffer)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_vector_index_id)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_vector_index)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_sparse_vector_index)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_ivf_vector_index)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_hybrid_vector_index)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_hybrid_vector_index_log)
  OB_STORAGE_DML_TABLE_BOOL_METHOD(is_no_need_update_vector_index)
#undef OB_STORAGE_DML_TABLE_BOOL_METHOD

  common::ObIAllocator &allocator_;
  share::schema::ObTableDMLParam legacy_;
};

namespace
{
const ObIDmlTablePlanState *table_view(const ObIDmlTablePlanState *state)
{
  return state;
}
}

ObDmlTablePlan::ObDmlTablePlan(common::ObIAllocator &allocator)
  : allocator_(allocator), state_(nullptr)
{
  void *buf = allocator_.alloc(sizeof(ObStorageDmlTablePlanState));
  if (nullptr != buf) {
    state_ = new (buf) ObStorageDmlTablePlanState(allocator_);
  }
}

ObDmlTablePlan::~ObDmlTablePlan()
{
  if (nullptr != state_) {
    state_->destroy();
    state_ = nullptr;
  }
}

void ObDmlTablePlan::reset()
{
  if (nullptr != state_) {
    state_->reset();
  }
}

bool ObDmlTablePlan::is_valid() const
{
  return nullptr != state_ && state_->is_valid();
}

int ObDmlTablePlan::build(const share::schema::ObTableSchema *table_schema,
                          const int64_t tenant_schema_version,
                          const common::ObIArray<uint64_t> &column_ids)
{
  return nullptr == state_
      ? common::OB_ALLOCATE_MEMORY_FAILED
      : state_->build(table_schema, tenant_schema_version, column_ids);
}

int ObDmlTablePlan::set_data_table_rowkey_tags(
    share::schema::ObSchemaGetterGuard *guard,
    const share::schema::ObTableSchema *index_schema)
{
  return nullptr == state_
      ? common::OB_ALLOCATE_MEMORY_FAILED
      : state_->set_data_table_rowkey_tags(guard, index_schema);
}

int ObDmlTablePlan::configure_multivalue_index(const int64_t data_table_rowkey_column_num)
{
  return nullptr == state_
      ? common::OB_ALLOCATE_MEMORY_FAILED
      : state_->configure_multivalue_index(data_table_rowkey_column_num);
}

void ObDmlTablePlan::set_has_async_index(const bool has_async_index)
{
  if (nullptr != state_) {
    state_->set_has_async_index(has_async_index);
  }
}

ObDmlTableView ObDmlTablePlan::get_data_table() const
{
  return ObDmlTableView(state_);
}

const common::ObIArray<share::schema::ObColDesc> &ObDmlTablePlan::get_col_descs() const
{
  if (nullptr == state_) {
    static const common::ObSEArray<share::schema::ObColDesc, 1> EMPTY_COLUMN_DESCRIPTORS;
    return EMPTY_COLUMN_DESCRIPTORS;
  }
  return state_->get_col_descs();
}

int ObDmlTablePlan::serialize(char *buf, const int64_t buf_len, int64_t &pos) const
{
  return nullptr == state_
      ? common::OB_ALLOCATE_MEMORY_FAILED
      : state_->serialize(buf, buf_len, pos);
}

int ObDmlTablePlan::deserialize(const char *buf, const int64_t data_len, int64_t &pos)
{
  return nullptr == state_
      ? common::OB_ALLOCATE_MEMORY_FAILED
      : state_->deserialize(buf, data_len, pos);
}

int64_t ObDmlTablePlan::get_serialize_size() const
{
  return nullptr == state_ ? 0 : state_->get_serialize_size();
}

int64_t ObDmlTablePlan::to_string(char *buf, const int64_t buf_len) const
{
  return nullptr == state_ ? 0 : state_->to_string(buf, buf_len);
}

bool ObDmlTableView::is_valid() const
{
  return nullptr != table_view(state_) && table_view(state_)->is_valid();
}

uint64_t ObDmlTableView::get_table_id() const
{
  return nullptr == table_view(state_) ? common::OB_INVALID_ID : table_view(state_)->get_table_id();
}

int64_t ObDmlTableView::get_schema_version() const
{
  return nullptr == table_view(state_) ? common::OB_INVALID_VERSION : table_view(state_)->get_schema_version();
}

share::schema::ObIndexType ObDmlTableView::get_index_type() const
{
  return nullptr == table_view(state_) ? share::schema::INDEX_TYPE_IS_NOT : table_view(state_)->get_index_type();
}

int64_t ObDmlTableView::get_rowkey_column_num() const
{
  return nullptr == table_view(state_) ? 0 : table_view(state_)->get_rowkey_column_num();
}

int64_t ObDmlTableView::get_data_table_rowkey_column_num() const
{
  return nullptr == table_view(state_) ? 0 : table_view(state_)->get_data_table_rowkey_column_num();
}

int64_t ObDmlTableView::get_fulltext_col_id() const
{
  return nullptr == table_view(state_) ? common::OB_INVALID_ID : table_view(state_)->get_fulltext_col_id();
}

int ObDmlTableView::get_typed_doc_id_col_id(uint64_t &doc_id_col_id, ObDocIDType &type) const
{
  return nullptr == table_view(state_)
      ? common::OB_INVALID_ARGUMENT
      : table_view(state_)->get_typed_doc_id_col_id(doc_id_col_id, type);
}

const common::ObString &ObDmlTableView::get_fts_parser_name() const
{
  static const common::ObString EMPTY;
  return nullptr == table_view(state_) ? EMPTY : table_view(state_)->get_fts_parser_name();
}

const common::ObString &ObDmlTableView::get_fts_parser_property() const
{
  static const common::ObString EMPTY;
  return nullptr == table_view(state_) ? EMPTY : table_view(state_)->get_fts_parser_property();
}

const common::ObString &ObDmlTableView::get_index_name() const
{
  static const common::ObString EMPTY;
  return nullptr == table_view(state_) ? EMPTY : table_view(state_)->get_index_name();
}

uint64_t ObDmlTableView::get_spatial_geo_col_id() const
{
  return nullptr == table_view(state_) ? common::OB_INVALID_ID : table_view(state_)->get_spatial_geo_col_id();
}

int64_t ObDmlTableView::get_multivalue_col_id() const
{
  return nullptr == table_view(state_) ? common::OB_INVALID_ID : table_view(state_)->get_multivalue_col_id();
}

int64_t ObDmlTableView::get_multivalue_array_col_id() const
{
  return nullptr == table_view(state_) ? common::OB_INVALID_ID : table_view(state_)->get_multivalue_array_col_id();
}

int64_t ObDmlTableView::get_vec_id_col_id() const
{
  return nullptr == table_view(state_) ? common::OB_INVALID_ID : table_view(state_)->get_vec_id_col_id();
}

int64_t ObDmlTableView::get_vec_chunk_col_id() const
{
  return nullptr == table_view(state_) ? common::OB_INVALID_ID : table_view(state_)->get_vec_chunk_col_id();
}

int64_t ObDmlTableView::get_embedded_vec_col_id() const
{
  return nullptr == table_view(state_) ? common::OB_INVALID_ID : table_view(state_)->get_embedded_vec_col_id();
}

int64_t ObDmlTableView::get_vec_vector_col_id() const
{
  return nullptr == table_view(state_) ? common::OB_INVALID_ID : table_view(state_)->get_vec_vector_col_id();
}

common::ObString ObDmlTableView::get_vec_index_param() const
{
  return nullptr == table_view(state_) ? common::ObString() : table_view(state_)->get_vec_index_param();
}

#define OB_DML_TABLE_VIEW_BOOL_METHOD(METHOD) \
  bool ObDmlTableView::METHOD() const \
  { \
    return nullptr != table_view(state_) && table_view(state_)->METHOD(); \
  }

OB_DML_TABLE_VIEW_BOOL_METHOD(has_async_index)
OB_DML_TABLE_VIEW_BOOL_METHOD(can_read_index)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_storage_index_table)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_unique_index)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_domain_index)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_spatial_index)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_fts_index)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_fts_index_aux)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_fts_doc_word_aux)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_multivalue_index)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_multivalue_index_aux)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_index_local_storage)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_vector_delta_buffer)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_vector_index_id)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_vector_index)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_sparse_vector_index)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_ivf_vector_index)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_hybrid_vector_index)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_hybrid_vector_index_log)
OB_DML_TABLE_VIEW_BOOL_METHOD(is_no_need_update_vector_index)

#undef OB_DML_TABLE_VIEW_BOOL_METHOD

int64_t ObDmlTableView::to_string(char *buf, const int64_t buf_len) const
{
  return nullptr == table_view(state_) ? 0 : table_view(state_)->to_string(buf, buf_len);
}

} // namespace data_plane
} // namespace oceanbase

namespace oceanbase
{
namespace storage
{

share::schema::ObTableDMLParam *ObDmlTablePlanAccess::get(data_plane::ObDmlTablePlan &plan)
{
  data_plane::ObStorageDmlTablePlanState *state =
      static_cast<data_plane::ObStorageDmlTablePlanState *>(
          data_plane::ObDmlTablePlanAccess::state(plan));
  return nullptr == state ? nullptr : &state->legacy_;
}

const share::schema::ObTableDMLParam *ObDmlTablePlanAccess::get(
    const data_plane::ObDmlTablePlan &plan)
{
  const data_plane::ObStorageDmlTablePlanState *state =
      static_cast<const data_plane::ObStorageDmlTablePlanState *>(
          data_plane::ObDmlTablePlanAccess::state(plan));
  return nullptr == state ? nullptr : &state->legacy_;
}

} // namespace storage
} // namespace oceanbase
