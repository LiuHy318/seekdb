/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEABASE_SHARE_THROTTLE_OB_SHARE_THROTTLE_DEFINE_H
#define OCEABASE_SHARE_THROTTLE_OB_SHARE_THROTTLE_DEFINE_H

#include "lib/alloc/alloc_struct.h"

/**
 * @brief This File is used to avoid introducing circular dependencies. It declares some class but do not include their
 * .h file
 */

#define DEFINE_CUSTOM_FUNC_FOR_THROTTLE(throttle_name)                                                           \
  static const lib::ObLabel throttle_unit_name()                                                                 \
  {                                                                                                              \
    static lib::ObLabel label(#throttle_name);                                                                   \
    return label;                                                                                                \
  }                                                                                                              \
  static int64_t resource_unit_size();                                                                           \
  static void init_throttle_config(int64_t &resource_limit, int64_t &trigger_percentage, int64_t &max_duration); \
  static void adaptive_update_limit(                                                     \
                                    const int64_t holding_size,                                                  \
                                    const int64_t config_specify_resource_limit,                                 \
                                    int64_t &resource_limit,                                                     \
                                    int64_t &last_update_limit_ts,                                               \
                                    bool &is_updated);

#define DEFINE_SHARE_THROTTLE(ThrottleName, ...)      \
                                                      \
  struct FakeAllocatorFor##ThrottleName {             \
    DEFINE_CUSTOM_FUNC_FOR_THROTTLE(ThrottleName);    \
  };                                                  \
                                                      \
  LST_DEFINE(__VA_ARGS__);                            \
                                                      \
  template <typename FakeAllocator, typename... Args> \
  class ObShareResourceThrottleTool;                  \
                                                      \
  using ThrottleName##ThrottleTool = ObShareResourceThrottleTool<FakeAllocatorFor##ThrottleName, __VA_ARGS__>;

namespace oceanbase {

namespace share {

// This Macor will expand as follows :
//
// struct FakeAllocatorForTxShare {
//   static const lib::ObLabel throttle_unit_name()
//   {
//     lib::ObLabel label("TxShare");
//     return label;
//   }
//   static int64_t resource_unit_size();
//   static void init_throttle_config(int64_t &resource_limit, int64_t &trigger_percentage, int64_t &max_duration);
// };
//
// class ObMemstoreAllocator;
// class ObTxDataAllocator;
// class ObMdsAllocator;
//
// template <typename FakeAllocator, typename... Args>
// class ObShareResourceThrottleTool;
//
// using TxShareThrottleTool = ObShareResourceThrottleTool<FakeAllocatorForTxShare,
//                                                         ObMemstoreAllocator,
//                                                         ObTxDataAllocator,
//                                                         ObMdsAllocator,
//                                                         ObVectorAllocator>;
// Vector retains its module limit and also contributes to the TxShare aggregate limit.
DEFINE_SHARE_THROTTLE(TxShare,
                      ObMemstoreAllocator,
                      ObTxDataAllocator,
                      ObMdsAllocator,
                      ObVectorAllocator)

int64_t get_tx_share_memory_limit();


class ObThrottleInfoGuard;

class PrintThrottleUtil {
public:
  static void pirnt_throttle_info(const int err_code,
                                  const char *throttle_unit_name,
                                  const int64_t sleep_time,
                                  const int64_t left_interval,
                                  const int64_t expected_wait_time,
                                  const int64_t abs_expire_time,
                                  const ObThrottleInfoGuard &share_ti_guard,
                                  const ObThrottleInfoGuard &module_ti_guard,
                                  bool &has_printed_lbt);

  static void print_throttle_statistic(const int err_code,
                                       const char *throttle_unit_name,
                                       const int64_t sleep_time,
                                       const int64_t throttle_memory_size = 0);
};

}  // namespace share

}  // namespace oceanbase

#endif
