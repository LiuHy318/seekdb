/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "share/scn.h"
#include "storage/tx_table/ob_tx_ctx_memtable.h"
#include "storage/compaction/ob_schedule_dag_func.h"

namespace oceanbase
{
using namespace share;
using namespace palf;

namespace storage
{

ObTxCtxMemtable::ObTxCtxMemtable()
  : ObIMemtable(),
    is_inited_(false),
    is_frozen_(false),
    ls_ctx_mgr_guard_(),
    flush_lock_(),
    max_end_scn_(share::SCN::min_scn())
{
}

ObTxCtxMemtable::~ObTxCtxMemtable()
{
  reset();
}

void ObTxCtxMemtable::reset()
{
  ls_ctx_mgr_guard_.reset();
  ObITable::reset();
  is_frozen_ = false;
  max_end_scn_.set_min();
  is_inited_ = false;
}

int ObTxCtxMemtable::init(const ObITable::TableKey &table_key)
{
  int ret = OB_SUCCESS;

  if (IS_INIT) {
    ret = OB_INIT_TWICE;
    STORAGE_LOG(WARN, "init tx ctx memtable twice", KR(ret));
  } else if (OB_FAIL(ObITable::init(table_key))) {
  } else if (OB_FAIL(ls_ctx_mgr_guard_.init())) {
  } else {
    max_end_scn_.set_min();
    is_inited_ = true;
    TRANS_LOG(INFO, "ob tx ctx memtable init successfully", K(table_key));
  }

  return ret;
}

int ObTxCtxMemtable::scan(const ObTableIterParam &param,
                          ObTableAccessContext &context,
                          const blocksstable::ObDatumRange &key_range,
                          ObStoreRowIterator *&row_iter)
{
  int ret = OB_SUCCESS;
  ObTxCtxMemtableScanIterator *scan_iter_ptr = nullptr;
  void *scan_iter_buff = nullptr;
  UNUSED(key_range);
  UNUSED(context);

  if (IS_NOT_INIT) {
    ret = OB_NOT_INIT;
    STORAGE_LOG(WARN, "ob tx ctx memtable is not inited.", KR(ret), KPC(this));
  } else if (OB_UNLIKELY(!param.is_valid() || !context.is_valid())) {
    ret = OB_INVALID_ARGUMENT;
    STORAGE_LOG(WARN, "invalid param", KR(ret), K(param), K(context));
  } else if (OB_UNLIKELY(!param.is_multi_version_minor_merge_)) {
    ret = OB_INVALID_ARGUMENT;
    STORAGE_LOG(WARN, "ObTxCtxMemtable only support scan for minor merge", KR(ret), K(param));
  } else if (OB_ISNULL(scan_iter_buff
                       = context.stmt_allocator_->alloc(sizeof(ObTxCtxMemtableScanIterator)))) {
    ret = OB_ALLOCATE_MEMORY_FAILED;
    STORAGE_LOG(WARN, "construct ObTxCtxMemtableScanIterator fail", "scan_iter_buffer",
                scan_iter_buff, "scan_iter_ptr", scan_iter_ptr, KR(ret));
  } else if (FALSE_IT(scan_iter_ptr = new (scan_iter_buff) ObTxCtxMemtableScanIterator())) {
  } else if (OB_FAIL(scan_iter_ptr->init(this))) {
  } else {
    // tx ctx memtable scan iterator init success
    row_iter = scan_iter_ptr;
    TRANS_LOG(INFO, "ob tx ctx memtable scan successfully", KPC(this));
  }

  return ret;
}

int ObTxCtxMemtable::get(const storage::ObTableIterParam &param,
                         storage::ObTableAccessContext &context,
                         const blocksstable::ObDatumRowkey &rowkey,
                         blocksstable::ObDatumRow &row)
{
  UNUSED(param);
  UNUSED(context);
  UNUSED(rowkey);
  UNUSED(row);
  return OB_NOT_SUPPORTED;
}

int ObTxCtxMemtable::get(const storage::ObTableIterParam &param,
                         storage::ObTableAccessContext &context,
                         const blocksstable::ObDatumRowkey &rowkey,
                         ObStoreRowIterator *&row_iter)
{
  UNUSED(param);
  UNUSED(context);
  UNUSED(rowkey);
  UNUSED(row_iter);
  return OB_NOT_SUPPORTED;
}

int ObTxCtxMemtable::multi_get(const ObTableIterParam &param,
                               ObTableAccessContext &context,
                               const common::ObIArray<blocksstable::ObDatumRowkey> &rowkeys,
                               ObStoreRowIterator *&row_iter)
{
  UNUSED(param);
  UNUSED(context);
  UNUSED(rowkeys);
  UNUSED(row_iter);
  return OB_NOT_SUPPORTED;
}

int ObTxCtxMemtable::multi_scan(const ObTableIterParam &param,
                                ObTableAccessContext &context,
                                const common::ObIArray<blocksstable::ObDatumRange> &ranges,
                                ObStoreRowIterator *&row_iter)
{
  UNUSED(param);
  UNUSED(context);
  UNUSED(ranges);
  UNUSED(row_iter);
  return OB_NOT_SUPPORTED;
}

int ObTxCtxMemtable::get_frozen_schema_version(int64_t &schema_version) const
{
  UNUSED(schema_version);
  return OB_NOT_SUPPORTED;
}

bool ObTxCtxMemtable::can_be_minor_merged()
{
  return true;
}

transaction::ObLSTxCtxMgr *ObTxCtxMemtable::get_ls_tx_ctx_mgr()
{
  return ls_ctx_mgr_guard_.get_ls_tx_ctx_mgr();
}

SCN ObTxCtxMemtable::get_rec_scn()
{
  int ret = OB_SUCCESS;
  SCN rec_scn;

  if (OB_FAIL(get_ls_tx_ctx_mgr()->get_rec_scn(rec_scn))) {
  } else {
    TRANS_LOG(INFO, "tx ctx memtable get rec scn", KPC(this), K(rec_scn));
  }

  return rec_scn;
}

ObTabletID ObTxCtxMemtable::get_tablet_id() const
{
  return LS_TX_CTX_TABLET;
}

bool ObTxCtxMemtable::is_flushing() const
{
  return ATOMIC_LOAD(&is_frozen_);
}

int ObTxCtxMemtable::on_memtable_flushed()
{
  int ret = OB_SUCCESS;
  if (get_scn_range().end_scn_ >= max_end_scn_) {
    max_end_scn_.atomic_store(get_scn_range().end_scn_);
    TRANS_LOG(INFO, "on memtable flushed succeed", KPC(this), K(get_scn_range()));
  } else {
    TRANS_LOG(ERROR, "on memtable flushed failed", KPC(this), K(get_scn_range()));
  }
  ATOMIC_STORE(&is_frozen_, false);
  return get_ls_tx_ctx_mgr()->on_tx_ctx_table_flushed();
}

bool ObTxCtxMemtable::is_frozen_memtable()
{
  return ATOMIC_LOAD(&is_frozen_);
}

bool ObTxCtxMemtable::is_active_memtable()
{
  return !ATOMIC_LOAD(&is_frozen_);
}

int ObTxCtxMemtable::flush(SCN recycle_scn, bool need_freeze)
{
  int ret = OB_SUCCESS;
  ObSpinLockGuard guard(flush_lock_);

  if (need_freeze) {
    SCN rec_scn = get_rec_scn();
    if (rec_scn >= recycle_scn) {
      TRANS_LOG(INFO, "no need to freeze", K(rec_scn), K(recycle_scn));
    } else if (is_active_memtable()) {
      int64_t cur_time_us = ObTimeUtility::current_time();
      share::SCN cur_time_scn;
      ObScnRange scn_range;
      if (OB_FAIL(cur_time_scn.convert_for_tx(cur_time_us))) {
      } else {
        scn_range.start_scn_.set_base();
        scn_range.end_scn_ = MAX(cur_time_scn, share::SCN::scn_inc(max_end_scn_));
        set_scn_range(scn_range);
        set_snapshot_version(scn_range.end_scn_);
        ATOMIC_STORE(&is_frozen_, true);
      }
    }
  }

  if (OB_SUCC(ret) && is_frozen_memtable()) {
    compaction::ObTabletMergeDagParam param;
    param.tablet_id_ = LS_TX_CTX_TABLET;
    param.merge_type_ = compaction::MINI_MERGE;
    param.merge_version_ = ObVersionRange::MIN_VERSION;
    if (OB_FAIL(compaction::ObScheduleDagFunc::schedule_tx_table_merge_dag(param))) {
      if (OB_EAGAIN != ret && OB_SIZE_OVERFLOW != ret) {
          TRANS_LOG(ERROR, "failed to schedule tablet merge dag", K(ret));
      }
    } else {
      TRANS_LOG(INFO, "tx ctx memtable flush successfully", KPC(this));
    }
  }

  return ret;
}

void ObTxCtxMemtable::set_max_end_scn(const share::SCN scn)
{
  int ret = OB_SUCCESS;
  if (scn >= max_end_scn_) {
    max_end_scn_.atomic_store(scn);
    TRANS_LOG(INFO, "set memtable end scn succeed", KPC(this), K(scn));
  } else {
    TRANS_LOG(ERROR, "set memtable end scn failed", KPC(this), K(scn));
  }
}

} // namespace storage
} // namespace oceanbase
