/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_TX_CTX_MEMTABLE
#define OCEANBASE_STORAGE_OB_TX_CTX_MEMTABLE

#include "storage/memtable/ob_memtable_interface.h"
#include "storage/tx_table/ob_tx_ctx_table.h"
#include "storage/tx_table/ob_tx_table_iterator.h"
#include "storage/checkpoint/ob_common_checkpoint.h"

namespace oceanbase
{
namespace storage
{
//
// We need to maintain the filter location and the playback site
// separately to modularly manage different table structures, remove
// dependencies between them, and minor merge independently.
//
// So we need:
//
// 1, Adaptation is required for a management insituation named CheckpointMgr[1] as a
// design prototype, the goal is a unified abstraction of the recovery module.
//
// 2, Adaptation is required for a management insituation like LSM mgr[2] as a
// design prototype, the goal is a unified abstraction of the merge module.
//
// [1]: 
// [2]: 
class ObTxCtxMemtable : public ObIMemtable, public checkpoint::ObCommonCheckpoint
{
public:
  ObTxCtxMemtable();
  ~ObTxCtxMemtable();

  int init(const ObITable::TableKey &table_key);

  void reset();
  int on_memtable_flushed() override;
  bool is_frozen_memtable() override;
  bool is_active_memtable() override;

  // ================ INHERITED FROM ObIMemtable ===============
  // We need to inherient the memtable method for merge process to iterate the
  // ls_ctx_mgr for dumping the tx ctx table.
  virtual int scan(const ObTableIterParam &param,
                   ObTableAccessContext &context,
                   const blocksstable::ObDatumRange &key_range,
                   ObStoreRowIterator *&row_iter) override;

  transaction::ObLSTxCtxMgr *get_ls_tx_ctx_mgr();
  virtual bool can_be_minor_merged() override;

  // TODO : @handora.qc implement it
  virtual int64_t get_occupied_size() const override { return 0; }

  // ================ INHERITED FROM ObCommonCheckpoint ===============
  virtual share::SCN get_rec_scn();
  virtual int flush(share::SCN recycle_scn, bool need_freeze = true);

  virtual ObTabletID get_tablet_id() const override;
  virtual bool is_flushing() const override;

  // ================ NOT SUPPORTED INTERFACE ===============

  virtual int get(const storage::ObTableIterParam &param,
                  storage::ObTableAccessContext &context,
                  const blocksstable::ObDatumRowkey &rowkey,
                  blocksstable::ObDatumRow &row) override;

  virtual int get(const storage::ObTableIterParam &param,
                  storage::ObTableAccessContext &context,
                  const blocksstable::ObDatumRowkey &rowkey,
                  ObStoreRowIterator *&row_iter) override;

  virtual int multi_get(const ObTableIterParam &param,
                        ObTableAccessContext &context,
                        const common::ObIArray<blocksstable::ObDatumRowkey> &rowkeys,
                        ObStoreRowIterator *&row_iter) override;

  virtual int multi_scan(const ObTableIterParam &param,
                         ObTableAccessContext &context,
                         const common::ObIArray<blocksstable::ObDatumRange> &ranges,
                         ObStoreRowIterator *&row_iter) override;

  virtual int get_frozen_schema_version(int64_t &schema_version) const override;

  void set_max_end_scn(const share::SCN end_scn);

  INHERIT_TO_STRING_KV("ObITable", ObITable, KP(this), K_(snapshot_version),
                       K_(is_frozen), K_(max_end_scn));

private:
  bool is_inited_;
  bool is_frozen_;
  ObTxCtxTable ls_ctx_mgr_guard_;
  common::ObSpinLock flush_lock_;
  share::SCN max_end_scn_;
};

}  // namespace storage
}  // namespace oceanbase
#endif // OCEANBASE_STORAGE_OB_TX_CTX_MEMTABLE
