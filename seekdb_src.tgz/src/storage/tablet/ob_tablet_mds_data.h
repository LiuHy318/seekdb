/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_TABLET_MDS_DATA
#define OCEANBASE_STORAGE_OB_TABLET_MDS_DATA

#include <stdint.h>
#include "lib/container/ob_se_array.h"
#include "lib/string/ob_string.h"
#include "storage/tablet/ob_tablet_autoincrement_state.h"
#include "storage/compaction/ob_compaction_util.h"
#include "storage/compaction/ob_extra_medium_info.h"
#include "storage/multi_data_source/adapter_define/mds_dump_node.h"
#include "storage/tablet/ob_tablet_complex_addr.h"
#include "storage/tablet/ob_tablet_member_wrapper.h"
#include "storage/tablet/ob_tablet_full_medium_info.h"

namespace oceanbase
{
namespace common
{
class ObIAllocator;
class ObArenaAllocator;
}
namespace compaction
{
class ObMediumCompactionInfoKey;
class ObMediumCompactionInfo;
class ObMediumCompactionInfoList;
}

namespace storage
{
class ObTabletFullMemoryMdsData;

class ObTabletMdsDumpStruct
{
  OB_UNIS_VERSION(1);
public:
  ObTabletMdsDumpStruct();
  ~ObTabletMdsDumpStruct();
  ObTabletMdsDumpStruct(const ObTabletMdsDumpStruct &) = delete;
  ObTabletMdsDumpStruct &operator=(const ObTabletMdsDumpStruct &) = delete;
public:
  int init(common::ObIAllocator &allocator);
  void reset();

  TO_STRING_KV(K_(uncommitted_kv), K_(committed_kv));
public:
  ObTabletComplexAddr<mds::MdsDumpKV> uncommitted_kv_;
  ObTabletComplexAddr<mds::MdsDumpKV> committed_kv_;
};
// not used after 4.3
class ObTabletMdsData
{
  friend class ObTablet;
public:
  ObTabletMdsData();
  ~ObTabletMdsData();
  ObTabletMdsData(const ObTabletMdsData&) = delete;
  ObTabletMdsData &operator=(const ObTabletMdsData&) = delete;
public:
  void reset();
  int init_for_first_creation();
  int init_for_mds_table_dump(
      common::ObIAllocator &allocator,
      const ObTabletMdsData &mds_table_data,
      const ObTabletMdsData &base_data,
      const int64_t finish_medium_scn);
  int init_for_evict_medium_info(
      common::ObIAllocator &allocator,
      const ObTabletMdsData &other,
      const int64_t finish_medium_scn,
      const compaction::ObMergeType merge_type = compaction::ObMergeType::MERGE_TYPE_MAX);
  void set_mem_addr();

public:
  int deserialize(const char *buf, const int64_t data_len, int64_t &pos);

  TO_STRING_KV(K_(is_inited),
               K_(tablet_status),
               K_(aux_tablet_info),
               K_(extra_medium_info),
               K_(medium_info_list),
               K_(auto_inc_seq),
               K_(tablet_status_cache));
public:
  static int load_mds_dump_kv(
      common::ObIAllocator &allocator,
      const ObTabletComplexAddr<mds::MdsDumpKV> &complex_addr,
      mds::MdsDumpKV *&kv);
  template<typename ARRAY_STRUCT>
  static int load_array(
      common::ObIAllocator &allocator,
      const ObTabletComplexAddr<ARRAY_STRUCT> &complex_addr,
      ARRAY_STRUCT *&list);
  static int load_auto_inc_seq(
      common::ObIAllocator &allocator,
      const ObTabletComplexAddr<ObTabletAutoincSeq> &complex_addr,
      ObTabletAutoincSeq *&auto_inc_seq);
  static int build_tablet_status(
      common::ObArenaAllocator &allocator,
      const ObTabletTxMultiSourceDataUnit &tx_data,
      const share::SCN &create_commit_scn,
      ObTabletMdsData &mds_data);
  static int build_aux_tablet_info(
      common::ObArenaAllocator &allocator,
      const ObTabletTxMultiSourceDataUnit &tx_data,
      const ObTabletBindingInfo &ddl_data,
      const share::SCN &clog_checkpoint_scn,
      ObTabletMdsData &mds_data);
  static int build_auto_inc_seq(
      common::ObArenaAllocator &allocator,
      const ObTabletAutoincSeq &auto_inc_seq,
      ObTabletMdsData &mds_data);
  static int build_mds_data(
    common::ObArenaAllocator &allocator,
    const ObTabletAutoincSeq &auto_inc_seq,
    const ObTabletTxMultiSourceDataUnit &tx_data,
    const share::SCN &create_commit_scn,
    const ObTabletBindingInfo &ddl_data,
    const share::SCN &clog_checkpoint_scn,
    const compaction::ObMediumCompactionInfoList &info_list,
    ObTabletMdsData &mds_data);
private:
  void reset(common::ObIAllocator &allocator);
  int set_tablet_status(
      common::ObIAllocator &allocator,
      const ObTabletStatus::Status &tablet_status,
      const ObTabletMdsUserDataType &data_type);
  static int init_single_complex_addr(
      common::ObIAllocator &allocator,
      const ObTabletComplexAddr<mds::MdsDumpKV> &src_addr,
      ObTabletComplexAddr<mds::MdsDumpKV> &dst_addr);
  static int init_single_complex_addr(
      common::ObIAllocator &allocator,
      const ObTabletComplexAddr<ObTabletAutoincSeq> &src_addr,
      ObTabletComplexAddr<ObTabletAutoincSeq> &dst_addr);
  static int init_single_complex_addr(
      common::ObIAllocator &allocator,
      const ObTabletComplexAddr<ObTabletDumpedMediumInfo> &src_addr,
      const int64_t finish_medium_scn,
      ObTabletComplexAddr<ObTabletDumpedMediumInfo> &dst_addr);
  static int init_single_complex_addr_and_extra_info(
      common::ObIAllocator &allocator,
      const ObTabletComplexAddr<ObTabletDumpedMediumInfo> &src_addr,
      const compaction::ObExtraMediumInfo &src_addr_extra_info,
      const ObTabletDumpedMediumInfo &src_data,
      const compaction::ObExtraMediumInfo &src_data_extra_info,
      const int64_t finish_medium_scn,
      ObTabletComplexAddr<ObTabletDumpedMediumInfo> &dst_addr,
      compaction::ObExtraMediumInfo &dst_extra_info);
  static int init_single_complex_addr(
      common::ObIAllocator &allocator,
      const ObTabletComplexAddr<mds::MdsDumpKV> &mds_table_data,
      const ObTabletComplexAddr<mds::MdsDumpKV> &base_data,
      ObTabletComplexAddr<mds::MdsDumpKV> &fused_data);
  static int init_single_complex_addr(
      common::ObIAllocator &allocator,
      const ObTabletComplexAddr<ObTabletAutoincSeq> &mds_table_data,
      const ObTabletComplexAddr<ObTabletAutoincSeq> &base_data,
      ObTabletComplexAddr<ObTabletAutoincSeq> &fused_data);
  static int init_single_complex_addr(
      common::ObIAllocator &allocator,
      const ObTabletComplexAddr<ObTabletDumpedMediumInfo> &mds_table_data,
      const ObTabletComplexAddr<ObTabletDumpedMediumInfo> &base_data,
      const int64_t finish_medium_scn,
      ObTabletComplexAddr<ObTabletDumpedMediumInfo> &fused_data);
  template<typename ARRAY_STRUCT, typename ITEM>
  static int read_items(
      const ObMetaDiskAddr &addr,
      ARRAY_STRUCT &input_array_struct,
      common::ObIArray<ITEM*> &array);
  static int copy_medium_info_list(
      const int64_t finish_medium_scn,
      const ObTabletDumpedMediumInfo &input_medium_info_list1,
      const ObTabletDumpedMediumInfo &input_medium_info_list2,
      ObTabletDumpedMediumInfo &medium_info_list);
  template <typename T>
  static int update_user_data_from_complex_addr(
      const ObTabletComplexAddr<mds::MdsDumpKV> &complex_addr,
      T &user_data);
public:
  bool is_inited_;
  ObTabletMdsDumpStruct tablet_status_;
  ObTabletMdsDumpStruct aux_tablet_info_;

  compaction::ObExtraMediumInfo extra_medium_info_;
  ObTabletComplexAddr<ObTabletDumpedMediumInfo> medium_info_list_;

  ObTabletComplexAddr<ObTabletAutoincSeq> auto_inc_seq_;
  ObTabletCreateDeleteMdsUserData tablet_status_cache_; // redundant data for tablet status
};

template <typename T>
int ObTabletMdsData::update_user_data_from_complex_addr(
    const ObTabletComplexAddr<mds::MdsDumpKV> &complex_addr,
    T &user_data)
{
  int ret = common::OB_SUCCESS;

  if (OB_UNLIKELY(!complex_addr.is_memory_object() && !complex_addr.is_none_object())) {
    ret = common::OB_INVALID_ARGUMENT;
    STORAGE_LOG(WARN, "complex addr is not memory or none type", K(ret), K(complex_addr));
  } else if (complex_addr.is_none_object()) {
    // do nothing
  } else {
    const mds::MdsDumpKV *kv = complex_addr.ptr_;
    const common::ObString &str = kv->v_.user_data_;
    if (str.empty()) {
      // do nothing
    } else {
      int64_t pos = 0;
      if (OB_FAIL(user_data.deserialize(str.ptr(), str.length(), pos))) {
      }
    }
  }

  return ret;
}
} // namespace storage
} // namespace oceanbase

#endif // OCEANBASE_STORAGE_OB_TABLET_MDS_DATA
