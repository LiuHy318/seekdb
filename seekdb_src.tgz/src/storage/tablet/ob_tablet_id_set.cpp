/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define USING_LOG_PREFIX STORAGE

#include "storage/tablet/ob_tablet_id_set.h"


namespace oceanbase
{
namespace storage
{
ObTabletIDSet::ObTabletIDSet()
  : id_set_(),
    bucket_lock_(),
    is_inited_(false)
{
}

ObTabletIDSet::~ObTabletIDSet()
{
  destroy();
}

int ObTabletIDSet::init(const uint64_t bucket_lock_bucket_cnt)
{
  int ret = OB_SUCCESS;
  const int64_t bucket_num = common::hash::cal_next_prime(bucket_lock_bucket_cnt);
  if (OB_UNLIKELY(is_inited_)) {
    ret = OB_INIT_TWICE;
    LOG_WARN("init twice", K(ret), K_(is_inited));
  } else if (OB_FAIL(id_set_.create(bucket_num, "TabletIDSetBkt", "TabletIDSetNode"))) {
  } else if (OB_FAIL(bucket_lock_.init(bucket_num, ObLatchIds::TABLET_BUCKET_LOCK,
      "TabletIDSetBkt"))) {
  } else {
    is_inited_ = true;
  }
  if (OB_UNLIKELY(!is_inited_)) {
    destroy();
  }
  return ret;
}

int ObTabletIDSet::set(const common::ObTabletID &tablet_id)
{
  ObBucketHashWLockGuard lock_guard(bucket_lock_, tablet_id.hash());
  return id_set_.set_refactored(tablet_id);
}

int ObTabletIDSet::exist(const common::ObTabletID &tablet_id)
{
  ObBucketHashRLockGuard lock_guard(bucket_lock_, tablet_id.hash());
  return id_set_.exist_refactored(tablet_id);
}

int ObTabletIDSet::erase(const common::ObTabletID &tablet_id)
{
  ObBucketHashWLockGuard lock_guard(bucket_lock_, tablet_id.hash());
  return id_set_.erase_refactored(tablet_id);
}

void ObTabletIDSet::destroy()
{
  bucket_lock_.destroy();
  id_set_.destroy();
  is_inited_ = false;
}
} // namespace storage
} // namespace oceanbase
