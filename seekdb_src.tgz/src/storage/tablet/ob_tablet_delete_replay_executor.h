/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_TABLET_DELETE_REPLAY_EXECUTOR
#define OCEANBASE_STORAGE_OB_TABLET_DELETE_REPLAY_EXECUTOR

#include "common/ob_tablet_id.h"
#include "storage/tablet/ob_tablet_replay_executor.h"

namespace oceanbase
{

namespace storage
{

struct ObRemoveTabletArg
{
  OB_UNIS_VERSION(1);
public:
  inline bool is_valid() const
  {
    return tablet_id_.is_valid();
  }

  TO_STRING_KV(K_(tablet_id));

public:
  common::ObTabletID tablet_id_;
};

class ObTabletDeleteReplayExecutor final : public ObTabletReplayExecutor
{
public:
  ObTabletDeleteReplayExecutor();

  int init(mds::BufferCtx &ctx, const share::SCN &scn);

protected:
  bool is_replay_update_tablet_status_() const override
  {
    return true;
  }

  int do_replay_(ObTabletHandle &tablet_handle) override;

  virtual bool is_replay_update_mds_table_() const override
  {
    return true;
  }

private:
  mds::BufferCtx *ctx_;
  share::SCN scn_;
};


}
}

#endif
