/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define USING_LOG_PREFIX STORAGE

#include "ob_tablet_binding_helper.h"
#include "query/session/ob_inner_sql_connection_access.h"
#include "share/ob_ex_rpc.h"
#include "share/rc/ob_server_runtime.h"
#include "storage/tablet/ob_tablet_binding_replay_executor.h"
#include "share/tablet/ob_tablet_mapping_operator.h"
#include "storage/tx_storage/ob_ls_service.h"

using namespace oceanbase::common;
using namespace oceanbase::share;
using namespace oceanbase::transaction;
using namespace oceanbase::palf;
using namespace oceanbase::memtable;
using namespace oceanbase::obcall;

namespace oceanbase
{
namespace storage
{

ObBatchUnbindTabletArg::ObBatchUnbindTabletArg()
  : schema_version_(OB_INVALID_VERSION),
    orig_tablet_ids_(),
    hidden_tablet_ids_(),
    is_write_defensive_(false)
{
}

int ObBatchUnbindTabletArg::assign(const ObBatchUnbindTabletArg &other)
{
  int ret = OB_SUCCESS;
  if (OB_FAIL(orig_tablet_ids_.assign(other.orig_tablet_ids_))) {
  } else if (OB_FAIL(hidden_tablet_ids_.assign(other.hidden_tablet_ids_))) {
  } else {
    schema_version_ = other.schema_version_;
    is_write_defensive_ = other.is_write_defensive_;
  }
  return ret;
}

OB_DEF_SERIALIZE(ObBatchUnbindTabletArg)
{
  int ret = OB_SUCCESS;
  LST_DO_CODE(OB_UNIS_ENCODE, schema_version_, orig_tablet_ids_, hidden_tablet_ids_, is_write_defensive_);
  return ret;
}

OB_DEF_SERIALIZE_SIZE(ObBatchUnbindTabletArg)
{
  int len = 0;
  LST_DO_CODE(OB_UNIS_ADD_LEN, schema_version_, orig_tablet_ids_, hidden_tablet_ids_, is_write_defensive_);
  return len;
}

OB_DEF_DESERIALIZE(ObBatchUnbindTabletArg)
{
  int ret = OB_SUCCESS;
  LST_DO_CODE(OB_UNIS_DECODE, schema_version_, orig_tablet_ids_, hidden_tablet_ids_, is_write_defensive_);
  return ret;
}

ObBatchUnbindLobTabletArg::ObBatchUnbindLobTabletArg()
  : data_tablet_ids_()
{
}

int ObBatchUnbindLobTabletArg::assign(const ObBatchUnbindLobTabletArg &other)
{
  int ret = OB_SUCCESS;
  if (OB_FAIL(data_tablet_ids_.assign(other.data_tablet_ids_))) {
  }
  return ret;
}

OB_SERIALIZE_MEMBER(ObBatchUnbindLobTabletArg, data_tablet_ids_);

int ObTabletBindingHelper::get_ls(ObLS *&tenant_ls)
{
  int ret = OB_SUCCESS;
  tenant_ls = nullptr;
  ObLSService *ls_srv = nullptr;
  if (OB_ISNULL(ls_srv = ::oceanbase::share::server_service<::oceanbase::storage::ObLSService>())) {
    ret = OB_ERR_UNEXPECTED;
    LOG_ERROR("::oceanbase::share::server_service<::oceanbase::storage::ObLSService>() fail, server modules not initialized?", KR(ret));
  } else if (OB_FAIL(ls_srv->get_ls(tenant_ls))) {
  } else if (OB_ISNULL(tenant_ls)) {
    ret = OB_ERR_UNEXPECTED;
    LOG_ERROR("local ls is null", KR(ret));
  }
  return ret;
}

int ObTabletBindingHelper::get_tablet_for_new_mds(const ObLS &ls, const ObTabletID &tablet_id, const share::SCN &replay_scn, ObTabletHandle &handle)
{
  int ret = OB_SUCCESS;
  const ObTabletMapKey key(tablet_id);
  const bool for_replay = replay_scn.is_valid();
  if (for_replay) {
    const bool replay_allow_tablet_not_exist = true;
    if (OB_FAIL(ls.replay_get_tablet_no_check(tablet_id, replay_scn, replay_allow_tablet_not_exist, handle))) {
      if (OB_OBSOLETE_CLOG_NEED_SKIP == ret) {
        ret = OB_NO_NEED_UPDATE;
        LOG_WARN("clog is obsolete, should skip replay", K(ret));
      } else {
        LOG_WARN("failed to get tablet", K(ret));
      }
    } else if (OB_UNLIKELY(handle.get_obj()->is_empty_shell())) {
      ret = OB_NO_NEED_UPDATE;
      LOG_WARN("tablet is already deleted, need skip", K(ret), K(key));
    }
  } else if (OB_FAIL(ObTabletCreateDeleteHelper::get_tablet(key, handle))) {
  }

  return ret;
}

int ObTabletBindingHelper::has_lob_tablets(const obcall::ObBatchCreateTabletArg &arg, const obcall::ObCreateTabletInfo &info, bool &has_lob)
{
  int ret = OB_SUCCESS;
  has_lob = false;
  for (int64_t i = 0; OB_SUCC(ret) && !has_lob && i < info.tablet_ids_.count(); i++) {
    const ObCreateTabletSchema *create_tablet_schema = arg.create_tablet_schemas_.at(info.table_schema_index_.at(i));
    if (OB_ISNULL(create_tablet_schema)) {
      ret = OB_INVALID_ARGUMENT;
      LOG_WARN("storage is NULL", KR(ret), K(arg));
    } else if (create_tablet_schema->is_aux_lob_meta_table() || create_tablet_schema->is_aux_lob_piece_table()) {
      has_lob = true;
    }
  }
  return ret;
}

int ObTabletBindingHelper::modify_tablet_binding_for_new_mds_create(const ObBatchCreateTabletArg &arg, const share::SCN &replay_scn, mds::BufferCtx &ctx)
{
  MDS_TG(100_ms);
  int ret = OB_SUCCESS;
  ObLS *tenant_ls = nullptr;
  if (OB_FAIL(ObTabletBindingHelper::get_ls(tenant_ls))) {
  } else {
    const ObArray<ObTabletID> empty_array;
    ObLS &ls = *tenant_ls;
    bool has_lob = false;
    for (int64_t i = 0; OB_SUCC(ret) && i < arg.tablets_.count(); i++) {
      const ObCreateTabletInfo &info = arg.tablets_[i];
      if (ObTabletCreateDeleteHelper::is_pure_hidden_tablets(info)) {
        if (CLICK_FAIL(bind_hidden_tablet_to_orig_tablet(ls, info, replay_scn, ctx))) {
          LOG_WARN("failed to add hidden tablet", K(ret));
        }
      } else if (OB_FAIL(ObTabletBindingHelper::has_lob_tablets(arg, info, has_lob))) {
      } else if (has_lob) {
        if (CLICK_FAIL(bind_lob_tablet_to_data_tablet(ls, arg, info, replay_scn, ctx))) {
          LOG_WARN("failed to add lob tablet", K(ret));
        }
      }
    }
  }
  return ret;
}

int ObBindHiddenTabletToOrigTabletOp::assign(const ObBindHiddenTabletToOrigTabletOp &other)
{
  int ret = OB_SUCCESS;
  info_ = other.info_;
  return ret;
}

int ObBindHiddenTabletToOrigTabletOp::operator()(ObTabletBindingMdsUserData &data)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(info_)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid arg", K(ret));
  } else {
    const ObTabletID &orig_tablet_id = info_->data_tablet_id_;
    for (int64_t i = 0; OB_SUCC(ret) && i < info_->tablet_ids_.count(); i++) {
      const ObTabletID &tablet_id = info_->tablet_ids_.at(i);
      if (tablet_id != orig_tablet_id && tablet_id != data.hidden_tablet_id_) {
        data.hidden_tablet_id_ = tablet_id;
      }
    }
  }
  return ret;
}

int ObTabletBindingHelper::bind_hidden_tablet_to_orig_tablet(
    ObLS &ls,
    const ObCreateTabletInfo &info,
    const share::SCN &replay_scn,
    mds::BufferCtx &ctx)
{
  ObBindHiddenTabletToOrigTabletOp op(info);
  return modify_tablet_binding_new_mds(ls, info.data_tablet_id_, replay_scn, ctx, op);
}

int ObBindLobTabletToDataTabletOp::assign(const ObBindLobTabletToDataTabletOp &other)
{
  int ret = OB_SUCCESS;
  arg_ = other.arg_;
  info_ = other.info_;
  return ret;
}

int ObBindLobTabletToDataTabletOp::operator()(ObTabletBindingMdsUserData &data)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(arg_) || OB_ISNULL(info_)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid arg", K(ret), KPC(arg_), KPC(info_));
  } else {
    const ObTabletID &data_tablet_id = info_->data_tablet_id_;
    for (int64_t i = 0; OB_SUCC(ret) && i < info_->tablet_ids_.count(); i++) {
      const ObTabletID &tablet_id = info_->tablet_ids_.at(i);
      if (tablet_id != data_tablet_id) {
        const ObCreateTabletSchema *create_tablet_schema = arg_->create_tablet_schemas_.at(info_->table_schema_index_.at(i));
        if (OB_ISNULL(create_tablet_schema)) {
          ret = OB_INVALID_ARGUMENT;
          LOG_WARN("storage is NULL", KR(ret), K(arg_));
        } else if (create_tablet_schema->is_aux_lob_meta_table()) {
          data.lob_meta_tablet_id_ = tablet_id;
        } else if (create_tablet_schema->is_aux_lob_piece_table()) {
          data.lob_piece_tablet_id_ = tablet_id;
        } else {
          // do not maintain index tablet ids
        }
      }
    }
  }
  return ret;
}

int ObTabletBindingHelper::bind_lob_tablet_to_data_tablet(
    ObLS &ls,
    const ObBatchCreateTabletArg &arg,
    const ObCreateTabletInfo &info,
    const share::SCN &replay_scn,
    mds::BufferCtx &ctx)
{
  ObBindLobTabletToDataTabletOp op(arg, info);
  return modify_tablet_binding_new_mds(ls, info.data_tablet_id_, replay_scn, ctx, op);
}

int ObTabletBindingHelper::build_single_table_write_defensive(
    const ObTableSchema &table_schema,
    const int64_t schema_version,
    common::ObMySQLTransaction &trans)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(!table_schema.is_valid() || schema_version <= 0)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("argument is invalid", K(ret), K(table_schema), K(schema_version));
  }
  ObArray<ObTabletID> tablet_ids;

  int64_t timeout_us = 0;
  if (OB_FAIL(ret)) {
  } else if (OB_FAIL(table_schema.get_tablet_ids(tablet_ids))) {
  } else if (OB_FAIL(ObDDLUtil::get_ddl_rpc_timeout(tablet_ids.count(), timeout_us))) {
  } else if (OB_FAIL(ObTabletBindingMdsHelper::modify_tablet_binding_for_write_defensive(tablet_ids,
                                                                                         schema_version,
                                                                                         ObTimeUtility::current_time() + timeout_us,
                                                                                         trans))) {
  }
  return ret;
}

// TODO (lihongqin.lhq) Separate the code of replay
template<typename F>
int ObTabletBindingHelper::modify_tablet_binding_new_mds(
    ObLS &ls,
    const ObTabletID &tablet_id,
    const share::SCN &replay_scn,
    mds::BufferCtx &ctx,
    F &&op)
{
  MDS_TG(100_ms);
  int ret = OB_SUCCESS;
  ObTabletHandle tablet_handle;
  ObTablet *tablet = nullptr;
  ObTabletBindingMdsUserData data;
  mds::MdsCtx &user_ctx = static_cast<mds::MdsCtx &>(ctx);
  if (CLICK_FAIL(get_tablet_for_new_mds(ls, tablet_id, replay_scn, tablet_handle))) {
    if (OB_NO_NEED_UPDATE == ret) {
      ret = OB_SUCCESS;
    } else {
      LOG_WARN("failed to get tablet", K(ret));
    }
  } else if (OB_FALSE_IT(tablet = tablet_handle.get_obj())) {
  } else if (CLICK_FAIL(tablet->get_ddl_data(data))) {
    if (!replay_scn.is_valid()) {
      ret = OB_EAGAIN;
    } else {
      LOG_WARN("failed to get ddl data", K(ret));
    }
  } else if (CLICK_FAIL(op(data))) {
    LOG_WARN("failed to operate on mds", K(ret));
  } else {
    if (replay_scn.is_valid()) {
      ObTabletBindingReplayExecutor replay_executor;
      if (CLICK_FAIL(replay_executor.init(ctx, data, replay_scn))) {
        LOG_ERROR("failed to init replay executor", K(ret));
      } else if (CLICK_FAIL(replay_executor.execute(replay_scn, tablet_id))) {
        if (OB_EAGAIN != ret) {
          LOG_ERROR("failed to replay tablet binding log", K(ret));
        }
      }
    } else {
      if (CLICK_FAIL(ls.get_tablet_svr()->set_ddl_info(tablet_id, std::move(data), user_ctx, 0/*lock_timeout_us*/))) {
        if (OB_ERR_EXCLUSIVE_LOCK_CONFLICT == ret) {
          ret = OB_EAGAIN;
        } else {
          LOG_WARN("failed to save tablet binding info", K(ret));
        }
      }
    }
  }
  if (replay_scn.is_valid() && OB_TIMEOUT == ret) {
    ret = OB_EAGAIN;
  }
  return ret;
}

int ObTabletUnbindMdsHelper::register_process(
    ObBatchUnbindTabletArg &arg,
    mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;

  if (OB_FAIL(modify_tablet_binding_for_unbind(arg, SCN::invalid_scn(), ctx))) {
  } else {
    LOG_INFO("modify_tablet_binding_for_unbind register", KR(ret), K(arg));
  }

  return ret;
}

int ObTabletUnbindMdsHelper::on_register(const char* buf, const int64_t len, mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;
  int64_t pos = 0;
  ObBatchUnbindTabletArg arg;
  if (OB_FAIL(arg.deserialize(buf, len, pos))) {
  } else if (OB_FAIL(register_process(arg, ctx))) {
  }
  return ret;
}

int ObTabletUnbindMdsHelper::replay_process(
    ObBatchUnbindTabletArg &arg,
    const share::SCN &scn,
    mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;

  if (OB_FAIL(modify_tablet_binding_for_unbind(arg, scn, ctx))) {
  } else {
    LOG_INFO("modify_tablet_binding_for_unbind redo", KR(ret), K(scn), K(arg));
  }

  return ret;
}

int ObTabletUnbindMdsHelper::on_replay(const char* buf, const int64_t len, const share::SCN &scn, mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;
  int64_t pos = 0;
  ObBatchUnbindTabletArg arg;
  if (OB_FAIL(arg.deserialize(buf, len, pos))) {
  } else if (OB_FAIL(replay_process(arg, scn, ctx))) {
  }
  return ret;
}

int ObUnbindHiddenTabletFromOrigTabletOp::operator()(ObTabletBindingMdsUserData &data)
{
  int ret = OB_SUCCESS;
  data.hidden_tablet_id_.reset();
  if (OB_INVALID_VERSION != schema_version_) {
    data.redefined_ = true;
    data.snapshot_version_ = OB_INVALID_VERSION; // will be fill back on commit
    data.schema_version_ = schema_version_;
  }
  return ret;
};

int ObTabletUnbindMdsHelper::unbind_hidden_tablets_from_orig_tablets(
    ObLS &ls,
    const ObBatchUnbindTabletArg &arg,
    const share::SCN &replay_scn,
    mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;
  for (int64_t i = 0; OB_SUCC(ret) && i < arg.orig_tablet_ids_.count(); i++) {
    const ObTabletID &orig_tablet = arg.orig_tablet_ids_.at(i);
    ObUnbindHiddenTabletFromOrigTabletOp op(arg.schema_version_);
    if (OB_FAIL(ObTabletBindingHelper::modify_tablet_binding_new_mds(ls, orig_tablet, replay_scn, ctx, op))) {
    }
  }
  return ret;
}

int ObSetRwDefensiveOp::operator()(ObTabletBindingMdsUserData &data)
{
  int ret = OB_SUCCESS;
  data.redefined_ = false;
  data.snapshot_version_ = OB_INVALID_VERSION; // will be fill back on commit
  data.schema_version_ = schema_version_;
  return ret;
};

int ObSetWriteDefensiveOp::operator()(ObTabletBindingMdsUserData &data)
{
  int ret = OB_SUCCESS;
  data.redefined_ = false;
  data.schema_version_ = schema_version_;
  return ret; 
};

int ObTabletUnbindMdsHelper::set_redefined_versions_for_hidden_tablets(
    ObLS &ls,
    const ObBatchUnbindTabletArg &arg,
    const share::SCN &replay_scn,
    mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;
  for (int64_t i = 0; OB_SUCC(ret) && i < arg.hidden_tablet_ids_.count(); i++) {
    const ObTabletID &hidden_tablet = arg.hidden_tablet_ids_.at(i);
    ObSetRwDefensiveOp op(arg.schema_version_);
    if (OB_FAIL(ObTabletBindingHelper::modify_tablet_binding_new_mds(ls, hidden_tablet, replay_scn, ctx, op))) {
    }
  }
  return ret;
}

int ObTabletUnbindMdsHelper::modify_tablet_binding_for_unbind(const ObBatchUnbindTabletArg &arg, const share::SCN &replay_scn, mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;
  ObLS *tenant_ls = nullptr;
  if (OB_FAIL(ObTabletBindingHelper::get_ls(tenant_ls))) {
  } else {
    ObLS &ls = *tenant_ls;
    if (OB_FAIL(unbind_hidden_tablets_from_orig_tablets(ls, arg, replay_scn, ctx))) {
    } else if (arg.is_redefined()) {
      if (OB_FAIL(set_redefined_versions_for_hidden_tablets(ls, arg, replay_scn, ctx))) {
      }
    }
  }
  return ret;
}

ObTabletBindingMdsArg::ObTabletBindingMdsArg() : tablet_ids_(), binding_datas_()
{
  reset();
}

bool ObTabletBindingMdsArg::is_valid() const
{
  return !tablet_ids_.empty() && tablet_ids_.count() == binding_datas_.count();
}

void ObTabletBindingMdsArg::reset()
{

  tablet_ids_.reset();
  binding_datas_.reset();
}


OB_SERIALIZE_MEMBER(ObTabletBindingMdsArg, tablet_ids_, binding_datas_);

int ObTabletBindingMdsHelper::get_sorted_tablets(const ObIArray<ObTabletID> &tablet_ids,
    ObArray<ObTabletID> &sorted_tablet_ids,
    ObMySQLTransaction &trans)
{
  int ret = OB_SUCCESS;
  sorted_tablet_ids.reset();
  ObArray<ObTabletTablePair> tablet_infos;
  if (OB_FAIL(ObTabletMappingTableOperator::batch_get(trans, tablet_ids, tablet_infos))) {
  } else if (OB_UNLIKELY(tablet_ids.count() != tablet_infos.count())) {
    ret = OB_ERR_UNEXPECTED;
    LOG_WARN("invalid tablet info count", K(ret), K(tablet_ids), K(tablet_infos));
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < tablet_ids.count(); i++) {
    if (OB_FAIL(sorted_tablet_ids.push_back(tablet_ids.at(i)))) {
    }
  }
  if (OB_SUCC(ret)) {
    lib::ob_sort(sorted_tablet_ids.begin(), sorted_tablet_ids.end(), TabletIDCmp());
  }
  return ret;
}

int ObTabletBindingMdsHelper::batch_get_tablet_binding(
    const int64_t abs_timeout_us,
    const ObBatchGetTabletBindingArg &arg,
    ObBatchGetTabletBindingRes &res)
{
  int ret = OB_SUCCESS;

  if (OB_UNLIKELY(!arg.is_valid())) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid argument", K(ret), K(arg));
  } else {
    SERVER_MODULE_SCOPE {
      ObLS *tenant_ls = nullptr;
      if (OB_FAIL(ObTabletBindingHelper::get_ls(tenant_ls))) {
      } else {
        for (int64_t i = 0; OB_SUCC(ret) && i < arg.tablet_ids_.count(); i++) {
          const ObTabletID &tablet_id = arg.tablet_ids_.at(i);
          ObTabletHandle tablet_handle;
          ObTabletBindingMdsUserData data;
          if (OB_FAIL(ObTabletBindingHelper::get_tablet_for_new_mds(
                  *tenant_ls, tablet_id, share::SCN::invalid_scn(), tablet_handle))) {
          } else if (OB_FAIL(tablet_handle.get_obj()->ObITabletMdsInterface::get_ddl_data(share::SCN::max_scn(), data, abs_timeout_us - ObTimeUtility::current_time()))) {
          } else if (OB_FAIL(res.binding_datas_.push_back(data))) {
          }

          // currently not support to read uncommitted mds set by this transaction, so check and avoid such usage
          if (OB_SUCC(ret) && arg.check_committed_) {
            ObTabletBindingMdsUserData tmp_data;
            mds::MdsWriter writer;
            mds::TwoPhaseCommitState trans_stat;
            share::SCN trans_version;
            if (OB_FAIL(tablet_handle.get_obj()->get_latest_ddl_data(tmp_data, writer, trans_stat, trans_version))) {
              if (OB_EMPTY_RESULT == ret) {
                ret = OB_SUCCESS;
              } else {
                LOG_WARN("failed to get latest ddl data", K(ret));
              }
            } else if (OB_UNLIKELY(trans_stat != mds::TwoPhaseCommitState::ON_COMMIT)) {
              ret = OB_EAGAIN;
              LOG_WARN("check committed failed", K(ret), K(tablet_id), K(tmp_data), K(trans_stat));
            }
          }
        }
      }
    }
  }
  return ret;
}

int ObTabletBindingMdsHelper::get_tablet_binding_mds_by_rpc(const ObIArray<ObTabletID> &tablet_ids,
    const int64_t abs_timeout_us,
    ObIArray<ObTabletBindingMdsUserData> &datas)
{
  int ret = OB_SUCCESS;
  obcall::ObBatchGetTabletBindingArg arg;
  obcall::ObBatchGetTabletBindingRes res;
  if (OB_FAIL(arg.init(tablet_ids, true/*check_committed*/))) {
  } else if (OB_FAIL(ex_rpc::sync_call([&]{
    return batch_get_tablet_binding(abs_timeout_us, arg, res);
  }))) {
  }
  if (OB_SUCC(ret)) {
    if (OB_FAIL(datas.assign(res.binding_datas_))) {
    }
  }
  return ret;
}

int ObTabletBindingMdsHelper::modify_tablet_binding_for_create(const obcall::ObBatchCreateTabletArg &arg,
    const int64_t abs_timeout_us,
    ObMySQLTransaction &trans)
{
  int ret = OB_SUCCESS;
  if (OB_SUCC(ret)) {
    ObArray<ObTabletID> batch_tablet_ids;
    ObArray<ObBindHiddenTabletToOrigTabletOp> batch_ops;
    for (int64_t i = 0; OB_SUCC(ret) && i < arg.tablets_.count(); i++) {
      const ObCreateTabletInfo &info = arg.tablets_[i];
      const bool is_last = i == arg.tablets_.count() - 1;
      if (ObTabletCreateDeleteHelper::is_pure_hidden_tablets(info)) {
        ObBindHiddenTabletToOrigTabletOp op(info);
        if (OB_FAIL(batch_tablet_ids.push_back(info.data_tablet_id_))) {
        } else if (OB_FAIL(batch_ops.push_back(op))) {
        }
      }
      if (OB_FAIL(ret)) {
      } else if (is_last || batch_tablet_ids.count() >= ObTabletBindingMdsArg::BATCH_TABLET_CNT) {
        if (OB_FAIL(modify_tablet_binding_batch_(batch_tablet_ids, abs_timeout_us,
                ModifyBindingByOps<ObBindHiddenTabletToOrigTabletOp>(batch_ops), trans))) {
        } else {
          batch_tablet_ids.reuse();
          batch_ops.reuse();
        }
      }
    }
    if (OB_SUCC(ret) && OB_UNLIKELY(!batch_tablet_ids.empty() || !batch_ops.empty())) {
      ret = OB_ERR_UNEXPECTED;
      LOG_WARN("batch not consumed out", K(ret), K(batch_tablet_ids), K(batch_ops));
    }
  }

  if (OB_SUCC(ret)) {
    ObArray<ObTabletID> batch_tablet_ids;
    ObArray<ObBindLobTabletToDataTabletOp> batch_ops;
    for (int64_t i = 0; OB_SUCC(ret) && i < arg.tablets_.count(); i++) {
      const ObCreateTabletInfo &info = arg.tablets_[i];
      const bool is_last = i == arg.tablets_.count() - 1;
      bool has_lob = false;
      if (OB_FAIL(ObTabletBindingHelper::has_lob_tablets(arg, info, has_lob))) {
      } else if (has_lob) {
        ObBindLobTabletToDataTabletOp op(arg, info);
        if (OB_FAIL(batch_tablet_ids.push_back(info.data_tablet_id_))) {
        } else if (OB_FAIL(batch_ops.push_back(op))) {
        }
      }
      if (OB_FAIL(ret)) {
      } else if (is_last || batch_tablet_ids.count() >= ObTabletBindingMdsArg::BATCH_TABLET_CNT) {
        if (OB_FAIL(modify_tablet_binding_batch_(batch_tablet_ids, abs_timeout_us,
                ModifyBindingByOps<ObBindLobTabletToDataTabletOp>(batch_ops), trans))) {
        } else {
          batch_tablet_ids.reuse();
          batch_ops.reuse();
        }
      }
    }
    if (OB_SUCC(ret) && OB_UNLIKELY(!batch_tablet_ids.empty() || !batch_ops.empty())) {
      ret = OB_ERR_UNEXPECTED;
      LOG_WARN("batch not consumed out", K(ret), K(batch_tablet_ids), K(batch_ops));
    }
  }
  return ret;
}

// redefined_schema_version is not OB_INVALID_VERSION iff for ddl succ
int ObTabletBindingMdsHelper::modify_tablet_binding_for_unbind(
    const ObIArray<ObTabletID> &orig_tablet_ids,
    const ObIArray<ObTabletID> &hidden_tablet_ids,
    const int64_t redefined_schema_version,
    const int64_t abs_timeout_us,
    ObMySQLTransaction &trans)
{
  int ret = OB_SUCCESS;
  if (OB_SUCC(ret)) {
    ObUnbindHiddenTabletFromOrigTabletOp op(redefined_schema_version);
    if (OB_FAIL(modify_tablet_binding_(orig_tablet_ids, abs_timeout_us, op, trans))) {
    }
  }

  if (OB_SUCC(ret) && OB_INVALID_VERSION != redefined_schema_version) {
    ObSetRwDefensiveOp op(redefined_schema_version);
    if (OB_FAIL(modify_tablet_binding_(hidden_tablet_ids, abs_timeout_us, op, trans))) {
    }
  }
  return ret;
}

int ObTabletBindingMdsHelper::modify_tablet_binding_for_rw_defensive(const ObIArray<ObTabletID> &tablet_ids,
    const int64_t schema_version,
    const int64_t abs_timeout_us,
    ObMySQLTransaction &trans)
{
  int ret = OB_SUCCESS;
  ObSetRwDefensiveOp op(schema_version);
  if (OB_UNLIKELY(OB_INVALID_VERSION == schema_version)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid arg", K(ret), K(schema_version), K(tablet_ids));
  } else if (OB_FAIL(modify_tablet_binding_(tablet_ids, abs_timeout_us, op, trans))) {
  }
  return ret;
}

int ObTabletBindingMdsHelper::modify_tablet_binding_for_write_defensive(const ObIArray<ObTabletID> &tablet_ids,
    const int64_t schema_version,
    const int64_t abs_timeout_us,
    ObMySQLTransaction &trans)
{
  int ret = OB_SUCCESS;
  ObSetWriteDefensiveOp op(schema_version);
  if (OB_UNLIKELY(OB_INVALID_VERSION == schema_version)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid arg", K(ret), K(schema_version), K(tablet_ids));
  } else if (OB_FAIL(modify_tablet_binding_(tablet_ids, abs_timeout_us, op, trans))) {
  }
  return ret;
}

template<typename F>
int ObTabletBindingMdsHelper::modify_tablet_binding_batch_(const ObIArray<ObTabletID> &tablet_ids,
    const int64_t abs_timeout_us,
    F &&op,
    ObMySQLTransaction &trans)
{
  int ret = OB_SUCCESS;
  if (!tablet_ids.empty()) {
    ObArray<ObTabletBindingMdsUserData> old_datas;
    if (OB_FAIL(get_tablet_binding_mds_by_rpc(tablet_ids, abs_timeout_us, old_datas))) {
    } else {
      ObTabletBindingMdsArg arg;
      if (OB_FAIL(arg.tablet_ids_.assign(tablet_ids))) {
      }
      for (int64_t i = 0; OB_SUCC(ret) && i < old_datas.count(); i++) {
        if (OB_FAIL(arg.binding_datas_.push_back(old_datas.at(i)))) {
        } else {
          ObTabletBindingMdsUserData &data = arg.binding_datas_.at(arg.binding_datas_.count() - 1);
          ret = op(i, data);
        }
      }
      if (OB_FAIL(ret)) {
      } else if (OB_UNLIKELY(!arg.is_valid())) {
        ret = OB_INVALID_ARGUMENT;
        LOG_WARN("invalid args", K(ret), K(arg));
      } else if (OB_FAIL(register_mds_(arg, trans))) {
      }
    }
  }
  return ret;
}

template<typename F>
int ObTabletBindingMdsHelper::modify_tablet_binding_(const ObIArray<ObTabletID> &tablet_ids,
    const int64_t abs_timeout_us,
    F &&op,
    ObMySQLTransaction &trans)
{
  int ret = OB_SUCCESS;
  if (!tablet_ids.empty()) {
    ObArray<ObTabletID> sorted_tablet_ids;
    ObArray<ObTabletID> this_batch_tablet_ids;
    if (OB_FAIL(get_sorted_tablets(tablet_ids, sorted_tablet_ids, trans))) {
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < sorted_tablet_ids.count(); i++) {
      const ObTabletID &tablet_id = sorted_tablet_ids.at(i);
      const bool is_last = i == sorted_tablet_ids.count() - 1;
      if (OB_FAIL(this_batch_tablet_ids.push_back(tablet_id))) {
      } else if (is_last || this_batch_tablet_ids.count() >= ObTabletBindingMdsArg::BATCH_TABLET_CNT) {
        if (OB_FAIL(modify_tablet_binding_batch_(this_batch_tablet_ids, abs_timeout_us,
                ModifyBindingByOp<F>(op), trans))) {
        } else {
          this_batch_tablet_ids.reuse();
        }
      }
    }
    if (OB_SUCC(ret) && OB_UNLIKELY(!this_batch_tablet_ids.empty())) {
      ret = OB_ERR_UNEXPECTED;
      LOG_WARN("batch not consumed out", K(ret), K(this_batch_tablet_ids));
    }
  }
  return ret;
}

int ObTabletBindingMdsHelper::register_mds_(
    const ObTabletBindingMdsArg &arg,
    ObMySQLTransaction &trans)
{
  int ret = OB_SUCCESS;
  sqlclient::ObISQLConnection *isql_conn = nullptr;
  if (OB_ISNULL(isql_conn = trans.get_connection())) {
    ret = OB_ERR_UNEXPECTED;
    LOG_WARN("invalid connection", K(ret));
  } else {
    const int64_t size = arg.get_serialize_size();
    ObArenaAllocator allocator("TblBind");
    char *buf = nullptr;
    int64_t pos = 0;
    if (OB_ISNULL(buf = static_cast<char *>(allocator.alloc(size)))) {
      ret = OB_ALLOCATE_MEMORY_FAILED;
      LOG_WARN("failed to allocate", K(ret));
    } else if (OB_FAIL(arg.serialize(buf, size, pos))) {
    } else if (OB_FAIL(query::ObInnerSQLConnectionAccess::register_multi_data_source(
                   isql_conn, ObTxDataSourceType::TABLET_BINDING, buf, pos))) {
    }
  }
  return ret;
}

int ObTabletBindingMdsHelper::on_register(const char* buf, const int64_t len, mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;
  int64_t pos = 0;
  ObTabletBindingMdsArg arg;
  if (OB_FAIL(arg.deserialize(buf, len, pos))) {
  } else if (OB_FAIL(modify_(arg, SCN::invalid_scn(), ctx))) {
  }
  return ret;
}

int ObTabletBindingMdsHelper::on_replay(const char* buf, const int64_t len, const share::SCN &scn, mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;
  int64_t pos = 0;
  ObTabletBindingMdsArg arg;
  if (OB_FAIL(arg.deserialize(buf, len, pos))) {
  } else if (OB_FAIL(modify_(arg, scn, ctx))) {
  }
  return ret;
}

int ObTabletBindingMdsHelper::modify_(
    const ObTabletBindingMdsArg &arg,
    const share::SCN &scn,
    mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;
  ObLS *tenant_ls = nullptr;
  if (OB_UNLIKELY(!arg.is_valid())) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid arg", K(ret), K(arg));
  } else if (OB_FAIL(::oceanbase::share::server_service<::oceanbase::storage::ObLSService>()->get_ls(tenant_ls))) {
  }
  for (int64_t i = 0; OB_SUCC(ret) && i < arg.tablet_ids_.count(); i++) {
    const ObTabletID &tablet_id = arg.tablet_ids_[i];
    if (OB_FAIL(set_tablet_binding_mds_(
            *tenant_ls, tablet_id, scn, arg.binding_datas_[i], ctx))) {
    }
  }
  LOG_INFO("modify tablet binding data", K(ret), K(scn), K(ctx.get_writer()), K(arg));
  return ret;
}

int ObTabletBindingMdsHelper::set_tablet_binding_mds_(
    ObLS &ls,
    const ObTabletID &tablet_id,
    const share::SCN &replay_scn,
    const ObTabletBindingMdsUserData &data,
    mds::BufferCtx &ctx)
{
  MDS_TG(100_ms);
  int ret = OB_SUCCESS;
  if (!replay_scn.is_valid()) {
    mds::MdsCtx &user_ctx = static_cast<mds::MdsCtx &>(ctx);
    if (CLICK_FAIL(ls.get_tablet_svr()->set_ddl_info(tablet_id, data, user_ctx, 0/*lock_timeout_us*/))) {
      if (OB_ERR_EXCLUSIVE_LOCK_CONFLICT == ret) {
        ret = OB_EAGAIN;
      } else {
        LOG_WARN("failed to save tablet binding info", K(ret));
      }
    }
  } else {
    ObTabletBindingReplayExecutor replay_executor;
    if (CLICK_FAIL(replay_executor.init(ctx, data, replay_scn))) {
      LOG_ERROR("failed to init replay executor", K(ret));
    } else if (CLICK_FAIL(replay_executor.execute(replay_scn, tablet_id))) {
      if (OB_EAGAIN != ret) {
        LOG_ERROR("failed to replay tablet binding log", K(ret));
      }
    }
  }
  return ret;
}

int ObTabletUnbindLobMdsHelper::modify_tablet_binding_for_unbind_lob_(const ObBatchUnbindLobTabletArg &arg, const share::SCN &replay_scn, mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;
  ObLS *tenant_ls = nullptr;
  if (OB_FAIL(ObTabletBindingHelper::get_ls(tenant_ls))) {
  } else {
    ObLS &ls = *tenant_ls;
    for (int64_t i = 0; OB_SUCC(ret) && i < arg.data_tablet_ids_.count(); i++) {
      const ObTabletID &data_tablet_id = arg.data_tablet_ids_.at(i);
      if (OB_FAIL(ObTabletBindingHelper::modify_tablet_binding_new_mds(ls, data_tablet_id,
              replay_scn, ctx, ClearLobTabletId()))) {
      }
    }
  }
  return ret;
}

int ObTabletUnbindLobMdsHelper::on_register(const char* buf, const int64_t len, mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;
  int64_t pos = 0;
  ObBatchUnbindLobTabletArg arg;
  if (OB_FAIL(arg.deserialize(buf, len, pos))) {
  } else if (OB_FAIL(modify_tablet_binding_for_unbind_lob_(arg, SCN::invalid_scn(), ctx))) {
  } else {
    LOG_INFO("register unbind lob success", K(arg), K(ctx));
  }
  return ret;
}

int ObTabletUnbindLobMdsHelper::on_replay(const char* buf, const int64_t len, const share::SCN &scn, mds::BufferCtx &ctx)
{
  int ret = OB_SUCCESS;
  int64_t pos = 0;
  ObBatchUnbindLobTabletArg arg;
  if (OB_FAIL(arg.deserialize(buf, len, pos))) {
  } else if (OB_FAIL(modify_tablet_binding_for_unbind_lob_(arg, scn, ctx))) {
  } else {
    LOG_INFO("replay unbind lob success", K(arg), K(ctx));
  }
  return ret;
}

} // namespace storage
} // namespace oceanbase
