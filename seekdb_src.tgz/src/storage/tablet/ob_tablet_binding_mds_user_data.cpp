/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "storage/tablet/ob_tablet_binding_mds_user_data.h"
#include "storage/tablet/ob_tablet_binding_info.h"

#define USING_LOG_PREFIX STORAGE

namespace oceanbase
{
namespace storage
{
ObTabletBindingMdsUserData::ObTabletBindingMdsUserData()
  : snapshot_version_(INT64_MAX),
    schema_version_(INT64_MAX),
    data_tablet_id_(),
    hidden_tablet_id_(),
    lob_meta_tablet_id_(),
    lob_piece_tablet_id_(),
    redefined_(false)
{
}

void ObTabletBindingMdsUserData::reset()
{
  redefined_ = false;
  snapshot_version_ = INT64_MAX;
  schema_version_ = INT64_MAX;
  data_tablet_id_.reset();
  hidden_tablet_id_.reset();
  lob_meta_tablet_id_.reset();
  lob_piece_tablet_id_.reset();
}

void ObTabletBindingMdsUserData::set_default_value()
{
  redefined_ = false;
  snapshot_version_ = 0;
  schema_version_ = 0;
  data_tablet_id_.reset();
  hidden_tablet_id_.reset();
  lob_meta_tablet_id_.reset();
  lob_piece_tablet_id_.reset();
}

bool ObTabletBindingMdsUserData::is_valid() const
{
  return snapshot_version_ != INT64_MAX && schema_version_ != INT64_MAX;
}

int ObTabletBindingMdsUserData::assign(const ObTabletBindingMdsUserData &other)
{
  int ret = OB_SUCCESS;
  redefined_ = other.redefined_;
  snapshot_version_ = other.snapshot_version_;
  schema_version_ = other.schema_version_;
  data_tablet_id_ = other.data_tablet_id_;
  hidden_tablet_id_ = other.hidden_tablet_id_;
  lob_meta_tablet_id_ = other.lob_meta_tablet_id_;
  lob_piece_tablet_id_ = other.lob_piece_tablet_id_;
  return ret;
}



void ObTabletBindingMdsUserData::on_commit(const share::SCN &commit_version, const share::SCN &commit_scn)
{
  if (OB_INVALID_VERSION == snapshot_version_) {
    // unbind has set the mds with snapshot_version_ of -1, indicating that we need to fill in the commit version here
    snapshot_version_ = commit_version.get_val_for_tx();
  }
  LOG_INFO("binding mds commit", K(redefined_), K(snapshot_version_), K(commit_version));
  return;
}

int ObTabletBindingMdsUserData::deep_copy(char *buf, const int64_t buf_len, ObIStorageMetaObj *&value) const
{
  int ret = OB_SUCCESS;
  value = nullptr;
  const int64_t deep_copy_size = get_deep_copy_size();

  if (OB_ISNULL(buf) || OB_UNLIKELY(buf_len < deep_copy_size)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invaild argument", K(ret), KP(buf), K(buf_len), K(deep_copy_size));
  } else {
    ObTabletBindingMdsUserData *aux_tablet_info = new (buf) ObTabletBindingMdsUserData();
    if (OB_FAIL(aux_tablet_info->assign(*this))) {
    } else {
      value = aux_tablet_info;
    }

    if (OB_FAIL(ret)) {
      aux_tablet_info->~ObTabletBindingMdsUserData();
    }
  }

  return ret;
}

int64_t ObTabletBindingMdsUserData::get_deep_copy_size() const
{
  return sizeof(ObTabletBindingMdsUserData);
}

OB_SERIALIZE_MEMBER(
  ObTabletBindingMdsUserData,
  redefined_,
  snapshot_version_,
  schema_version_,
  data_tablet_id_,
  hidden_tablet_id_,
  lob_meta_tablet_id_,
  lob_piece_tablet_id_);
} // namespace storage
} // namespace oceanbase
