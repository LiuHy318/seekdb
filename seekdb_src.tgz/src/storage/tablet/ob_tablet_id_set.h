/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_TABLET_ID_SET
#define OCEANBASE_STORAGE_OB_TABLET_ID_SET

#include <stdint.h>
#include "lib/hash/ob_hashset.h"
#include "lib/lock/ob_bucket_lock.h"
#include "common/ob_tablet_id.h"

namespace oceanbase
{
namespace storage
{
class ObTabletIDSet final
{
  typedef common::hash::ObHashSet<common::ObTabletID, hash::NoPthreadDefendMode> NonLockedHashSet;
public:
  ObTabletIDSet();
  ~ObTabletIDSet();
  ObTabletIDSet(const ObTabletIDSet&) = delete;
  ObTabletIDSet &operator=(const ObTabletIDSet&) = delete;
public:
  int init(const uint64_t bucket_lock_bucket_cnt);
  int set(const common::ObTabletID &tablet_id);
  int exist(const common::ObTabletID &tablet_id);
  int erase(const common::ObTabletID &tablet_id);
  int clear() { return id_set_.clear(); }
  int64_t size() const { return id_set_.size(); }

  template<class Operator>
  int foreach(Operator &op)
  {
    int ret = common::OB_SUCCESS;
    bool locked = false;
    while (OB_SUCC(ret) && !locked) {
      common::ObBucketTryRLockAllGuard lock_guard(bucket_lock_);
      if (OB_FAIL(lock_guard.get_ret()) && common::OB_EAGAIN != ret) {
        STORAGE_LOG(WARN, "fail to lock all tablet id set", K(ret));
      } else if (common::OB_EAGAIN == ret) {
        // try again after 1ms sleep.
        ob_usleep(1000);
        ret = common::OB_SUCCESS;
      } else {
        locked = true;
        NonLockedHashSet::const_iterator iter = id_set_.begin();
        for (; OB_SUCC(ret) && iter != id_set_.end(); ++iter) {
          const ObTabletID &tablet_id = iter->first;
          if (OB_FAIL(op(tablet_id))) {
          }
        }
      }
    }
    return ret;
  }
  void destroy();
private:
  NonLockedHashSet id_set_;
  common::ObBucketLock bucket_lock_;
  bool is_inited_;
};
} // namespace storage
} // namespace oceanbase

#endif // OCEANBASE_STORAGE_OB_TABLET_ID_SET
