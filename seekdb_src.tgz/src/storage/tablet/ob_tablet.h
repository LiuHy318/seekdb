/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_TABLET_OB_TABLET
#define OCEANBASE_STORAGE_TABLET_OB_TABLET

#include "lib/atomic/ob_atomic.h"
#include "lib/container/ob_fixed_array.h"
#include "lib/lock/ob_tc_rwlock.h"
#include "storage/ob_storage_schema.h"
#include "storage/ob_storage_struct.h"
#include "storage/ob_storage_table_guard.h"
#include "storage/compaction/ob_medium_compaction_mgr.h"
#include "storage/memtable/ob_memtable.h"
#include "storage/meta_mem/ob_tablet_map_key.h"
#include "storage/meta_mem/ob_tablet_pointer_handle.h"
#include "storage/tablet/ob_tablet_complex_addr.h"
#include "storage/tablet/ob_tablet_member_wrapper.h"
#include "storage/tablet/ob_tablet_memtable_mgr.h"
#include "storage/tablet/ob_tablet_meta.h"
#include "storage/tablet/ob_tablet_table_store.h"
#include "storage/tablet/ob_tablet_table_store_flag.h"
#include "storage/tablet/ob_tablet_mds_data.h"
#include "storage/tablet/ob_tablet_mds_data_cache.h"
#include "storage/tablet/ob_tablet_block_aggregated_info.h"
#include "storage/tablet/ob_tablet_block_header.h"
#include "storage/tablet/ob_tablet_space_usage.h"
#include "storage/tx/ob_trans_define.h"
#include "share/scn.h"
#include "ob_i_tablet_mds_customized_interface.h"
#include <type_traits>

namespace oceanbase
{
namespace share
{
struct ObTabletAutoincInterval;
struct ObTabletLocalChecksumItem;
class ObTabletRuntimeInfo;
}

namespace logservice
{
class ObLogHandler;
}

namespace memtable
{
class ObIMultiSourceDataUnit;
}

namespace blocksstable
{
class ObSSTable;
class ObSSTableCloneParam;
}

namespace compaction
{
class ObExtraMediumInfo;
}

namespace transaction
{
class ObTransID;
}

namespace storage
{
class ObTabletReplayExecutor;
class ObLS;
class ObIMemtable;
class ObStoreCtx;
class ObTableHandleV2;
class ObFreezer;
class ObTabletDDLInfo;
class ObTabletDDLKvMgr;
class ObDDLKVHandle;
class ObTabletTableIterator;
class ObMetaDiskAddr;
class ObUpdateTabletPointerParam;
class ObTabletCreateDeleteMdsUserData;
class ObTabletBindingMdsUserData;
class ObMemtableArray;
class ObMacroInfoIterator;
class ObMdsRowIterator;
class ObMdsMiniMergeOperator;
struct ObTabletDirectLoadInsertParam;
struct ObTruncateInfoArray;

struct ObTableStoreCache
{
public:
  ObTableStoreCache();
  ~ObTableStoreCache() { reset(); }
  void reset();
  int init(
      const ObSSTableArray &major_tables,
      const ObSSTableArray &minor_tables);
  TO_STRING_KV(K_(last_major_snapshot_version), K_(major_table_cnt),
      K_(minor_table_cnt), K_(recycle_version), K_(last_major_column_count),
      K_(last_major_macro_block_cnt),
      K_(last_major_compressor_type), K_(last_major_latest_row_store_type));

public:
  int64_t last_major_snapshot_version_;
  int64_t major_table_cnt_;
  int64_t minor_table_cnt_;
  int64_t recycle_version_;
  int64_t last_major_column_count_;
  int64_t last_major_macro_block_cnt_;
  common::ObCompressorType last_major_compressor_type_;
  common::ObRowStoreType last_major_latest_row_store_type_;
};

class ObTablet final : public ObITabletMdsCustomizedInterface
{
  friend class ObLSTabletService;
  friend class ObTabletPointer;
  friend class ObTabletMediumInfoReader;
  friend class ObTabletTruncateInfoReader;
  friend class ObTabletReplayExecutor;
  friend class ObTabletPersister;
  friend class ObTabletPointerMap;
  friend class ObTabletTableIterator;
public:
  int get_mds_table_handle_for_diagnostics(
      mds::MdsTableHandle &handle,
      const bool create_if_not_exist) const
  {
    return get_mds_table_handle_(handle, create_if_not_exist);
  }
  typedef ObMetaObjGuard<ObTabletDDLKvMgr> ObDDLKvMgrHandle;
  typedef common::ObSEArray<ObTableHandleV2, BASIC_MEMSTORE_CNT> ObTableHandleArray;
  typedef common::ObFixedArray<share::schema::ObColDesc, common::ObIAllocator> ColDescArray;
public:
  explicit ObTablet(const bool is_external_tablet = false);
  ObTablet(const ObTablet&) = delete;
  ObTablet &operator=(const ObTablet&) = delete;
  virtual ~ObTablet();
public:
  void reset();
  bool is_ls_inner_tablet() const;
  bool is_ls_tx_data_tablet() const;
  bool is_ls_tx_ctx_tablet() const;
  void update_wash_score(const int64_t score);
  void inc_ref();
  int64_t dec_ref();
  int64_t get_ref() const { return ATOMIC_LOAD(&ref_cnt_); }
  int64_t get_wash_score() const { return ATOMIC_LOAD(&wash_score_); }
  int get_max_sync_medium_scn(int64_t &max_medium_scn) const;
  int get_max_sync_storage_schema_version(int64_t &max_schema_version) const;
  inline int64_t get_last_major_snapshot_version() const { return table_store_cache_.last_major_snapshot_version_; }
  inline int64_t get_major_table_count() const { return table_store_cache_.major_table_cnt_; }
  inline int64_t get_minor_table_count() const { return table_store_cache_.minor_table_cnt_; }
  inline int64_t get_recycle_version() const { return table_store_cache_.recycle_version_; }
  inline int64_t get_last_major_column_count() const { return table_store_cache_.last_major_column_count_; }
  inline int64_t get_last_major_total_macro_block_count() const { return table_store_cache_.last_major_macro_block_cnt_; }
  inline common::ObCompressorType get_last_major_compressor_type() const { return table_store_cache_.last_major_compressor_type_; }
  inline common::ObRowStoreType get_last_major_latest_row_store_type() const { return table_store_cache_.last_major_latest_row_store_type_; }
  inline common::ObTabletID get_tablet_id() const { return tablet_meta_.tablet_id_; }
  inline common::ObTabletID get_data_tablet_id() const { return tablet_meta_.data_tablet_id_; }
  inline int64_t get_last_compaction_scn() const { return tablet_meta_.extra_medium_info_.last_medium_scn_; }
  inline bool is_user_tablet() const { return tablet_meta_.tablet_id_.is_user_tablet(); }
  inline bool is_user_data_table() const { return tablet_meta_.table_store_flag_.is_user_data_table(); }
  int get_mds_table_rec_scn(share::SCN &rec_scn) const;
  int mds_table_flush(const share::SCN &decided_scn);
  int scan_mds_table_with_op(
      const int64_t mds_construct_sequence,
      ObMdsMiniMergeOperator &op) const;
  int get_valid_last_major_column_count(int64_t &last_major_column_cnt) const;

public:
  // first time create tablet
  int init_for_first_time_creation(
      common::ObArenaAllocator &allocator,
      const common::ObTabletID &tablet_id,
      const common::ObTabletID &data_tablet_id,
      const share::SCN &create_scn,
      const int64_t snapshot_version,
      const ObCreateTabletSchema &storage_schema,
      const bool need_create_empty_major_sstable,
      const share::SCN &clog_checkpoint_scn,
      const share::SCN &mds_checkpoint_scn,
      const bool micro_index_clustered,
      ObFreezer *freezer,
      const share::ObForkTabletInfo &fork_info = share::ObForkTabletInfo());
  int init_for_physical_restore(
      common::ObArenaAllocator &allocator,
      const ObTabletMeta &tablet_meta,
      const ObStorageSchema &storage_schema);
  // dump/merge build new multi version tablet
  int init_for_merge(
      common::ObArenaAllocator &allocator,
      const ObUpdateTableStoreParam &param,
      const ObTablet &old_tablet);
  bool is_external_tablet() const { return is_external_tablet_; }
  //batch update table store with range cut
  int init_for_sstable_replace(
      common::ObArenaAllocator &allocator,
      const ObBatchUpdateTableStoreParam &param,
      const ObTablet &old_tablet);
  // update medium compaction info mgr and build new tablet
  int init_with_update_medium_info(
      common::ObArenaAllocator &allocator,
      const ObTablet &old_tablet,
      const bool clear_wait_check_flag);

  int init_with_updated_members(
      common::ObArenaAllocator &allocator,
      const ObTablet &old_tablet,
      const int64_t snapshot_version
);
  // init for mds table mini merge
  int init_with_mds_sstable(
      common::ObArenaAllocator &allocator,
      const ObTablet &old_tablet,
      const share::SCN &flush_scn,
      const ObUpdateTableStoreParam &param);

  // batch replace sstables without data modification
  int init_for_defragment(
      common::ObArenaAllocator &allocator,
      const ObIArray<storage::ObITable *> &tables,
      const ObTablet &old_tablet);

  // init empty tablet for delete
  int init_empty_shell(
      ObArenaAllocator &allocator,
      const ObTablet &old_tablet);

  bool is_valid() const;
  // refresh memtable and update tablet_addr_ and table_store_addr_ sequence, only used by slog ckpt
  int refresh_memtable_and_update_seq(const uint64_t seq);
  int32_t get_version() const { return version_; }
  void dec_macro_ref_cnt();
  int inc_macro_ref_cnt();
  // these interfaces is only for tiny mode
  // load_$member: member will always exist in disk(slog file/macro block), so read from disk then deserialize
  // fetch_$member: member may exist in memory or disk, if in memory, get it directly, if in disk,
  //                read from disk then put into kv cache, and return kv cache handle for caller
  int fetch_table_store(ObTabletMemberWrapper<ObTabletTableStore> &wrapper) const;
  int load_macro_info(
      const int64_t ls_epoch,
      common::ObArenaAllocator &allocator,
      ObTabletMacroInfo *&tablet_macro_info,
      bool &in_memory) const;
  int load_storage_schema(
      common::ObIAllocator &allocator,
      ObStorageSchema *&storage_schema) const;
  int read_medium_info_list(
      common::ObArenaAllocator &allocator,
      const compaction::ObMediumCompactionInfoList *&medium_info_list) const;
  void check_truncate_info_state(
      const common::ObVersionRange &read_version_range,
      bool &has_truncate_flag,
      bool &contain_truncate_info);
  bool has_truncate_info() const;
  int read_truncate_info_array(
      common::ObArenaAllocator &allocator,
      const common::ObVersionRange &read_version_range,
      const bool for_access,
      ObTruncateInfoArray &truncate_info_array);
  int get_truncate_info_newest_version(int64_t &newest_commit_version, int64_t &count);
  void set_tablet_addr(const ObMetaDiskAddr &tablet_addr);
  void set_allocator(ObArenaAllocator *allocator) { allocator_ = allocator; }
  void set_next_tablet(ObTablet* tablet) { next_tablet_ = tablet; }
  ObTablet *get_next_tablet() { return next_tablet_; }
  ObArenaAllocator *get_allocator() const { return allocator_; }
  bool is_empty_shell() const;
  // major merge or medium merge call
  bool is_data_complete() const;
  int get_ready_for_read_param(ObReadyForReadParam &parm) const;

  // serialize & deserialize
  // TODO: change the impl of serialize and get_serialize_size after rebase
  int serialize(
      char *buf,
      const int64_t len,
      int64_t &pos,
      const ObSArray<ObInlineSecondaryMeta> &meta_arr = ObSArray<ObInlineSecondaryMeta>()) const;
  int deserialize_for_replay(
    common::ObArenaAllocator &allocator,
    const char *buf,
    const int64_t len,
    int64_t &pos);

  // for normal tablet deserialize
  int load_deserialize(
      common::ObArenaAllocator &allocator,
      const char *buf,
      const int64_t len,
      int64_t &pos);
  int deserialize_post_work(
      common::ObArenaAllocator &allocator);
  int deserialize(
      common::ObArenaAllocator &allocator,
      const char *buf,
      const int64_t len,
      int64_t &pos);
  // for 4k tablet
  int deserialize(
      const char *buf,
      const int64_t len,
      int64_t &pos);
  int release_ref_cnt(
      common::ObArenaAllocator &allocator,
      const char *buf,
      const int64_t len,
      int64_t &pos);
  int inc_snapshot_ref_cnt(
      common::ObArenaAllocator &allocator,
      const char *buf,
      const int64_t len,
      int64_t &pos);
  int64_t get_serialize_size(const ObSArray<ObInlineSecondaryMeta> &meta_arr = ObSArray<ObInlineSecondaryMeta>()) const;
  ObMetaObjGuard<ObTablet> &get_next_tablet_guard() { return next_tablet_guard_; }
  const ObMetaObjGuard<ObTablet> &get_next_tablet_guard() const { return next_tablet_guard_; }
  void set_next_tablet_guard(const ObTabletHandle &next_tablet_guard);
  void trim_tablet_list();

  // dml operation
  int insert_rows(
      ObRelativeTable &relative_table,
      ObStoreCtx &store_ctx,
      const bool check_exist,
      const ObColDescIArray &col_descs,
      ObRowsInfo &rows_info);
  int insert_row(
      ObRelativeTable &relative_table,
      ObStoreCtx &store_ctx,
      const bool check_exist,
      const ObColDescIArray &col_descs,
      blocksstable::ObDatumRow &row);
  int update_row(
      ObRelativeTable &relative_table,
      ObStoreCtx &store_ctx,
      const ObColDescIArray &col_descs,
      const ObIArray<int64_t> &update_idx,
      const blocksstable::ObDatumRow &old_row,
      blocksstable::ObDatumRow &new_row);
  int update_rows(
      ObRelativeTable &relative_table,
      ObStoreCtx &store_ctx,
      const ObColDescIArray &col_descs,
      const ObIArray<int64_t> &update_idx,
      const blocksstable::ObDatumRow *old_rows,
      ObRowsInfo &rows_info);
  int lock_row(
      ObRelativeTable &relative_table,
      ObStoreCtx &store_ctx,
      ObColDescArray &col_desc,
      blocksstable::ObDatumRow &row);
  int lock_row(
      ObRelativeTable &relative_table,
      ObStoreCtx &store_ctx,
      const blocksstable::ObDatumRowkey &rowkey);
  int check_row_locked_by_myself(
      ObRelativeTable &relative_table,
      ObStoreCtx &store_ctx,
      const blocksstable::ObDatumRowkey &rowkey,
      bool &locked);
  int get_tablet_first_second_level_meta_ids(ObIArray<blocksstable::MacroBlockId> &meta_ids) const;
  // table operation
  int get_all_tables(ObTableStoreIterator &iter) const;
  int get_all_sstables(ObTableStoreIterator &iter) const;
  int get_memtables(common::ObIArray<storage::ObITable *> &memtables) const;
  int get_ddl_kvs(common::ObIArray<ObDDLKV *> &ddl_kvs) const;
  int get_all_memtables_from_memtable_mgr(ObTableHdlArray &handle) const;
  int get_boundary_memtable_from_memtable_mgr(ObTableHandleV2 &handle) const;
  int get_protected_memtable_mgr_handle(ObProtectedMemtableMgrHandle *&handle) const;

  // get the active memtable for write or replay.
  int get_active_memtable(ObTableHandleV2 &handle) const;

  // ATTENTION!!!
  // 1. release memtables from memtable manager and this tablet.
  // 2. If a tablet may be being accessed, shouldn't call this function.
  int rebuild_memtables(const share::SCN scn);

  void reset_memtable();
  // ATTENTION!!! The following two interfaces only release memtable from memtable manager.
  int release_memtables(const share::SCN scn);
  // force release all memtables
  // used when local tablet state must be rebuilt.
  int release_memtables();

  int wait_release_memtables();

  // ATTENTION!!!
  // 1. release ddl memtables from this tablet.
  // 2. If a tablet may be being accessed, shouldn't call this function.
  int clear_ddl_memtables();

  int get_restore_status(ObTabletRestoreStatus::STATUS &restore_status) const;

  // static help function
  static int deserialize_id(
      const char *buf,
      const int64_t len,
      share::ObLSID &ls_id,
      common::ObTabletID &tablet_id);

  int build_sstable_clone_param(
      const ObITable::TableKey &table_key,
      blocksstable::ObSSTableCloneParam &clone_sstable_param) const;
  int get_ddl_kv_mgr(ObDDLKvMgrHandle &ddl_kv_mgr_handle, bool try_create = false);
  int start_direct_load_task_if_need();
  int get_ddl_sstables(ObTableStoreIterator &table_store_iter) const;
  int get_mds_sstables(ObTableStoreIterator &table_store_iter) const;
  int get_mini_minor_sstables(ObTableStoreIterator &table_store_iter) const;
  int get_table(const ObITable::TableKey &table_key, ObTableHandleV2 &handle) const;
  int get_recycle_version(const int64_t multi_version_start, int64_t &recycle_version) const;

public:
  // other
  const ObMetaDiskAddr &get_tablet_addr() const { return tablet_addr_; }
  const ObTabletMeta &get_tablet_meta() const { return tablet_meta_; }
  share::SCN get_clog_checkpoint_scn() const { return tablet_meta_.clog_checkpoint_scn_; }
  share::SCN get_mds_checkpoint_scn() const { return tablet_meta_.mds_checkpoint_scn_; }
  int64_t get_snapshot_version() const { return tablet_meta_.snapshot_version_; }
  int64_t get_multi_version_start() const { return tablet_meta_.multi_version_start_; }
  int get_snapshot_version(share::SCN &scn) const;

  //TODO huronghui.hrh: rename function for row store sstable
  const ObITableReadInfo &get_rowkey_read_info() const { return *rowkey_read_info_; }
  const ObTabletPointerHandle &get_pointer_handle() const;

  int get_meta_disk_addr(ObMetaDiskAddr &addr) const;

  int assign_pointer_handle(const ObTabletPointerHandle &ptr_hdl);

  int replay_update_storage_schema(
      const share::SCN &scn,
      const char *buf,
      const int64_t buf_size,
      int64_t &pos);
  //Deprecated interface, DONOT use it anymore
  int get_schema_version_from_storage_schema(int64_t &schema_version) const;
  // get MAX(storage_schema_version, data_schema_version on memtable)
  int get_newest_schema_version(int64_t &schema_version) const;

  int submit_medium_compaction_clog(
      compaction::ObMediumCompactionInfo &medium_info,
      ObIAllocator &allocator);
  int replay_medium_compaction_clog(
      const share::SCN &scn,
      const char *buf,
      const int64_t buf_size,
      int64_t &pos);

  int fetch_tablet_autoinc_seq_cache(
      const uint64_t cache_size,
      share::ObTabletAutoincInterval &result);

  int update_tablet_autoinc_seq(const uint64_t autoinc_seq, const bool is_tablet_creating);
  int get_kept_snapshot_info(
      const int64_t min_reserved_snapshot_on_ls,
      ObStorageSnapshotInfo &snapshot_info) const;
  int check_schema_version_elapsed(
      const int64_t schema_version,
      const bool need_wait_trans_end,
      int64_t &max_commit_version,
      transaction::ObTransID &pending_tx_id);
  int replay_schema_version_change_log(const int64_t schema_version);
  int get_tablet_runtime_info(
      share::ObTabletRuntimeInfo &runtime_info,
      share::ObTabletLocalChecksumItem &tablet_checksum) const;
  int check_and_set_initial_state();
  int read_mds_table(
      common::ObIAllocator &allocator,
      ObTabletMdsData &mds_data,
      const bool for_flush,
      const int64_t mds_construct_sequence = 0) const;
  int get_mds_table_for_dump(mds::MdsTableHandle &mds_table) const;
  int64_t get_memtable_count() const { return memtable_count_; }

  int check_new_mds_with_cache(const int64_t snapshot_version);
  int check_tablet_status_for_read_all_committed();
  int check_schema_version_with_cache(const int64_t schema_version);
  int check_snapshot_readable_with_cache(
      const int64_t snapshot_version,
      const int64_t schema_version,
      const int64_t timeout);
  int set_tablet_status(
      const ObTabletCreateDeleteMdsUserData &tablet_status,
      mds::MdsCtx &ctx);
  int replay_set_tablet_status(
      const share::SCN &scn,
      const ObTabletCreateDeleteMdsUserData &tablet_status,
      mds::MdsCtx &ctx);
  int set_ddl_info(
      const ObTabletBindingMdsUserData &ddl_info,
      mds::MdsCtx &ctx,
      const int64_t lock_timeout_us);
  int replay_set_ddl_info(
      const share::SCN &scn,
      const ObTabletBindingMdsUserData &ddl_info,
      mds::MdsCtx &ctx);
  int set_ddl_complete(const mds::DummyKey &key,
                       const ObTabletDDLCompleteMdsUserData &ddl_complete,
                       mds::MdsCtx &ctx,
                       const int64_t lock_timeout_us);
  int replay_set_ddl_complete(const share::SCN &scn,
                              const mds::DummyKey &key,
                              const ObTabletDDLCompleteMdsUserData &ddl_complete,
                              mds::MdsCtx &ctx);
  int set_truncate_info(
      const ObTruncateInfoKey &key,
      const ObTruncateInfo &value,
      mds::MdsCtx &ctx,
      const int64_t lock_timeout_us);
  int replay_set_truncate_info(
      const share::SCN &scn,
      const ObTruncateInfoKey &key,
      const ObTruncateInfo &value,
      mds::MdsCtx &ctx);
  int set_frozen_for_all_memtables();

  // different from the is_valid() function
  // typically used to check whether the tablet is ready for local access or restore
  int check_valid(const bool ignore_local_status = false) const;

  int64_t to_string(char *buf, const int64_t buf_len) const;
  int get_max_column_cnt_on_schema_recorder(int64_t &max_column_cnt);
  int get_max_schema_version(int64_t &schema_version);
  int get_ls_epoch(int64_t &ls_epoch);
  int get_sstable_column_checksum(
    const blocksstable::ObSSTable &sstable,
    common::ObIArray<int64_t> &column_checksums) const;
  int get_all_minor_sstables(ObTableStoreIterator &table_store_iter) const;
  int get_sstable_read_info(
      const blocksstable::ObSSTable *sstable,
      const storage::ObITableReadInfo *&index_read_info) const;
  int get_memtables(
      common::ObIArray<ObTableHandleV2> &memtables) const;

  int get_fork_info(share::ObForkTabletInfo &fork_info) const;
protected:// for MDS use
  virtual bool check_is_inited_() const override final { return is_inited_; }
  virtual const ObTabletMeta &get_tablet_meta_() const override final { return tablet_meta_; }
  virtual int get_mds_table_handle_(mds::MdsTableHandle &handle,
                                    const bool create_if_not_exist) const override final;
  virtual ObTabletPointer *get_tablet_pointer_() const override final;
private:
  int update_meta_last_persisted_committed_tablet_status_from_sstable(
      const ObUpdateTableStoreParam &param,
      const ObTabletCreateDeleteMdsUserData &last_tablet_status);
  int update_tablet_status_from_sstable(const bool expect_persist_status);
  int partial_deserialize(
      common::ObArenaAllocator &allocator,
      const char *buf,
      const int64_t len,
      int64_t &pos);
  static int deserialize_macro_info(
      common::ObArenaAllocator &allocator,
      const char *buf,
      const int64_t len,
      int64_t &pos,
      ObTabletMacroInfo *&tablet_macro_info);
  int init_aggregated_info(
      common::ObArenaAllocator &allocator,
      ObLinkedMacroBlockItemWriter *linked_writer);
  void set_initial_addr();
  int check_meta_addr() const;
  static int parse_meta_addr(const ObMetaDiskAddr &addr, ObIArray<blocksstable::MacroBlockId> &meta_ids);
  void dec_ref_with_aggregated_info();
  void dec_ref_without_aggregated_info();
  void dec_ref_with_macro_iter(ObMacroInfoIterator &macro_iter) const;
  int inner_inc_macro_ref_cnt();
  int inc_ref_with_aggregated_info();
  int inc_ref_without_aggregated_info();
  int inc_ref_with_macro_iter(ObMacroInfoIterator &macro_iter, bool &inc_success) const;
  void dec_table_store_ref_cnt();
  int inc_table_store_ref_cnt(bool &inc_success);
  static int inc_addr_ref_cnt(const ObMetaDiskAddr &addr, bool &inc_success);
  static void dec_addr_ref_cnt(const ObMetaDiskAddr &addr);
  static int inc_linked_block_ref_cnt(const ObMetaDiskAddr &head_addr, bool &inc_success);
  static void dec_linked_block_ref_cnt(const ObMetaDiskAddr &head_addr);
  int64_t get_try_cache_size() const;
  int inner_release_memtables(const share::SCN scn);
  int calc_sstable_occupy_size(int64_t &all_sstable_occupy_size);
  inline void set_space_usage_(const ObTabletSpaceUsage &space_usage) { tablet_meta_.set_space_usage_(space_usage); }

  int inner_read_truncate_info_array_from_mds(
      common::ObArenaAllocator &allocator,
      const common::ObVersionRange &read_version_range,
      storage::ObTruncateInfoArray &truncate_info_array,
      ObMdsReadInfoCollector &collector) const;
private:
  static bool ignore_ret(const int ret);
  int inner_check_valid(const bool ignore_local_status = false) const;
  int self_serialize(char *buf, const int64_t len, int64_t &pos) const;
  int64_t get_self_serialize_size() const;
  static int check_schema_version(const ObDDLInfoCache& ddl_info_cache, const int64_t schema_version);
  static int check_snapshot_readable(const ObDDLInfoCache& ddl_info_cache, const int64_t snapshot_version, const int64_t schema_version);
  logservice::ObLogHandler *get_log_handler() const { return log_handler_; } // TODO(gaishun.gs): get log handler from tablet pointer handle

  int init_shared_params(const common::ObTabletID &tablet_id);
  int build_read_info(
      common::ObArenaAllocator &allocator,
      const ObTablet *tablet);
  int create_memtable(CreateMemtableArg &arg);
  int try_update_start_scn();
  int try_update_ddl_checkpoint_scn();
  int try_update_table_store_flag(const bool with_major);
  int inner_get_all_sstables(ObTableStoreIterator &iter) const;
  int check_schema_version_for_bounded_staleness_read(
      const int64_t table_version_for_read,
      const int64_t data_max_schema_version,
      const uint64_t table_id);

  static int prepare_memtable(
      ObRelativeTable &relative_table,
      ObStoreCtx &store_ctx,
      memtable::ObMemtable *&write_memtable);

  int inner_create_memtable(CreateMemtableArg &arg);

  int inner_get_memtables(common::ObIArray<storage::ObITable *> &memtables) const;

  int write_sync_tablet_seq_log(ObTabletAutoincSeq &autoinc_seq,
                                const bool is_tablet_creating,
                                share::SCN &scn);

  int update_ddl_info(
      const int64_t schema_version,
      const share::SCN &scn,
      int64_t &schema_refreshed_ts);
  int write_tablet_schema_version_change_clog(
      const int64_t schema_version,
      share::SCN &scn);
  int get_ddl_info(
      int64_t &refreshed_schema_version,
      int64_t &refreshed_schema_ts) const;
  int get_read_tables(
      const int64_t snapshot_version,
      ObTabletTableIterator &iter,
      const bool allow_no_ready_read);
  int get_read_major_sstable(
      const int64_t &major_snapshot_version,
      ObTabletTableIterator &iter);
  int auto_get_read_tables(
      const int64_t snapshot_version,
      ObTabletTableIterator &iter,
      const bool allow_no_ready_read);
  int get_read_tables_(
      const int64_t snapshot_version,
      ObTableStoreIterator &iter,
      ObStorageMetaHandle &table_store_handle,
      const ObGetReadTablesMode mode);
  int get_read_major_sstable(
      const int64_t &major_snapshot_version,
      ObTableStoreIterator &iter) const;
  int get_fork_src_read_tables_(
      ObTabletTableIterator &iter,
      const bool allow_no_ready_read);

  int allow_to_read_();

  int check_medium_list() const;
  int check_sstable_column_checksum() const;
  int get_finish_medium_scn(int64_t &finish_medium_scn) const;

  int inner_get_mds_sstables(ObTableStoreIterator &table_store_iter) const;
  int inner_get_mds_table(
      mds::MdsTableHandle &mds_table,
      bool not_exist_create = false) const;
  int read_medium_array(
      common::ObArenaAllocator &allocator,
      common::ObIArray<compaction::ObMediumCompactionInfo*> &medium_info_array) const;
  int pre_check_empty_shell(const ObTablet &old_tablet, ObTabletCreateDeleteMdsUserData &user_data);
  int build_user_data_for_aborted_tx_tablet(
    const share::SCN &flush_scn,
    ObTabletCreateDeleteMdsUserData &user_data);
  int set_initial_state(const bool initial_state);
  int set_macro_info_addr(
      const blocksstable::MacroBlockId &macro_id,
      const int64_t offset,
      const int64_t size,
      const ObMetaDiskAddr::DiskType block_type);

  int load_deserialize_current(
      common::ObArenaAllocator &allocator,
      const char *buf,
      const int64_t len,
      int64_t &pos,
      const bool prepare_memtable);

  int prepare_param(ObRelativeTable &relative_table, ObTableIterParam &param);
  int prepare_param_ctx(
      common::ObIAllocator &allocator,
      ObRelativeTable &relative_table,
      ObStoreCtx &ctx,
      ObTableIterParam &param,
      ObTableAccessContext &context);

  // memtable operation
  // the allocator must be the same as the allocator used to construct the tablet, otherwise there will be lifecycle problems.
  int pull_memtables(ObArenaAllocator &allocator);
  int pull_memtables_without_ddl();
  int update_memtables();
  int build_memtable(common::ObIArray<ObTableHandleV2> &handle_array, const int64_t start_pos = 0);
  int rebuild_memtable(common::ObIArray<ObTableHandleV2> &handle_array);
  int rebuild_memtable(
      const share::SCN &clog_checkpoint_scn,
      common::ObIArray<ObTableHandleV2> &handle_array);
  int add_memtable(ObIMemtable* const table);
  bool exist_memtable_with_end_scn(const ObITable *table, const share::SCN &end_scn);
  int assign_memtables(ObIMemtable * const *memtables, const int64_t memtable_count);
  int assign_ddl_kvs(ObDDLKV * const *ddl_kvs, const int64_t ddl_kv_count);
  int pull_ddl_memtables(ObArenaAllocator &allocator, ObDDLKV **&ddl_kvs_addr, int64_t &ddl_kv_count);
  void reset_ddl_memtables();
  int wait_release_memtables_();
  int mark_mds_table_switched_to_empty_shell_();

  // DDL.

  // NOTICE:
  // - Because the `calc_tablet_attr()` may has I/O operations, you can bypass it if wantn't to update it.
  int get_updating_tablet_pointer_param(
      ObUpdateTabletPointerParam &param,
      const bool need_tablet_attr = true) const;
  int calc_tablet_attr(ObTabletAttr &attr) const;
  int check_ready_for_read_if_need(const ObTablet &old_tablet);
  int get_tablet_runtime_info_by_sstable(
    const ObTabletTableStore &table_store,
    share::ObTabletRuntimeInfo &runtime_info,
    share::ObTabletLocalChecksumItem &tablet_checksum) const;

  int clear_memtables_on_table_store(); // be careful to call this func, will destroy memtables array on table_store
  int check_table_store_flag_match_with_table_store_(const ObTabletTableStore *table_store);
  int copy_embedded_meta_(
      const ObRootBlockInfo &block_info,
      common::ObIAllocator &allocator,
      storage::ObMetaDiskAddr &addr,
      char *&buf) const;
  int start_direct_load_task_for_idem(ObLS *tenant_ls);
public:
  static constexpr int32_t TABLET_PAYLOAD_VERSION = 4;
private:
  // ObTabletDDLKvMgr::MAX_DDL_KV_CNT_IN_STORAGE
  // Array size is too large, need to shrink it if possible
  static const int64_t DDL_KV_ARRAY_SIZE = 64;
  static const int64_t MAX_PRINT_COUNT = 100;
private:
  int32_t version_;                                          // size: 4B, alignment: 4B
  int32_t length_;                                           // size: 4B, alignment: 4B
  volatile int64_t wash_score_;                              // size: 8B, alignment: 8B
  volatile int64_t ref_cnt_;                                 // size: 8B, alignment: 8B
  ObTabletHandle next_tablet_guard_;                         // size: 56B, alignment: 8B
  ObTabletMeta tablet_meta_;                                 // size: 288B, alignment: 8B
  ObRowkeyReadInfo *rowkey_read_info_;                       // size: 8B, alignment: 8B
  // in memory or disk
  ObTabletComplexAddr<ObTabletTableStore> table_store_addr_; // size: 56B, alignment: 8B
  // always in disk
  ObTabletComplexAddr<ObStorageSchema> storage_schema_addr_; // size: 56B, alignment: 8B
  ObTabletComplexAddr<ObTabletMacroInfo> macro_info_addr_;   // size: 56B, alignment: 8B
  int64_t memtable_count_;                                   // size: 8B, alignment: 8B
  ObDDLKV **ddl_kvs_;                                        // size: 8B, alignment: 8B
  int64_t ddl_kv_count_;                                     // size: 8B, alignment: 8B
  ObTabletPointerHandle pointer_hdl_;                   // size: 24B, alignment: 8B
  ObMetaDiskAddr tablet_addr_;                               // size: 40B, alignment: 8B 1080
  // NOTICE: these two pointers: memtable_mgr_ and log_handler_,
  // are considered as cache for tablet.
  // we keep it on tablet because we cannot get them in ObTablet::deserialize
  // through ObTabletPointerHandle.
  // may be some day will fix this issue, then the pointers have no need to exist.
  // won't persist
  storage::ObIMemtable *memtables_[MAX_MEMSTORE_CNT];        // size: 128B, alignment: 8B
  ObArenaAllocator *allocator_;                              // size: 8B, alignment: 8B
  mutable common::SpinRWLock memtables_lock_;                // size: 12B, alignment: 4B
  mutable common::SpinRWLock mds_cache_lock_;                // size: 12B, alignment: 4B
  logservice::ObLogHandler *log_handler_;                    // size: 8B, alignment: 8B

  ObTablet *next_tablet_; // used in old_version_chain and tablet_gc_queue
                                                             // size: 8B, alignment: 8B
  ObTabletStatusCache tablet_status_cache_;                  // size: 24B, alignment: 8B
  ObDDLInfoCache ddl_data_cache_;                            // size: 24B, alignment: 8B
  ObTruncateInfoCache truncate_info_cache_;                  // size: 8B, alignment: 8B
  ObTableStoreCache table_store_cache_; // no need to serialize, should be initialized after table store is initialized.
                                                             // size: 48B, alignment: 8B
  // whether hold ref cnt
  // when destroying tablet, only if hold_ref_cnt_ is true do we decrease meta blocks' ref cnt
  // we need to set it to true after increasing meta blocks' ref cnt or deserializing tablet
  bool gc_occupy_flag_;                                      // size: 4B, alignment: 1B
  bool hold_ref_cnt_;                                        // size: 4B, alignment: 1B
  bool is_inited_;                                           // size: 4B, alignment: 1B
  const bool is_external_tablet_;                                  // size: 4B, alignment: 1B
};

inline bool ObTablet::is_ls_inner_tablet() const
{
  return tablet_meta_.tablet_id_.is_ls_inner_tablet();
}

inline bool ObTablet::is_ls_tx_data_tablet() const
{
  return tablet_meta_.tablet_id_.is_ls_tx_data_tablet();
}

inline bool ObTablet::is_ls_tx_ctx_tablet() const
{
  return tablet_meta_.tablet_id_.is_ls_tx_ctx_tablet();
}

inline bool ObTablet::is_valid() const
{
  return (!is_empty_shell()
          && tablet_meta_.is_valid()
          && table_store_addr_.is_valid()
          && storage_schema_addr_.is_valid()
          && nullptr != rowkey_read_info_) // judgement case 1
          || (is_empty_shell()
          && table_store_addr_.addr_.is_none()
          && storage_schema_addr_.addr_.is_none()
          && nullptr == rowkey_read_info_); // judgement case 2
}

inline int ObTablet::allow_to_read_()
{
  return tablet_meta_.local_status_.check_allow_read() ? common::OB_SUCCESS : common::OB_REPLICA_NOT_READABLE;
}

inline void ObTablet::update_wash_score(const int64_t score)
{
  int64_t ret_v = 0;
  int64_t old_v = ATOMIC_LOAD(&wash_score_);
  if (score > old_v) {
    while (old_v != (ret_v = ATOMIC_CAS(&wash_score_, old_v, score))) {
      if (ret_v >= score) {
        break; // higher score may be updated by others, so just skip.
      } else {
        old_v = ret_v;
      }
    }
  }
}

inline void ObTablet::inc_ref()
{
  const int64_t cnt = ATOMIC_AAF(&ref_cnt_, 1);
#ifdef DEBUG
  const common::ObTabletID tablet_id = tablet_meta_.tablet_id_;
  STORAGE_LOG(DEBUG, "tablet inc ref", KP(this), K(tablet_id), "ref_cnt", cnt, K(lbt()));
#endif
}

inline int64_t ObTablet::dec_ref()
{
#ifdef DEBUG
  const common::ObTabletID tablet_id = tablet_meta_.tablet_id_;
#endif
  const int64_t cnt = ATOMIC_SAF(&ref_cnt_, 1/* just sub 1 */);
#ifdef DEBUG
  STORAGE_LOG(DEBUG, "tablet dec ref", KP(this), K(tablet_id), "ref_cnt", cnt, K(lbt()));
#endif

  return cnt;
}

} // namespace storage
} // namespace oceanbase

#endif // OCEANBASE_STORAGE_TABLET_OB_TABLET
