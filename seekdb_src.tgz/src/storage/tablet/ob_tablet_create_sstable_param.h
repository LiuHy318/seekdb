/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_TABLET_CREATE_SSTABLE_PARAM
#define OCEANBASE_STORAGE_OB_TABLET_CREATE_SSTABLE_PARAM

#include "lib/utility/ob_print_utils.h"
#include "storage/ob_i_table.h"
#include "storage/blocksstable/ob_macro_block_id.h"
#include "storage/blocksstable/ob_imicro_block_reader.h"
#include "storage/meta_mem/ob_meta_obj_struct.h"
#include "share/scn.h"
#include "storage/ddl/ob_ddl_struct.h"
#include "storage/compaction/ob_compaction_util.h"

namespace oceanbase
{
namespace blocksstable
{
struct ObSSTableMergeRes;
struct ObBlockInfo;
struct ObSSTableBasicMeta;
class ObSSTableMacroInfo;
class ObSSTableMeta;
class ObSSTableCloneParam;
class ObSSTable;
class ObSSTableIndexBuilder;
}
namespace compaction
{
struct ObBasicTabletMergeCtx;
}
namespace storage
{
struct ObTabletDDLParam;

class ObBlockMetaTree;

struct ObTabletCreateSSTableParam final
{
public:
  ObTabletCreateSSTableParam();
  ~ObTabletCreateSSTableParam() = default;
  ObTabletCreateSSTableParam(const ObTabletCreateSSTableParam &other) = delete;
  ObTabletCreateSSTableParam &operator=(ObTabletCreateSSTableParam &other) = delete;
public:
  bool is_valid() const;
  bool is_block_meta_valid(const ObMetaDiskAddr &addr,
                           const blocksstable::ObMicroBlockData &data) const;
  
  // Without checking the validity of the input parameters, necessary to ensure the correctness of the method call.
  int init_for_empty_major_sstable(const ObTabletID &tablet_id,
                                   const ObStorageSchema &storage_schema,
                                   const int64_t snapshot_version);

  // Without checking the validity of the input parameters, necessary to ensure the correctness of the method call.
  int init_for_small_sstable(const blocksstable::ObSSTableMergeRes &res,
                             const ObITable::TableKey &table_key,
                             const blocksstable::ObSSTableMeta &sstable_meta,
                             const blocksstable::ObBlockInfo &block_info);

  // Without checking the validity of the input parameters, necessary to ensure the correctness of the method call.
  int init_for_merge(const compaction::ObBasicTabletMergeCtx &ctx,
                     const blocksstable::ObSSTableMergeRes &res);

  // Without checking the validity of the input parameters, necessary to ensure the correctness of the method call.
  int init_for_ddl(blocksstable::ObSSTableIndexBuilder *sstable_index_builder,
                   const ObTabletDDLParam &ddl_param,
                   const blocksstable::ObSSTable *first_ddl_sstable,
                   const ObStorageSchema &storage_schema,
                   const int64_t macro_block_column_count,
                   const int64_t create_schema_version_on_tablet,
                   const ObIArray<blocksstable::MacroBlockId> &macro_id_array);

  // Without checking the validity of the input parameters, necessary to ensure the correctness of the method call.
  int init_for_ddl_mem(const ObITable::TableKey &table_key,
                       const share::SCN &ddl_start_scn,
                       const ObStorageSchema &storage_schema,
                       ObBlockMetaTree &block_meta_tree);

  // Without checking the validity of the input parameters, necessary to ensure the correctness of the method call.
  int init_for_fork(const ObTabletID &dst_tablet_id,
                     const ObITable::TableKey &src_table_key,
                     const blocksstable::ObSSTableBasicMeta &basic_meta,
                     const int64_t schema_version,
                     const blocksstable::ObSSTableMergeRes &res,
                     const share::SCN &max_end_scn);

  // Without checking the validity of the input parameters, necessary to ensure the correctness of the method call.
  int init_for_empty_minor_sstable(const ObTabletID &tablet_id,
                                   const share::SCN &start_scn,
                                   const share::SCN &end_scn,
                                   const blocksstable::ObSSTableBasicMeta &basic_meta);

  // Without checking the validity of the input parameters, necessary to ensure the correctness of the method call.
  int init_for_lob_split(const ObTabletID &new_tablet_id,
                         const ObITable::TableKey &table_key,
                         const blocksstable::ObSSTableBasicMeta &basic_meta,
                         const compaction::ObMergeType &merge_type,
                         const int64_t schema_version,
                         const int64_t dst_major_snapshot_version,
                         const int64_t uncommitted_tx_id,
                         const int64_t sstable_logic_seq,
                         const blocksstable::ObSSTableMergeRes &res);

  int init_for_fork(const blocksstable::ObSSTableCloneParam &sstable_param,
                    const ObTabletID &dst_tablet_id,
                    const ObITable::TableKey &src_table_key,
                    const blocksstable::ObSSTableMeta &sstable_meta,
                    const share::SCN &max_end_scn = share::SCN());

  int init_for_mds(const compaction::ObBasicTabletMergeCtx &ctx,
                   const blocksstable::ObSSTableMergeRes &res,
                   const ObStorageSchema &mds_schema);

  int init_for_physical_restore(
      const ObITable::TableKey &table_key,
      const blocksstable::ObSSTableBasicMeta &basic_meta,
      const common::ObIArray<int64_t> &column_checksums);
  int init_for_physical_restore(
      const ObITable::TableKey &table_key,
      const blocksstable::ObSSTableBasicMeta &basic_meta,
      const common::ObIArray<int64_t> &column_checksums,
      const blocksstable::ObSSTableMergeRes &res);
  
  inline const ObITable::TableKey& table_key() const { return table_key_; }
  inline bool is_ready_for_read() const { return is_ready_for_read_; }
  inline int64_t data_blocks_cnt() const { return data_blocks_cnt_; }
  inline share::SCN filled_tx_scn() const { return filled_tx_scn_; }

  // TODO: delete this interface
  // ObTabletMergeInfo::record_start_tx_scn_for_tx_data
  inline void set_filled_tx_scn(const share::SCN &scn) { filled_tx_scn_ = scn; }

  TO_STRING_KV(K_(table_key),
      K_(sstable_logic_seq),
      K_(schema_version),
      K_(create_snapshot_version),
      K_(progressive_merge_round),
      K_(progressive_merge_step),
      K_(is_ready_for_read),
      K_(table_mode),
      K_(index_type),
      K_(root_block_addr),
      K_(root_block_data),
      K_(root_row_store_type),
      K_(latest_row_store_type),
      K_(data_index_tree_height),
      K_(data_block_macro_meta_addr),
      K_(data_block_macro_meta),
      K_(index_blocks_cnt),
      K_(data_blocks_cnt),
      K_(micro_block_cnt),
      K_(use_old_macro_block_count),
      K_(row_count),
      K_(rowkey_column_cnt),
      K_(column_cnt),
      K_(column_checksums),
      K_(data_checksum),
      K_(occupy_size),
      K_(original_size),
      K_(max_merged_trans_version),
      K_(ddl_scn),
      K_(filled_tx_scn),
      K_(tx_data_recycle_scn),
      K_(contain_uncommitted_row),
      K_(is_meta_root),
      K_(compressor_type),
      K_(recycle_version),
      K_(nested_offset),
      K_(nested_size),
      K_(uncommitted_tx_id));
private:
  static const int64_t DEFAULT_MACRO_BLOCK_CNT = 64;
  int inner_init_with_merge_res(const blocksstable::ObSSTableMergeRes &res);
  void inner_init_for_physical_restore(
      const ObITable::TableKey &table_key,
      const blocksstable::ObSSTableBasicMeta &basic_meta);
  int inner_init_with_embedded_meta(const blocksstable::ObSSTableCloneParam &sstable_param,
                                    const common::ObIArray<blocksstable::MacroBlockId> &data_block_ids,
                                    const common::ObIArray<blocksstable::MacroBlockId> &other_block_ids);
  int collect_macro_block_ids_from_meta(
      const blocksstable::ObSSTableMacroInfo &macro_info,
      common::ObIArray<blocksstable::MacroBlockId> &data_block_ids,
      common::ObIArray<blocksstable::MacroBlockId> &other_block_ids);
private:
  friend class blocksstable::ObSSTableMeta;
  friend class blocksstable::ObSSTableMacroInfo;
public:
  ObITable::TableKey table_key_;
  int16_t sstable_logic_seq_;
  int64_t schema_version_;
  int64_t create_snapshot_version_;
  int64_t progressive_merge_round_;
  int64_t progressive_merge_step_;
  bool is_ready_for_read_;
  share::schema::ObTableMode table_mode_;
  share::schema::ObIndexType index_type_;
  ObMetaDiskAddr root_block_addr_;
  blocksstable::ObMicroBlockData root_block_data_;
  common::ObRowStoreType root_row_store_type_;
  common::ObRowStoreType latest_row_store_type_;
  int16_t data_index_tree_height_;
  ObMetaDiskAddr data_block_macro_meta_addr_;
  blocksstable::ObMicroBlockData data_block_macro_meta_;
  int64_t index_blocks_cnt_;
  int64_t data_blocks_cnt_;
  int64_t micro_block_cnt_;
  int64_t use_old_macro_block_count_;
  int64_t row_count_;
  int64_t rowkey_column_cnt_;
  int64_t column_cnt_;
  common::ObSEArray<int64_t, common::OB_ROW_DEFAULT_COLUMNS_COUNT> column_checksums_;
  int64_t data_checksum_;
  int64_t occupy_size_;
  int64_t original_size_;
  int64_t max_merged_trans_version_;
  share::SCN ddl_scn_; // saved into sstable meta
  share::SCN filled_tx_scn_;
  share::SCN tx_data_recycle_scn_;
  bool contain_uncommitted_row_;
  bool is_meta_root_;
  common::ObCompressorType compressor_type_;
  int64_t recycle_version_;
  int64_t nested_offset_;
  int64_t nested_size_;
  int64_t root_macro_seq_;
  common::ObSEArray<blocksstable::MacroBlockId, DEFAULT_MACRO_BLOCK_CNT> data_block_ids_;
  common::ObSEArray<blocksstable::MacroBlockId, DEFAULT_MACRO_BLOCK_CNT> other_block_ids_;
  int64_t uncommitted_tx_id_;
};

} // namespace storage
} // namespace oceanbase

#endif // OCEANBASE_STORAGE_OB_TABLET_CREATE_SSTABLE_PARAM
