/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define USING_LOG_PREFIX STORAGE

#include "ob_tablet_create_sstable_param.h"
#include "storage/blocksstable/ob_shared_macro_block_manager.h"
#include "storage/compaction/ob_basic_tablet_merge_ctx.h"
#include "storage/ddl/ob_direct_load_struct.h"
#include "storage/ddl/ob_tablet_ddl_kv.h"

namespace oceanbase
{
using namespace share;
namespace storage
{
// if you add membership for this param, plz check all paths that use it, including
// but not limited to unittest, merge, and DDL
ObTabletCreateSSTableParam::ObTabletCreateSSTableParam()
  : table_key_(),
    sstable_logic_seq_(-1),
    schema_version_(-1),
    create_snapshot_version_(-1),
    progressive_merge_round_(-1),
    progressive_merge_step_(-1),
    is_ready_for_read_(true),
    table_mode_(),
    index_type_(share::schema::ObIndexType::INDEX_TYPE_MAX),
    root_block_addr_(),
    root_block_data_(),
    root_row_store_type_(common::ObRowStoreType::MAX_ROW_STORE),
    latest_row_store_type_(common::ObRowStoreType::MAX_ROW_STORE),
    data_index_tree_height_(-1),
    data_block_macro_meta_addr_(),
    data_block_macro_meta_(),
    index_blocks_cnt_(-1),
    data_blocks_cnt_(-1),
    micro_block_cnt_(-1),
    use_old_macro_block_count_(-1),
    row_count_(-1),
    rowkey_column_cnt_(-1),
    column_cnt_(-1),
    data_checksum_(0),
    occupy_size_(-1),
    original_size_(-1),
    max_merged_trans_version_(0),
    ddl_scn_(),
    filled_tx_scn_(),
    tx_data_recycle_scn_(),
    contain_uncommitted_row_(false),
    is_meta_root_(false),
    compressor_type_(ObCompressorType::INVALID_COMPRESSOR),
    recycle_version_(-1),
    nested_offset_(-1),
    nested_size_(-1),
    root_macro_seq_(-1),
    data_block_ids_(),
    other_block_ids_(),
    uncommitted_tx_id_(0)
{}

bool ObTabletCreateSSTableParam::is_valid() const
{
  bool ret = true;
  if (OB_UNLIKELY(!table_key_.is_valid())) {
    ret = false;
    LOG_WARN("invalid table key", K(table_key_));
  } else if (OB_UNLIKELY(!table_mode_.is_valid())) {
    ret = false;
    LOG_WARN("invalid table mode", K(table_mode_));
  } else if (!(schema_version_ >= 0
               && sstable_logic_seq_ >= 0
               && create_snapshot_version_ >= 0
               && progressive_merge_round_ >= 0
               && progressive_merge_step_ >= 0
               && index_type_ < share::schema::ObIndexType::INDEX_TYPE_MAX
               && root_row_store_type_ < ObRowStoreType::MAX_ROW_STORE
               && latest_row_store_type_ < ObRowStoreType::MAX_ROW_STORE
               && data_index_tree_height_ >= 0
               && index_blocks_cnt_ >= 0
               && data_blocks_cnt_ >= 0
               && micro_block_cnt_ >= 0
               && use_old_macro_block_count_ >= 0
               && row_count_ >= 0
               && rowkey_column_cnt_ >= 0
               && column_cnt_ >= 0
               && occupy_size_ >= 0
               && ddl_scn_.is_valid()
               && filled_tx_scn_.is_valid()
               && tx_data_recycle_scn_.is_valid()
               && original_size_ >= 0
               && recycle_version_ >= 0
               && nested_offset_ >= 0
               && nested_size_ >= 0
               && root_macro_seq_ >= 0)) {
    ret = false;
    LOG_WARN("invalid basic params", KPC(this)); // LOG_KVS arg number overflow
  } else if (ObITable::is_ddl_sstable(table_key_.table_type_)) {
    // ddl sstable can have invalid meta addr, so skip following ifs
    if (!ddl_scn_.is_valid_and_not_min()) {
      ret = false;
      LOG_WARN("ddl log ts is invalid", K(ddl_scn_), K(table_key_));
    }
  } else if (!is_block_meta_valid(root_block_addr_, root_block_data_)) {
    ret = false;
    LOG_WARN("invalid root meta", K(root_block_addr_), K(root_block_data_));
  } else if (!is_block_meta_valid(data_block_macro_meta_addr_, data_block_macro_meta_)) {
    ret = false;
    LOG_WARN("invalid data meta", K(data_block_macro_meta_addr_), K(data_block_macro_meta_));
  } else if (!table_key_.get_tablet_id().is_ls_inner_tablet() && table_key_.is_minor_sstable() && filled_tx_scn_ < table_key_.get_end_scn()) {
    ret = false;
    LOG_WARN("filled tx scn is invalid", K(filled_tx_scn_), K(table_key_));
  }
  return ret;
}

bool ObTabletCreateSSTableParam::is_block_meta_valid(const storage::ObMetaDiskAddr &addr,
                                                     const blocksstable::ObMicroBlockData &data) const
{
  return addr.is_valid() && (!addr.is_memory() || (data.is_valid() && data.size_ == addr.size()));
}

int ObTabletCreateSSTableParam::inner_init_with_merge_res(const blocksstable::ObSSTableMergeRes &res)
{
  int ret = OB_SUCCESS;
  blocksstable::ObSSTableMergeRes::fill_addr_and_data(res.root_desc_,
      root_block_addr_, root_block_data_);
  blocksstable::ObSSTableMergeRes::fill_addr_and_data(res.data_root_desc_,
      data_block_macro_meta_addr_, data_block_macro_meta_);
  root_row_store_type_ = res.root_row_store_type_;
  data_index_tree_height_ = res.root_desc_.height_;
  index_blocks_cnt_ = res.index_blocks_cnt_;
  data_blocks_cnt_ = res.data_blocks_cnt_;
  micro_block_cnt_ = res.micro_block_cnt_;
  use_old_macro_block_count_ = res.use_old_macro_block_count_;
  row_count_ = res.row_count_;
  data_checksum_ = res.data_checksum_;
  occupy_size_ = res.occupy_size_;
  original_size_ = res.original_size_;
  contain_uncommitted_row_ = res.contain_uncommitted_row_;
  compressor_type_ = res.compressor_type_;
  is_meta_root_ = res.data_root_desc_.is_meta_root_;
  nested_offset_ = res.nested_offset_;
  nested_size_ = res.nested_size_;
  root_macro_seq_ = res.root_macro_seq_;
  if (OB_FAIL(data_block_ids_.assign(res.data_block_ids_))) {
  } else if (OB_FAIL(other_block_ids_.assign(res.other_block_ids_))) {
  }
  return ret;
}

void ObTabletCreateSSTableParam::inner_init_for_physical_restore(
    const ObITable::TableKey &table_key,
    const blocksstable::ObSSTableBasicMeta &basic_meta)
{
  table_key_ = table_key;
  sstable_logic_seq_ = basic_meta.sstable_logic_seq_;
  schema_version_ = basic_meta.schema_version_;
  create_snapshot_version_ = basic_meta.create_snapshot_version_;
  progressive_merge_round_ = basic_meta.progressive_merge_round_;
  progressive_merge_step_ = basic_meta.progressive_merge_step_;
  table_mode_ = basic_meta.table_mode_;
  index_type_ = static_cast<share::schema::ObIndexType>(basic_meta.index_type_);
  root_row_store_type_ = basic_meta.root_row_store_type_;
  latest_row_store_type_ = basic_meta.latest_row_store_type_;
  rowkey_column_cnt_ = basic_meta.rowkey_column_count_;
  column_cnt_ = basic_meta.column_cnt_;
  max_merged_trans_version_ = basic_meta.max_merged_trans_version_;
  ddl_scn_ = basic_meta.ddl_scn_;
  filled_tx_scn_ = basic_meta.filled_tx_scn_;
  tx_data_recycle_scn_ = basic_meta.tx_data_recycle_scn_;
  recycle_version_ = basic_meta.recycle_version_;
  root_macro_seq_ = basic_meta.root_macro_seq_;
}

int ObTabletCreateSSTableParam::init_for_physical_restore(
    const ObITable::TableKey &table_key,
    const blocksstable::ObSSTableBasicMeta &basic_meta,
    const common::ObIArray<int64_t> &column_checksums)
{
  int ret = OB_SUCCESS;
  inner_init_for_physical_restore(table_key, basic_meta);
  root_block_addr_.set_none_addr();
  data_block_macro_meta_addr_.set_none_addr();
  data_index_tree_height_ = basic_meta.data_index_tree_height_;
  index_blocks_cnt_ = basic_meta.index_macro_block_count_;
  data_blocks_cnt_ = basic_meta.data_macro_block_count_;
  micro_block_cnt_ = basic_meta.data_micro_block_count_;
  use_old_macro_block_count_ = basic_meta.use_old_macro_block_count_;
  row_count_ = basic_meta.row_count_;
  data_checksum_ = basic_meta.data_checksum_;
  occupy_size_ = basic_meta.occupy_size_;
  original_size_ = basic_meta.original_size_;
  contain_uncommitted_row_ = basic_meta.contain_uncommitted_row_;
  compressor_type_ = basic_meta.compressor_type_;
  is_meta_root_ = false;
  nested_offset_ = 0;
  nested_size_ = 0;

  if (OB_FAIL(column_checksums_.assign(column_checksums))) {
    LOG_WARN("fail to assign column checksums", K(ret), K(table_key));
  } else if (OB_FAIL(blocksstable::ObSSTableMetaCompactUtil::fix_filled_tx_scn_value_for_compact(
      table_key_, filled_tx_scn_))) {
    LOG_WARN("failed to fix filled tx scn for physical restore", K(ret), K(table_key));
  } else if (!is_valid()) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid physical restore sstable param", K(ret), K(table_key), K(basic_meta), KPC(this));
  }
  return ret;
}

int ObTabletCreateSSTableParam::init_for_physical_restore(
    const ObITable::TableKey &table_key,
    const blocksstable::ObSSTableBasicMeta &basic_meta,
    const common::ObIArray<int64_t> &column_checksums,
    const blocksstable::ObSSTableMergeRes &res)
{
  int ret = OB_SUCCESS;
  inner_init_for_physical_restore(table_key, basic_meta);
  column_cnt_ = res.data_column_cnt_;
  max_merged_trans_version_ = res.max_merged_trans_version_;
  if (OB_FAIL(inner_init_with_merge_res(res))) {
    LOG_WARN("fail to initialize restored sstable from merge result", K(ret), K(table_key), K(res));
  } else if (OB_FAIL(column_checksums_.assign(column_checksums))) {
    LOG_WARN("fail to assign column checksums", K(ret), K(table_key));
  } else if (OB_FAIL(blocksstable::ObSSTableMetaCompactUtil::fix_filled_tx_scn_value_for_compact(
      table_key_, filled_tx_scn_))) {
    LOG_WARN("failed to fix filled tx scn for physical restore", K(ret), K(table_key));
  } else {
    root_macro_seq_ = MAX(root_macro_seq_, basic_meta.root_macro_seq_);
    if (!is_valid()) {
      ret = OB_INVALID_ARGUMENT;
      LOG_WARN("invalid physical restore sstable param", K(ret), K(table_key), K(basic_meta), K(res), KPC(this));
    }
  }
  return ret;
}

int ObTabletCreateSSTableParam::init_for_empty_major_sstable(const ObTabletID &tablet_id,
                                                             const ObStorageSchema &storage_schema,
                                                             const int64_t snapshot_version)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(!storage_schema.is_valid() || !tablet_id.is_valid() 
      || OB_INVALID_VERSION == snapshot_version)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid args", K(ret), K(storage_schema), K(snapshot_version));
  } else {
    const int64_t multi_version_col_cnt = ObMultiVersionRowkeyHelpper::get_extra_rowkey_col_cnt();
    table_key_.table_type_ = ObITable::TableType::MAJOR_SSTABLE;

    table_key_.tablet_id_ = tablet_id;
    table_key_.version_range_.snapshot_version_ = snapshot_version;
    max_merged_trans_version_ = snapshot_version;

    schema_version_ = storage_schema.get_schema_version();
    create_snapshot_version_ = 0;
    progressive_merge_round_ = storage_schema.get_progressive_merge_round();
    progressive_merge_step_ = 0;

    table_mode_ = storage_schema.get_table_mode_struct();
    index_type_ = storage_schema.get_index_type();
    rowkey_column_cnt_ = storage_schema.get_rowkey_column_num()
            + ObMultiVersionRowkeyHelpper::get_extra_rowkey_col_cnt();
    root_block_addr_.set_none_addr();
    data_block_macro_meta_addr_.set_none_addr();
    root_row_store_type_ = (ObRowStoreType::ENCODING_ROW_STORE == storage_schema.get_row_store_type()
        ? ObRowStoreType::SELECTIVE_ENCODING_ROW_STORE : storage_schema.get_row_store_type());
    latest_row_store_type_ = storage_schema.get_row_store_type();
    data_index_tree_height_ = 0;
    index_blocks_cnt_ = 0;
    data_blocks_cnt_ = 0;
    micro_block_cnt_ = 0;
    use_old_macro_block_count_ = 0;
    data_checksum_ = 0;
    occupy_size_ = 0;
    ddl_scn_.set_min();
    filled_tx_scn_.set_min();
    tx_data_recycle_scn_.set_min();
    original_size_ = 0;
    compressor_type_ = ObCompressorType::NONE_COMPRESSOR;
    sstable_logic_seq_ = 0;
    row_count_ = 0;
    recycle_version_ = 0;
    nested_offset_ = 0;
    nested_size_ = 0;
    root_macro_seq_ = 0;
    if (OB_FAIL(storage_schema.get_store_column_count(column_cnt_, true/*is_full*/))) {
    } else if (FALSE_IT(column_cnt_ += multi_version_col_cnt)) {
    } else if (OB_FAIL(ObSSTableMergeRes::fill_column_checksum_for_empty_major(column_cnt_,
        column_checksums_))) {
    }
  }
  return ret;
}

int ObTabletCreateSSTableParam::init_for_empty_minor_sstable(const ObTabletID &tablet_id,
                                                             const share::SCN &start_scn,
                                                             const share::SCN &end_scn,
                                                             const blocksstable::ObSSTableBasicMeta &basic_meta)
{
  int ret = OB_SUCCESS;
  table_key_.table_type_ = ObITable::TableType::MINOR_SSTABLE;
  table_key_.tablet_id_ = tablet_id;
  table_key_.scn_range_.start_scn_ = start_scn;
  table_key_.scn_range_.end_scn_ = end_scn;
  max_merged_trans_version_ = 0;

  schema_version_ = basic_meta.schema_version_;
  progressive_merge_round_ = basic_meta.progressive_merge_round_;
  progressive_merge_step_ = basic_meta.progressive_merge_step_;
  sstable_logic_seq_ = basic_meta.sstable_logic_seq_;
  filled_tx_scn_ = basic_meta.filled_tx_scn_;
  table_mode_ = basic_meta.table_mode_;
  index_type_ = static_cast<share::schema::ObIndexType> (basic_meta.index_type_);
  rowkey_column_cnt_ = basic_meta.rowkey_column_count_;
  latest_row_store_type_ = basic_meta.latest_row_store_type_;
  recycle_version_ = basic_meta.recycle_version_;
  schema_version_ = basic_meta.schema_version_;
  create_snapshot_version_ = basic_meta.create_snapshot_version_;
  ddl_scn_ = basic_meta.ddl_scn_;
  progressive_merge_round_ = basic_meta.progressive_merge_round_;
  progressive_merge_step_ = basic_meta.progressive_merge_step_;
  column_cnt_ = basic_meta.column_cnt_;

  root_block_addr_.set_none_addr();
  data_block_macro_meta_addr_.set_none_addr();
  root_row_store_type_ = ObRowStoreType::FLAT_ROW_STORE;
  latest_row_store_type_ = ObRowStoreType::FLAT_ROW_STORE;
  data_index_tree_height_ = 0;
  index_blocks_cnt_ = 0;
  data_blocks_cnt_ = 0;
  micro_block_cnt_ = 0;
  use_old_macro_block_count_ = 0;
  row_count_ = 0;
  data_checksum_ = 0;
  occupy_size_ = 0;
  ddl_scn_.set_min();
  filled_tx_scn_ = end_scn;
  tx_data_recycle_scn_.set_min();
  original_size_ = 0;
  compressor_type_ = ObCompressorType::NONE_COMPRESSOR;
  nested_offset_ = 0;
  nested_size_ = 0;
  root_macro_seq_ = 0;
  return ret;
}

int ObTabletCreateSSTableParam::init_for_small_sstable(
    const blocksstable::ObSSTableMergeRes &res,
    const ObITable::TableKey &table_key,
    const blocksstable::ObSSTableMeta &sstable_meta,
    const blocksstable::ObBlockInfo &block_info)
{
  int ret = OB_SUCCESS;
  const blocksstable::ObSSTableBasicMeta &basic_meta = sstable_meta.get_basic_meta();
  filled_tx_scn_ = basic_meta.filled_tx_scn_;
  tx_data_recycle_scn_ = basic_meta.tx_data_recycle_scn_;
  ddl_scn_ = basic_meta.ddl_scn_;
  table_key_ = table_key;
  sstable_logic_seq_ = sstable_meta.get_sstable_seq();
  table_mode_ = basic_meta.table_mode_;
  index_type_ = static_cast<share::schema::ObIndexType>(basic_meta.index_type_);
  schema_version_ = basic_meta.schema_version_;
  create_snapshot_version_ = basic_meta.create_snapshot_version_;
  progressive_merge_round_ = basic_meta.progressive_merge_round_;
  progressive_merge_step_ = basic_meta.progressive_merge_step_;
  rowkey_column_cnt_ = basic_meta.rowkey_column_count_;
  recycle_version_ = basic_meta.recycle_version_;
  latest_row_store_type_ = basic_meta.latest_row_store_type_;
  is_ready_for_read_ = true;
  column_cnt_ = res.data_column_cnt_;
  max_merged_trans_version_ = res.max_merged_trans_version_;

  if (OB_FAIL(inner_init_with_merge_res(res))) {
  } else {
    nested_offset_ = block_info.nested_offset_;
    nested_size_ = block_info.nested_size_;
    if (table_key_.is_major_sstable()
        && OB_FAIL(sstable_meta.get_column_checksums(column_checksums_))) {
      LOG_WARN("fail to fill column checksum", K(ret), K(sstable_meta));
    }
  }
  if (OB_SUCC(ret) && !is_valid()) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("init for small sstable get invalid argument", K(ret), K(res), K(table_key),
        KPC(this), K(sstable_meta), K(block_info));
  }
  return ret;
}

int ObTabletCreateSSTableParam::init_for_merge(const compaction::ObBasicTabletMergeCtx &ctx,
                                               const blocksstable::ObSSTableMergeRes &res)
{
  int ret = OB_SUCCESS;
  const compaction::ObStaticMergeParam &static_param = ctx.static_param_;
  ObITable::TableKey table_key;
  table_key.table_type_ = ctx.get_merged_table_type();
  table_key.tablet_id_ = ctx.get_tablet_id();
  if (is_major_or_meta_merge_type(static_param.get_merge_type())) {
    table_key.version_range_.snapshot_version_ = static_param.version_range_.snapshot_version_;
  } else {
    table_key.scn_range_ = static_param.scn_range_;
  }
  uncommitted_tx_id_ = is_minor_merge_type(static_param.get_merge_type()) && res.contain_uncommitted_row_
                     ? static_param.tx_id_
                     : 0;
  table_key_ = table_key;

  sstable_logic_seq_ = static_param.sstable_logic_seq_;
  filled_tx_scn_ = ctx.get_merge_scn();
  table_mode_ = ctx.get_schema()->get_table_mode_struct();
  index_type_ = ctx.get_schema()->get_index_type();
  rowkey_column_cnt_ = static_param.schema_->get_rowkey_column_num()
                     + ObMultiVersionRowkeyHelpper::get_extra_rowkey_col_cnt();
  latest_row_store_type_ = ctx.get_schema()->get_row_store_type();
  recycle_version_ = is_minor_merge_type(static_param.get_merge_type())
                   ? static_param.version_range_.base_version_
                   : 0;
  schema_version_ = ctx.get_schema()->get_schema_version();
  create_snapshot_version_ = static_param.create_snapshot_version_;
  progressive_merge_round_ = ctx.get_progressive_merge_round();
  progressive_merge_step_ = ctx.get_result_progressive_merge_step();
  column_cnt_ = res.data_column_cnt_;
  max_merged_trans_version_ = 0 == res.row_count_ && 0 == res.max_merged_trans_version_
                            ? static_param.version_range_.snapshot_version_
                            : res.max_merged_trans_version_;
  ddl_scn_.set_min();
  tx_data_recycle_scn_.set_min();

  if (OB_FAIL(inner_init_with_merge_res(res))) {
  } else if (is_major_or_meta_merge_type(static_param.get_merge_type())
      && OB_FAIL(column_checksums_.assign(res.data_column_checksums_))) {
    LOG_WARN("fail to fill column checksum", K(ret), K(res.data_column_checksums_));
  }

  if (OB_SUCC(ret) && !is_valid()) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("init for merge sstable get invalid argument", K(ret), K(table_key), KPC(this),
        K(res), K(ctx));
  }
  return ret;
}

int ObTabletCreateSSTableParam::init_for_ddl(blocksstable::ObSSTableIndexBuilder *sstable_index_builder,
                                             const ObTabletDDLParam &ddl_param,
                                             const blocksstable::ObSSTable *first_ddl_sstable,
                                             const ObStorageSchema &storage_schema,
                                             const int64_t macro_block_column_count,
                                             const int64_t create_schema_version_on_tablet,
                                             const ObIArray<blocksstable::MacroBlockId> &macro_id_array)
{
  int ret = OB_SUCCESS;
  SMART_VAR(blocksstable::ObSSTableMergeRes, res) {
    int64_t column_count = 0;
    share::schema::ObTableMode table_mode = storage_schema.get_table_mode_struct();
    share::schema::ObIndexType index_type = storage_schema.get_index_type();
    int64_t rowkey_column_cnt = storage_schema.get_rowkey_column_num() + ObMultiVersionRowkeyHelpper::get_extra_rowkey_col_cnt();
    common::ObRowStoreType row_store_type = storage_schema.get_row_store_type();

    if (nullptr != first_ddl_sstable) {
      blocksstable::ObSSTableMetaHandle meta_handle;
      if (OB_FAIL(first_ddl_sstable->get_meta(meta_handle))) {
      } else {
        column_count = meta_handle.get_sstable_meta().get_column_count();
        table_mode = meta_handle.get_sstable_meta().get_basic_meta().table_mode_;
        index_type = static_cast<share::schema::ObIndexType>(meta_handle.get_sstable_meta().get_basic_meta().index_type_);
        rowkey_column_cnt = meta_handle.get_sstable_meta().get_basic_meta().rowkey_column_count_;
        row_store_type = meta_handle.get_sstable_meta().get_basic_meta().latest_row_store_type_;
      }
    } else { // row store sstable
      if (OB_FAIL(storage_schema.get_stored_column_count_in_sstable(column_count))) {
      } else if (macro_block_column_count > 0 && macro_block_column_count < column_count) {
        LOG_INFO("use macro block column count", K(ddl_param), K(macro_block_column_count), K(column_count));
        column_count = macro_block_column_count;
      }
    }
    if (OB_FAIL(ret)) {
    } else if (OB_FAIL(sstable_index_builder->close(res))) {
    } else if (OB_UNLIKELY((ddl_param.table_key_.is_major_sstable() ||
                            ddl_param.table_key_.is_ddl_sstable()) &&
                            res.row_count_ > 0 &&
                            res.max_merged_trans_version_ != ddl_param.snapshot_version_)) {
      ret = OB_ERR_UNEXPECTED;
      LOG_WARN("max_merged_trans_version_ in res is different from ddl snapshot version", K(ret),
                K(res), K(ddl_param));
    } else {
      table_key_ = ddl_param.table_key_;
      table_mode_ = table_mode;
      index_type_ = index_type;
      rowkey_column_cnt_ = rowkey_column_cnt;
      schema_version_ = create_schema_version_on_tablet;
      latest_row_store_type_ = row_store_type;
      create_snapshot_version_ = ddl_param.snapshot_version_;
      ddl_scn_ = ddl_param.start_scn_;
      column_cnt_ = column_count;
      max_merged_trans_version_ = ddl_param.snapshot_version_;
      filled_tx_scn_ = table_key_.get_end_scn();
      sstable_logic_seq_ = 0;
      progressive_merge_round_ = 0;
      progressive_merge_step_ = 0;
      tx_data_recycle_scn_.set_min();
      recycle_version_ = 0;

      if (OB_FAIL(inner_init_with_merge_res(res))) {
      }
      if (OB_SUCC(ret)) {
        if (macro_id_array.count() > 0) {
          ret = OB_ERR_UNEXPECTED;
          LOG_WARN("other_block_ids should be empty in share nothing mode", K(ret), K(macro_id_array.count()));
        }
      }
      if (OB_FAIL(ret)) {
      } else if (OB_FAIL(column_checksums_.assign(res.data_column_checksums_))) {
      } else if (OB_UNLIKELY(column_checksums_.count() != column_count)) {
        // we have corrected the col_default_checksum_array_ in prepare_index_data_desc
        ret = OB_ERR_UNEXPECTED;
        LOG_WARN("unexpected column checksums", K(ret), K(column_count), KPC(this));
      }

      if (OB_SUCC(ret)) {
        if (!is_valid()) {
          ret = OB_INVALID_ARGUMENT;
          LOG_WARN("init for ddl sstable get invalid argument", K(ret), K(ddl_param), KPC(this),
              K(res));
        }
      }
    }
  }

  return ret;
}

int ObTabletCreateSSTableParam::init_for_ddl_mem(const ObITable::TableKey &table_key,
                                                 const share::SCN &ddl_start_scn,
                                                 const ObStorageSchema &storage_schema,
                                                 ObBlockMetaTree &block_meta_tree)
{
  int ret = OB_SUCCESS;
  int64_t column_count = 0;
  const ObDataStoreDesc &data_desc = block_meta_tree.get_data_desc();
  const int64_t root_block_size = sizeof(ObBlockMetaTree);

  if (OB_FAIL(storage_schema.get_stored_column_count_in_sstable(column_count))) {
  } else {
    table_key_ = table_key;
    if (table_key.table_type_ == ObITable::TableType::MINI_SSTABLE) {
      table_key_.table_type_ = ObITable::TableType::DDL_MEM_MINI_SSTABLE;
    } else {
      table_key_.table_type_ = ObITable::TableType::DDL_MEM_SSTABLE;
    }
    rowkey_column_cnt_ = storage_schema.get_rowkey_column_num() + ObMultiVersionRowkeyHelpper::get_extra_rowkey_col_cnt();
    column_cnt_ = column_count;
    is_ready_for_read_ = true;
    table_mode_ = storage_schema.get_table_mode_struct();
    index_type_ = storage_schema.get_index_type();
    schema_version_ = storage_schema.get_schema_version();
    latest_row_store_type_ = storage_schema.get_row_store_type();
    create_snapshot_version_ = table_key.get_snapshot_version();
    max_merged_trans_version_ = table_key.get_snapshot_version();
    ddl_scn_ = ddl_start_scn;
    root_row_store_type_ = data_desc.get_row_store_type(); // for root block, not used for ddl memtable
    data_index_tree_height_ = 2; // fixed tree height, because there is only one root block
    contain_uncommitted_row_ = table_key.is_minor_sstable();
    compressor_type_ = data_desc.get_compressor_type();
    use_old_macro_block_count_ = 0; // all new, no reuse
    index_blocks_cnt_ = 0; // index macro block count, the index is in memory, so be 0.
    other_block_ids_.reset(); // other blocks contains only index macro blocks now, so empty.
    filled_tx_scn_ = table_key.is_major_sstable() ? SCN::min_scn() : table_key.get_end_scn();
    tx_data_recycle_scn_.set_min();
    sstable_logic_seq_ = 0;
    row_count_ = 0;
    recycle_version_ = 0;
    root_macro_seq_ = 0;
    nested_offset_ = 0;
    nested_size_ = 0;
    data_blocks_cnt_ = 0;
    micro_block_cnt_ = 0;
    occupy_size_ = 0;
    original_size_ = 0;
    progressive_merge_round_ = 0;
    progressive_merge_step_ = 0;

    if (OB_SUCC(ret)) {
      // set root block for data tree
      if (OB_FAIL(root_block_addr_.set_mem_addr(0/*offset*/, root_block_size/*size*/))) {
      } else {
        root_block_data_.type_ = ObMicroBlockData::DDL_BLOCK_TREE;
        root_block_data_.buf_ = reinterpret_cast<char *>(&block_meta_tree);
        root_block_data_.size_ = root_block_size;
      }
    }

    if (OB_SUCC(ret)) {
      // set root block for secondary meta tree
      if (OB_FAIL(data_block_macro_meta_addr_.set_mem_addr(0/*offset*/, root_block_size/*size*/))) {
      } else {
        data_block_macro_meta_.type_ = ObMicroBlockData::DDL_BLOCK_TREE;
        data_block_macro_meta_.buf_ = reinterpret_cast<char *>(&block_meta_tree);
        data_block_macro_meta_.size_ = root_block_size;
      }
    }
  }
  return ret;
}

int ObTabletCreateSSTableParam::init_for_fork(const ObTabletID &dst_tablet_id,
                                               const ObITable::TableKey &src_table_key,
                                               const blocksstable::ObSSTableBasicMeta &basic_meta,
                                               const int64_t schema_version,
                                               const blocksstable::ObSSTableMergeRes &res,
                                               const share::SCN &max_end_scn)
{
  int ret = OB_SUCCESS;
  table_key_ = src_table_key;
  table_key_.tablet_id_ = dst_tablet_id;
  // For fork rewrite: limit end_scn to max_end_scn (e.g., fork_snapshot_version)
  if (max_end_scn.is_valid() && table_key_.scn_range_.end_scn_ > max_end_scn) {
    table_key_.scn_range_.end_scn_ = max_end_scn;
  }
  sstable_logic_seq_ = basic_meta.sstable_logic_seq_;
  filled_tx_scn_ = basic_meta.filled_tx_scn_;
  table_mode_ = basic_meta.table_mode_;
  index_type_ = static_cast<share::schema::ObIndexType> (basic_meta.index_type_);
  rowkey_column_cnt_ = basic_meta.rowkey_column_count_;
  latest_row_store_type_ = basic_meta.latest_row_store_type_;
  recycle_version_ = basic_meta.recycle_version_;
  schema_version_ = schema_version; // use new schema version.
  create_snapshot_version_ = basic_meta.create_snapshot_version_;
  ddl_scn_ = basic_meta.ddl_scn_;
  progressive_merge_round_ = basic_meta.progressive_merge_round_;
  progressive_merge_step_ = basic_meta.progressive_merge_step_;

  ddl_scn_.set_min();
  max_merged_trans_version_ = res.max_merged_trans_version_;
  column_cnt_ = res.data_column_cnt_;
  tx_data_recycle_scn_.set_min();

  if (OB_FAIL(inner_init_with_merge_res(res))) {
  }
  if (OB_SUCC(ret) && table_key_.is_major_sstable()) {
    if (OB_FAIL(column_checksums_.assign(res.data_column_checksums_))) {
    }
  }
  return ret;
}                                          



int ObTabletCreateSSTableParam::init_for_fork(
    const blocksstable::ObSSTableCloneParam &sstable_param,
    const ObTabletID &dst_tablet_id,
    const ObITable::TableKey &src_table_key,
    const blocksstable::ObSSTableMeta &sstable_meta,
    const share::SCN &max_end_scn)
{
  int ret = OB_SUCCESS;

  table_key_ = src_table_key;
  table_key_.tablet_id_ = dst_tablet_id;
  // For fork reuse: limit end_scn to max_end_scn (e.g., fork_snapshot_scn)
  if (max_end_scn.is_valid() && table_key_.scn_range_.end_scn_ > max_end_scn) {
    LOG_WARN("fork reuse sstable end_scn exceeds max_end_scn, truncating",
        "original_end_scn", table_key_.scn_range_.end_scn_,
        K(max_end_scn),
        K(dst_tablet_id),
        K(src_table_key));
    table_key_.scn_range_.end_scn_ = max_end_scn;
  }

  sstable_logic_seq_ = sstable_param.basic_meta_.sstable_logic_seq_;
  schema_version_ = sstable_param.basic_meta_.schema_version_;
  create_snapshot_version_ = sstable_param.basic_meta_.create_snapshot_version_;
  table_mode_ = sstable_param.basic_meta_.table_mode_;
  index_type_ = static_cast<share::schema::ObIndexType>(sstable_param.basic_meta_.index_type_);
  progressive_merge_round_ = sstable_param.basic_meta_.progressive_merge_round_;
  progressive_merge_step_ = sstable_param.basic_meta_.progressive_merge_step_;
  is_ready_for_read_ = true;
  root_row_store_type_ = sstable_param.basic_meta_.root_row_store_type_;
  latest_row_store_type_ = sstable_param.basic_meta_.latest_row_store_type_;
  index_blocks_cnt_ = sstable_param.basic_meta_.index_macro_block_count_;
  data_blocks_cnt_ = sstable_param.basic_meta_.data_macro_block_count_;
  micro_block_cnt_ = sstable_param.basic_meta_.data_micro_block_count_;
  use_old_macro_block_count_ = sstable_param.basic_meta_.use_old_macro_block_count_;
  row_count_ = sstable_param.basic_meta_.row_count_;
  column_cnt_ = sstable_param.basic_meta_.column_cnt_;
  data_checksum_ = sstable_param.basic_meta_.data_checksum_;
  occupy_size_ = sstable_param.basic_meta_.occupy_size_;
  original_size_ = sstable_param.basic_meta_.original_size_;
  max_merged_trans_version_ = sstable_param.basic_meta_.max_merged_trans_version_;
  ddl_scn_ = sstable_param.basic_meta_.ddl_scn_;
  filled_tx_scn_ = sstable_param.basic_meta_.filled_tx_scn_;
  tx_data_recycle_scn_ = sstable_param.basic_meta_.tx_data_recycle_scn_;
  contain_uncommitted_row_ = sstable_param.basic_meta_.contain_uncommitted_row_;
  compressor_type_ = sstable_param.basic_meta_.compressor_type_;
  rowkey_column_cnt_ = sstable_param.basic_meta_.rowkey_column_count_;
  root_macro_seq_ = sstable_param.basic_meta_.root_macro_seq_;
  is_meta_root_ = sstable_param.is_meta_root_;
  root_block_addr_.set_none_addr();
  data_block_macro_meta_addr_.set_none_addr();

  data_index_tree_height_ = sstable_param.basic_meta_.data_index_tree_height_;
  recycle_version_ = sstable_param.basic_meta_.recycle_version_;

  const blocksstable::ObSSTableMacroInfo &macro_info = sstable_meta.get_macro_info();
  nested_offset_ = macro_info.get_nested_offset();
  nested_size_ = macro_info.get_nested_size();

  ObSEArray<blocksstable::MacroBlockId, 64> data_block_ids;
  ObSEArray<blocksstable::MacroBlockId, 64> other_block_ids;

  if (OB_FAIL(column_checksums_.assign(sstable_param.column_checksums_))) {
  } else if (OB_FAIL(collect_macro_block_ids_from_meta(macro_info, data_block_ids, other_block_ids))) {
  }

  if (OB_FAIL(ret)) {
  } else if (OB_FAIL(blocksstable::ObSSTableMetaCompactUtil::fix_filled_tx_scn_value_for_compact(table_key_, filled_tx_scn_))) {
  } else if (OB_FAIL(inner_init_with_embedded_meta(sstable_param, data_block_ids, other_block_ids))) {
  } else if (!is_valid()) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("init for fork sstable get invalid argument", K(ret), K(sstable_param), KPC(this));
  }

  return ret;
}

int ObTabletCreateSSTableParam::collect_macro_block_ids_from_meta(
    const blocksstable::ObSSTableMacroInfo &macro_info,
    common::ObIArray<blocksstable::MacroBlockId> &data_block_ids,
    common::ObIArray<blocksstable::MacroBlockId> &other_block_ids)
{
  int ret = OB_SUCCESS;
  blocksstable::ObMacroIdIterator data_iter;
  blocksstable::ObMacroIdIterator other_iter;

  if (OB_FAIL(macro_info.get_data_block_iter(data_iter))) {
  } else if (OB_FAIL(macro_info.get_other_block_iter(other_iter))) {
  } else {
    // Collect data block IDs
    blocksstable::MacroBlockId macro_id;
    while (OB_SUCC(ret)) {
      if (OB_FAIL(data_iter.get_next_macro_id(macro_id))) {
        if (OB_ITER_END == ret) {
          ret = OB_SUCCESS;
          break;
        } else {
          LOG_WARN("failed to get next data macro id", K(ret));
        }
      } else if (OB_FAIL(data_block_ids.push_back(macro_id))) {
      }
    }

    // Collect other block IDs
    if (OB_SUCC(ret)) {
      while (OB_SUCC(ret)) {
        if (OB_FAIL(other_iter.get_next_macro_id(macro_id))) {
          if (OB_ITER_END == ret) {
            ret = OB_SUCCESS;
            break;
          } else {
            LOG_WARN("failed to get next other macro id", K(ret));
          }
        } else if (OB_FAIL(other_block_ids.push_back(macro_id))) {
        }
      }
    }
  }

  return ret;
}

int ObTabletCreateSSTableParam::init_for_mds(
    const compaction::ObBasicTabletMergeCtx &ctx,
    const blocksstable::ObSSTableMergeRes &res,
    const ObStorageSchema &mds_schema)
{
  // TODO: @baichangmin.bcm check ctx valid for mds
  // reference to merge info
  int ret = OB_SUCCESS;
  const compaction::ObStaticMergeParam &static_param = ctx.static_param_;

  ObITable::TableKey table_key;
  table_key.table_type_ = ctx.get_merged_table_type();
  table_key.tablet_id_ = ctx.get_tablet_id();
  table_key.scn_range_ = static_param.scn_range_;

  table_key_ = table_key;
  sstable_logic_seq_ = static_param.sstable_logic_seq_;
  filled_tx_scn_ = ctx.get_merge_scn();

  table_mode_ = mds_schema.get_table_mode_struct();
  index_type_ = mds_schema.get_index_type();
  rowkey_column_cnt_ = mds_schema.get_rowkey_column_num()
      + ObMultiVersionRowkeyHelpper::get_extra_rowkey_col_cnt();
  latest_row_store_type_ = mds_schema.get_row_store_type();
  recycle_version_ = 0;
  schema_version_ = mds_schema.get_schema_version();
  create_snapshot_version_ = static_param.create_snapshot_version_;
  progressive_merge_round_ = 0;
  progressive_merge_step_ = 0;

  column_cnt_ = res.data_column_cnt_;
  if (0 == res.row_count_ && 0 == res.max_merged_trans_version_) {
    // empty mini table merged forcely
    max_merged_trans_version_ = static_param.version_range_.snapshot_version_;
  } else {
    max_merged_trans_version_ = res.max_merged_trans_version_;
  }
  ddl_scn_.set_min();
  tx_data_recycle_scn_.set_min();

  if (OB_FAIL(inner_init_with_merge_res(res))) {
  } else if (is_major_or_meta_merge_type(static_param.get_merge_type())) {
    if (OB_FAIL(column_checksums_.assign(res.data_column_checksums_))) {
    }
  }

  if (OB_SUCC(ret)) {
    if (!is_valid()) {
      ret = OB_INVALID_ARGUMENT;
      LOG_WARN("init for mds sstable get invalid argument", K(ret), K(res), K(ctx), KPC(this));
    }
  }
  return ret;
}

int ObTabletCreateSSTableParam::inner_init_with_embedded_meta(
  const blocksstable::ObSSTableCloneParam &sstable_param,
  const common::ObIArray<blocksstable::MacroBlockId> &data_block_ids,
  const common::ObIArray<blocksstable::MacroBlockId> &other_block_ids)
{
  int ret = OB_SUCCESS;
  if (sstable_param.root_block_addr_.is_valid()) {
    root_block_addr_ = sstable_param.root_block_addr_;
    root_block_data_.buf_ = sstable_param.root_block_buf_;
    root_block_data_.size_ = sstable_param.root_block_addr_.size();
  }

  if (sstable_param.data_block_macro_meta_addr_.is_valid()) {
    data_block_macro_meta_addr_ = sstable_param.data_block_macro_meta_addr_;
    data_block_macro_meta_.buf_ = sstable_param.data_block_macro_meta_buf_;
    data_block_macro_meta_.size_ = sstable_param.data_block_macro_meta_addr_.size();
  }

  root_row_store_type_ = sstable_param.basic_meta_.root_row_store_type_;
  data_index_tree_height_ = sstable_param.basic_meta_.data_index_tree_height_;
  index_blocks_cnt_ = sstable_param.basic_meta_.index_macro_block_count_;
  data_blocks_cnt_ = sstable_param.basic_meta_.data_macro_block_count_;
  micro_block_cnt_ = sstable_param.basic_meta_.data_micro_block_count_;
  use_old_macro_block_count_ = sstable_param.basic_meta_.use_old_macro_block_count_;
  row_count_ = sstable_param.basic_meta_.row_count_;
  data_checksum_ = sstable_param.basic_meta_.data_checksum_;
  occupy_size_ = sstable_param.basic_meta_.occupy_size_;
  original_size_ = sstable_param.basic_meta_.original_size_;
  contain_uncommitted_row_ = sstable_param.basic_meta_.contain_uncommitted_row_;
  compressor_type_ = sstable_param.basic_meta_.compressor_type_;
  is_meta_root_ = sstable_param.is_meta_root_;
  root_macro_seq_ = sstable_param.basic_meta_.root_macro_seq_;
  if (OB_FAIL(data_block_ids_.assign(data_block_ids))) {
  } else if (OB_FAIL(other_block_ids_.assign(other_block_ids))) {
  }
  return ret;
}

} // namespace storage
} // namespace oceanbase
