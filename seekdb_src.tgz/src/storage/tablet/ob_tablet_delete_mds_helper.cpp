/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ob_tablet_delete_mds_helper.h"
#include "share/rc/ob_server_runtime.h"
#include "storage/tablet/ob_tablet_delete_replay_executor.h"
#include "storage/tx_storage/ob_ls_service.h"

#define USING_LOG_PREFIX MDS

using namespace oceanbase::common;

namespace oceanbase
{
namespace storage
{
int ObTabletDeleteMdsHelper::register_process(
    obcall::ObBatchRemoveTabletArg &arg,
    mds::BufferCtx &ctx)
{
  MDS_TG(1_s);
  int ret = OB_SUCCESS;

  if (CLICK_FAIL(delete_tablets(arg, ctx))) {
    LOG_WARN("failed to delete tablets", K(ret), K(arg));
  } else if (CLICK_FAIL(ObTabletCreateDeleteMdsUserData::set_tablet_empty_shell_trigger())) {
    LOG_WARN("failed to set_tablet_empty_shell_trigger", K(ret), K(arg));
  } else {
    LOG_INFO("delete tablet register", KR(ret), K(arg));
  }

  return ret;
}

int ObTabletDeleteMdsHelper::on_register(
    const char* buf,
    const int64_t len,
    mds::BufferCtx &ctx)
{
  MDS_TG(1_s);
  int ret = OB_SUCCESS;
  obcall::ObBatchRemoveTabletArg arg;
  int64_t pos = 0;
  bool exist = true;

  if (OB_ISNULL(buf) || OB_UNLIKELY(len <= 0)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid args", K(ret), KP(buf), K(len));
  } else if (CLICK_FAIL(arg.deserialize(buf, len, pos))) {
    LOG_WARN("failed to deserialize", K(ret));
  } else if (CLICK_FAIL(register_process(arg, ctx))) {
    LOG_WARN("failed to register_process", K(ret), K(arg));
  }

  return ret;
}

int ObTabletDeleteMdsHelper::replay_process(
    obcall::ObBatchRemoveTabletArg &arg,
    const share::SCN &scn,
    mds::BufferCtx &ctx)
{
  MDS_TG(1_s);
  int ret = OB_SUCCESS;

  if (CLICK_FAIL(replay_delete_tablets(arg, scn, ctx))) {
    LOG_WARN("failed to delete tablets", K(ret), K(arg), K(scn));
  } else if (CLICK_FAIL(ObTabletCreateDeleteMdsUserData::set_tablet_empty_shell_trigger())) {
    LOG_WARN("failed to set_tablet_empty_shell_trigger", K(ret), K(arg));
  } else {
    LOG_INFO("delete tablet replay", KR(ret), K(scn), K(arg));
  }

  return ret;
}

int ObTabletDeleteMdsHelper::on_replay(
    const char* buf,
    const int64_t len,
    const share::SCN &scn,
    mds::BufferCtx &ctx)
{
  MDS_TG(1_s);
  int ret = OB_SUCCESS;
  obcall::ObBatchRemoveTabletArg arg;
  int64_t pos = 0;
  bool exist = true;

  if (OB_ISNULL(buf) || OB_UNLIKELY(len <= 0)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid args", K(ret), KP(buf), K(len));
  } else if (CLICK_FAIL(arg.deserialize(buf, len, pos))) {
    LOG_WARN("failed to deserialize", K(ret));
  } else if (CLICK_FAIL(replay_process(arg, scn, ctx))) {
    LOG_WARN("failed to replay_process", K(ret), K(arg));
  }

  return ret;
}

int ObTabletDeleteMdsHelper::delete_tablets(
    const obcall::ObBatchRemoveTabletArg &arg,
    mds::BufferCtx &ctx)
{
  MDS_TG(1_s);
  int ret = OB_SUCCESS;
  ObStorageMetaMemMgr *t3m = ::oceanbase::share::server_service<::oceanbase::storage::ObStorageMetaMemMgr>();
  bool exist = false;
  ObTabletHandle tablet_handle;
  ObTabletMapKey key;

  ObLS *tenant_ls = nullptr;
  if (CLICK_FAIL(::oceanbase::share::server_service<::oceanbase::storage::ObLSService>()->get_ls(tenant_ls))) {
      LOG_WARN("failed to get ls", K(ret));
  } else {
    CLICK();
    for (int64_t i = 0; OB_SUCC(ret) && i < arg.tablet_ids_.count(); ++i) {
      MDS_TG(10_ms);
      exist = false;
      key.tablet_id_ = arg.tablet_ids_.at(i);

      if (CLICK_FAIL(ObTabletCreateDeleteHelper::get_tablet(key, tablet_handle))) {
        if (OB_TABLET_NOT_EXIST == ret) {
          exist = false;
          ret = OB_SUCCESS;
        } else {
          LOG_WARN("failed to get tablet", K(ret), K(key));
        }
      } else {
        exist = true;
      }

      if (CLICK_FAIL(ret)) {
      } else if (!exist) {
        ret = OB_ERR_UNEXPECTED;
        LOG_WARN("tablet does not exist", K(ret), K(key));
      } else if (CLICK_FAIL(set_tablet_deleted_status(
              tenant_ls->get_tablet_svr(), tablet_handle, ctx))) {
        LOG_ERROR("failed to set tablet deleted status", K(ret), K(key));
      }
    }
  }

  // remember to roll back if failed

  return ret;
}

int ObTabletDeleteMdsHelper::replay_delete_tablets(
    const obcall::ObBatchRemoveTabletArg &arg,
    const share::SCN &scn,
    mds::BufferCtx &ctx)
{
  MDS_TG(1_s);
  int ret = OB_SUCCESS;
  bool exist = false;
  ObRemoveTabletArg remove_tablet_arg;
  for (int64_t i = 0; OB_SUCC(ret) && i < arg.tablet_ids_.count(); ++i) {
    MDS_TG(10_ms);
    exist = true;
    remove_tablet_arg.tablet_id_ = arg.tablet_ids_.at(i);
    ObTabletDeleteReplayExecutor replayer;
    if (CLICK_FAIL(replayer.init(ctx, scn))) {
      LOG_ERROR("failed to init tablet delete replay executor", K(ret), K(remove_tablet_arg));
    } else if (CLICK_FAIL(replayer.execute(scn, remove_tablet_arg.tablet_id_))) {
      if (OB_TABLET_NOT_EXIST == ret) {
        exist = false;
        ret = OB_SUCCESS;
      } else {
        LOG_ERROR("failed to replay", K(ret), K(remove_tablet_arg), K(scn));
      }
    }

    if (OB_FAIL(ret)) {
    } else if (!exist) {
      // tablet does not exist, maybe already deleted, do nothing
    }
  }

  // remember to roll back if failed

  return ret;
}

int ObTabletDeleteMdsHelper::set_tablet_deleted_status(
    ObLSTabletService *ls_tablet_service,
    ObTabletHandle &tablet_handle,
    mds::BufferCtx &ctx)
{
  MDS_TG(10_ms);
  int ret = OB_SUCCESS;
  ObTablet *tablet = tablet_handle.get_obj();
  mds::MdsCtx &user_ctx = static_cast<mds::MdsCtx&>(ctx);
  ObTabletCreateDeleteMdsUserData data;
  const int64_t timeout = THIS_WORKER.get_timeout_remain();
  if (OB_ISNULL(tablet)) {
    ret = OB_ERR_UNEXPECTED;
    LOG_WARN("tablet is null", K(ret), K(tablet_handle));
  } else if (CLICK_FAIL(tablet->ObITabletMdsInterface::get_tablet_status(share::SCN::max_scn(), data, timeout))) {
    LOG_WARN("failed to get tablet status", K(ret), K(timeout));
  } else {
    data.tablet_status_ = ObTabletStatus::DELETED;
    data.data_type_ = ObTabletMdsUserDataType::REMOVE_TABLET;
    if (CLICK_FAIL(ls_tablet_service->set_tablet_status(tablet->get_tablet_meta().tablet_id_, data, user_ctx))) {
      LOG_WARN("failed to set mds data", K(ret));
    }
  }

  return ret;
}

} // namespace storage
} // namespace oceanbase
