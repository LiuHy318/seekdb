/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OB_TABLE_STORE_STAT_MGR_H_
#define OB_TABLE_STORE_STAT_MGR_H_
#include <stdint.h>
#include "lib/oblog/ob_log_module.h"
#include "lib/utility/ob_print_utils.h"
#include "lib/lock/ob_spin_rwlock.h"
#include "lib/allocator/page_arena.h"
#include "lib/hash_func/murmur_hash.h"
#include "lib/hash/ob_hashmap.h"
#include "lib/task/ob_timer.h"
#include "common/ob_tablet_id.h"

namespace oceanbase
{
namespace storage
{
struct ObMergeIterStat
{
public:
  ObMergeIterStat() { reset(); };
  ~ObMergeIterStat() = default;
  OB_INLINE void reset() { MEMSET(this, 0, sizeof(ObMergeIterStat)); }
  bool is_valid() const;
  int add(const ObMergeIterStat& other);
  TO_STRING_KV(K_(call_cnt), K_(output_row_cnt));

  int64_t call_cnt_;
  int64_t output_row_cnt_;
};

struct ObBlockAccessStat
{
public:
  ObBlockAccessStat() { reset(); };
  ~ObBlockAccessStat() = default;
  OB_INLINE void reset() { MEMSET(this, 0, sizeof(ObBlockAccessStat)); }
  bool is_valid() const;
  int add(const ObBlockAccessStat& other);
  TO_STRING_KV(K_(effect_read_cnt), K_(empty_read_cnt));

  int64_t effect_read_cnt_;
  int64_t empty_read_cnt_;
};

struct ObTableStoreStat
{
public:
  ObTableStoreStat();
  ~ObTableStoreStat() = default;

  void reset();
  bool is_valid() const;
  TO_STRING_KV(K_(tablet_id), K_(table_id),
               K_(row_cache_hit_cnt), K_(row_cache_miss_cnt), K_(row_cache_put_cnt),
               K_(block_cache_hit_cnt), K_(block_cache_miss_cnt),
               K_(access_row_cnt), K_(output_row_cnt), K_(fuse_row_cache_hit_cnt),
               K_(fuse_row_cache_miss_cnt), K_(fuse_row_cache_put_cnt),
               K_(macro_access_cnt), K_(micro_access_cnt), K_(pushdown_micro_access_cnt),
               K_(pushdown_row_access_cnt), K_(pushdown_row_select_cnt),
               K_(single_get_stat), K_(multi_get_stat), K_(index_back_stat),
               K_(single_scan_stat), K_(multi_scan_stat),
               K_(exist_row), K_(get_row), K_(scan_row),
               K_(logical_read_cnt), K_(physical_read_cnt));

  common::ObTabletID tablet_id_;
  common::ObTableID table_id_;
  int64_t row_cache_hit_cnt_;
  int64_t row_cache_miss_cnt_;
  int64_t row_cache_put_cnt_;
  int64_t block_cache_hit_cnt_;
  int64_t block_cache_miss_cnt_;
  int64_t index_block_cache_hit_cnt_;
  int64_t index_block_cache_miss_cnt_;
  int64_t access_row_cnt_;
  int64_t output_row_cnt_;
  int64_t fuse_row_cache_hit_cnt_;
  int64_t fuse_row_cache_miss_cnt_;
  int64_t fuse_row_cache_put_cnt_;
  int64_t macro_access_cnt_;
  int64_t micro_access_cnt_;
  int64_t pushdown_micro_access_cnt_;
  int64_t pushdown_row_access_cnt_;
  int64_t pushdown_row_select_cnt_;
  ObMergeIterStat single_get_stat_;
  ObMergeIterStat multi_get_stat_;
  ObMergeIterStat index_back_stat_; // index back only works in multi_get mode
  ObMergeIterStat single_scan_stat_;
  ObMergeIterStat multi_scan_stat_;
  ObBlockAccessStat exist_row_;
  ObBlockAccessStat get_row_;
  ObBlockAccessStat scan_row_;
  int64_t logical_read_cnt_;
  int64_t physical_read_cnt_;
};

struct ObTableStoreStatKey
{
public:
  ObTableStoreStatKey() : table_id_(common::OB_INVALID_ID), tablet_id_(common::OB_INVALID_ID) {}
  ObTableStoreStatKey(const ObTableID table_id, const ObTabletID tablet_id) : table_id_(table_id), tablet_id_(tablet_id) {}
  ~ObTableStoreStatKey() {}
  OB_INLINE uint64_t hash() const
  {
    uint64_t hash_ret = 0;
    hash_ret = common::murmurhash(&table_id_, sizeof(ObTableID), 0);
    hash_ret = common::murmurhash(&tablet_id_, sizeof(ObTabletID), hash_ret);
    return hash_ret;
  }
  int hash(uint64_t &hash_val) const
  {
    hash_val = hash();
    return OB_SUCCESS;
  }
  OB_INLINE bool operator ==(const ObTableStoreStatKey &other) const
  {
    return (table_id_ == other.table_id_) && (tablet_id_ == other.tablet_id_);
  }
  OB_INLINE bool operator !=(const ObTableStoreStatKey &other) const
  {
    return (*this == other);
  }
  TO_STRING_KV(K_(table_id), K_(tablet_id));
  common::ObTableID table_id_;
  common::ObTabletID tablet_id_;
};

struct ObTableStoreStatNode
{
public:
  ObTableStoreStatNode() : pre_(NULL), next_(NULL), stat_(NULL) {}
  ~ObTableStoreStatNode() { reset(); }
  OB_INLINE void reset() { pre_ = next_ = NULL; stat_ = NULL; }
  ObTableStoreStatNode *pre_;
  ObTableStoreStatNode *next_;
  ObTableStoreStat *stat_;
};

class ObTableStoreStatIterator
{
public:
  ObTableStoreStatIterator();
  virtual ~ObTableStoreStatIterator();
  int open();
  int get_next_stat(ObTableStoreStat &stat);
  void reset();
private:
  int64_t cur_idx_;
  bool is_opened_;
};

} //namespace storage
} //namespace oceanbase
#endif /* OB_TABLE_STORE_STAT_MGR_H_ */
