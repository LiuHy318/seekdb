/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_STORAGE_SCHEMA_RECORDER_
#define OCEANBASE_STORAGE_STORAGE_SCHEMA_RECORDER_

#include "lib/ob_define.h"
#include "storage/ob_storage_clog_recorder.h"
#include "storage/ob_storage_schema.h"
#include "share/schema/ob_multi_version_schema_service.h"
#include "share/scn.h"

namespace oceanbase
{

namespace share
{
namespace schema
{
class ObSchemaGetterGuard;
class ObMultiVersionSchemaService;
} // namespace share
} // namespace schema

namespace storage
{
class ObTablet;
class ObIMemtableMgr;
class ObTabletHandle;

class ObStorageSchemaRecorder : public ObIStorageClogRecorder
{

public:
  ObStorageSchemaRecorder();
  ~ObStorageSchemaRecorder();

  int init(
      const ObTabletID &tablet_id,
      const int64_t saved_schema_version,
      logservice::ObLogHandler *log_handler);
  void destroy();
  bool is_inited() const { return is_inited_; }
  int64_t get_max_column_cnt() const { return max_column_cnt_; }

  // follower
  int replay_schema_log(const share::SCN &scn, const char *buf, const int64_t size, int64_t &pos);
  // leader
  int try_update_storage_schema(
      const int64_t table_id,
      const int64_t table_version,
      ObIAllocator &allocator,
      const int64_t timeout);

  ObStorageSchemaRecorder(const ObStorageSchemaRecorder&) = delete;
  ObStorageSchemaRecorder& operator=(const ObStorageSchemaRecorder&) = delete;
  INHERIT_TO_STRING_KV("ObIStorageClogRecorder", ObIStorageClogRecorder, K_(tablet_id));

private:
  virtual int inner_replay_clog(
      const int64_t update_version,
      const share::SCN &scn,
      const char *buf,
      const int64_t size,
      int64_t &pos) override;
  virtual int on_sync_clog_success(const int64_t update_version) override;
  virtual void on_sync_clog_failure() override;

  int get_schema(int64_t &table_version);

  virtual int prepare_struct_in_lock(
      int64_t &update_version,
      ObIAllocator *allocator,
      char *&clog_buf,
      int64_t &clog_len) override;
  virtual int submit_log(
      const int64_t update_version,
      const char *clog_buf,
      const int64_t clog_len) override;
  virtual void free_struct_in_lock() override
  {
    free_allocated_info();
  }
  int generate_clog(
      char *&clog_buf,
      int64_t &clog_len);
  int64_t calc_schema_log_size() const;
  void free_allocated_info();
  int try_update_with_lock(const int64_t table_id, const int64_t table_version, const int64_t expire_ts);

  bool is_inited_;
  bool ignore_storage_schema_;
  char *clog_buf_;

  ObTabletHandle *tablet_handle_ptr_;
  share::schema::ObSchemaGetterGuard *schema_guard_;
  ObStorageSchema *storage_schema_;
  ObIAllocator *allocator_;

  ObTabletID tablet_id_;
  int64_t table_id_;
  int64_t max_column_cnt_;
};

} // storage
} // oceanbase
#endif /* OCEANBASE_STORAGE_STORAGE_SCHEMA_RECORDER_ */
