/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_TRANSACTION_OB_MULTI_DATA_SOURCE_
#define OCEANBASE_TRANSACTION_OB_MULTI_DATA_SOURCE_

#include "lib/container/ob_se_array.h"
#include "lib/list/ob_list.h"
#include "lib/utility/ob_unify_serialize.h"
#include "lib/string/ob_string.h"
#include "share/scn.h"
#include "storage/tx/ob_multi_data_source_printer.h"
#include "storage/tx/ob_multi_data_source_tx_buffer_node.h"
#include "storage/tx/ob_tx_seq.h"

namespace oceanbase
{

namespace memtable
{
class ObMemtableCtx;
}

namespace storage
{
namespace mds
{
class BufferCtxNode;
}
}

namespace transaction
{
class ObTxCtx;
struct ObMulSourceDataNotifyArg;

enum class ObTxDataSourceType : int64_t
{
  UNKNOWN = -1,
  // for memory table
  MEM_TABLE = 0,
  // for table lock
  TABLE_LOCK = 1,
  // for log stream table(create log stream)
  LS_TABLE = 2,
  // 5 was DDL_BARRIER. Reserved; do not reuse.
  // Marker for DDL transactions consumed by the local Change Stream.
  DDL_TRANS = 6,
#define NEED_GENERATE_MDS_FRAME_CODE_FOR_TRANSACTION
#define _GENERATE_MDS_FRAME_CODE_FOR_TRANSACTION_(helper_class_name, buffer_ctx_type, ID, ENUM_NAME) ENUM_NAME = ID,
  #include "storage/multi_data_source/compile_utility/mds_register.h"
#undef _GENERATE_MDS_FRAME_CODE_FOR_TRANSACTION_
#undef NEED_GENERATE_MDS_FRAME_CODE_FOR_TRANSACTION
  MAX_TYPE = 100
};

inline bool uses_builtin_mds_notifier(const ObTxDataSourceType type)
{
  return ObTxDataSourceType::TABLE_LOCK == type
      || ObTxDataSourceType::LS_TABLE == type
      || ObTxDataSourceType::DDL_TRANS == type;
}

enum class NotifyType : int64_t
{
  UNKNOWN = -1,
  REGISTER_SUCC = 0,
  ON_REDO = 1,
  TX_END = 2,
  ON_PREPARE = 3,
  ON_COMMIT = 4,
  ON_ABORT = 5
};

class ObMulSourceTxDataNotifier
{
public:
  static int notify(const ObTxBufferNodeArray &array,
                    const NotifyType type,
                    const ObMulSourceDataNotifyArg &arg,
                    ObTxCtx *part_ctx,
                    int64_t &total_time);
  static int notify_table_lock(const ObTxBufferNodeArray &array,
                               const ObMulSourceDataNotifyArg &arg,
                               ObTxCtx *part_ctx,
                               int64_t &total_time);
private:
  static void ob_abort_log_cb_notify_(const NotifyType type, int err_code, bool for_replay);
  static int notify_table_lock(const NotifyType type,
                               const char *buf, const int64_t len,
                               const ObMulSourceDataNotifyArg &arg,
                               memtable::ObMemtableCtx *mt_ctx);
  static int notify_ls_table(const NotifyType type,
                             const char *buf, const int64_t len,
                             const ObMulSourceDataNotifyArg &arg);
  static int notify_ddl_trans(const NotifyType type,
                              const char *buf, const int64_t len,
                              const ObMulSourceDataNotifyArg &arg);
};

class ObMulSourceTxDataDump
{
public:
   static const char* dump_buf(ObTxDataSourceType source_type,
                               const char * buf,
                               const int64_t len,
                               ObCStringHelper &helper);
private:


};

struct ObRegisterMdsFlag
{
  bool need_flush_redo_instantly_;
  share::SCN mds_base_scn_;

  ObRegisterMdsFlag() { reset(); }
  void reset()
  {
    need_flush_redo_instantly_ = false;
    mds_base_scn_.reset();
  }

  TO_STRING_KV(K(need_flush_redo_instantly_), K(mds_base_scn_));

  OB_UNIS_VERSION(1);
};

class ObMDSInnerSQLStr
{
  OB_UNIS_VERSION(1);

public:
  ObMDSInnerSQLStr();
  ~ObMDSInnerSQLStr();
  void reset();

  int set(const char *mds_buf,
          const int64_t mds_buf_len,
          const ObTxDataSourceType &type,
          const ObRegisterMdsFlag &register_flag);

  const char *get_msd_buf() { return mds_str_.ptr(); }
  int64_t get_msd_buf_len() { return mds_str_.length(); }
  const ObTxDataSourceType &get_msd_type() { return type_; }
  const ObRegisterMdsFlag &get_register_flag() { return register_flag_; }

  TO_STRING_KV(K(mds_str_), "type_", ObMultiDataSourcePrinter::to_str_mds_type(type_), K(register_flag_));

private:
  // const char *msd_buf_;
  // int64_t msd_buf_len_;
  // bool from_copy_;
  common::ObString mds_str_;
  ObTxDataSourceType type_;
  ObRegisterMdsFlag register_flag_;
};

} // transaction

} // oceanbase

#endif
