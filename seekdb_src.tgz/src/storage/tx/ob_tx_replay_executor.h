/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_TRANSACTION_OB_TX_REPLAY_EXECUTOR
#define OCEANBASE_TRANSACTION_OB_TX_REPLAY_EXECUTOR

#include "storage/tx/ob_tx_log.h"
#include "storage/ob_i_table.h"

#include "lib/worker.h"
#include "storage/ob_storage_table_guard.h"

namespace oceanbase
{
namespace common
{
class ObTabletID;
};
namespace memtable
{
class ObMemtableCtx;
class ObMemtable;
class ObMemtableMutatorIterator;
};
namespace storage
{
class ObLSTxService;
class ObLSTabletService;
class ObTableHandleV2;
class ObStoreCtx;
class ObStorageTableGuard;
};
namespace transaction
{
class ObTxLogBlock;
class ObTxCtx;
class ObTransService;

typedef ObTxCtx ReplayTxCtx;

class ObTxReplayExecutor {
public:
  static int execute(storage::ObLS *ls,
                     storage::ObLSTxService *ls_tx_srv,
                     const char *buf,
                     const int64_t size,
                     const int skip_pos,
                     const palf::LSN &lsn,
                     const share::SCN &log_timestamp,
                     const logservice::ObLogBaseHeader &base_header);

public:
  TO_STRING_KV(KP(ctx_),
               KP(ls_),
               KP(ls_tx_srv_),
               KP(mt_ctx_),
               K(log_block_),
               K_(replay_queue),
               K_(replaying_log_entry_no),
               K(lsn_),
               K(log_ts_ns_),
               K(base_header_));

private:
  ObTxReplayExecutor(storage::ObLS *ls,
                     storage::ObLSTxService *ls_tx_srv,
                     const palf::LSN &lsn,
                     const share::SCN &log_timestamp,
                     const logservice::ObLogBaseHeader &base_header)
      : ctx_(nullptr),
        ls_(ls),
        ls_tx_srv_(ls_tx_srv),
        replay_queue_(0),
        replaying_log_entry_no_(0),
        lsn_(lsn),
        log_ts_ns_(log_timestamp),
        mmi_ptr_(nullptr),
        mt_ctx_(nullptr),
        first_created_ctx_(false),
        has_redo_(false),
        tx_part_log_no_(0),
        mvcc_row_count_(0),
        table_lock_row_count_(0),
        base_header_(base_header)
  {}

  ~ObTxReplayExecutor() { ob_free(mmi_ptr_); }

private:
  int do_replay_(const char *buf,
                 const int64_t size,
                 const int skip_pos);
  int prepare_replay_(const char *buf, const int64_t &size, const int skip_pos);
  int try_get_tx_ctx_();
  int iter_next_log_for_replay_(ObTxLogHeader &header);
  int before_replay_redo_();
  void finish_replay_(const int retcode);

  int errsim_tx_replay_();

  int replay_redo_();
  int replay_tx_log_(const ObTxLogType log_type);
  int replay_rollback_to_();
  int replay_commit_info_();
  int replay_commit_();
  int replay_abort_();
  int replay_clear_();
  int replay_multi_source_data_();
  int replay_record_();
  bool is_tx_log_replay_queue() const { return replay_queue_ == 0; }
  int replay_redo_in_memtable_(ObTxRedoLog &redo, const bool serial_final, ObTxSEQ &max_seq_no);
  virtual int replay_one_row_in_memtable_(memtable::ObMutatorRowHeader& row_head,
                                          memtable::ObMemtableMutatorIterator *mmi_ptr);
  int prepare_memtable_replay_(storage::ObStorageTableGuard &w_guard,
                          storage::ObIMemtable *&mem_ptr);
  int replay_row_(storage::ObStoreCtx &store_ctx,
                  storage::ObTablet *tablet,
                  memtable::ObMemtableMutatorIterator *mmi_ptr);
  int replay_lock_(storage::ObStoreCtx &store_ctx,
                   storage::ObTablet *tablet,
                   memtable::ObMemtableMutatorIterator *mmi_ptr);
  bool can_replay() const;

  void rewrite_replay_retry_code_(int &ret_code);

private:
  DISALLOW_COPY_AND_ASSIGN(ObTxReplayExecutor);

  ReplayTxCtx *ctx_;
  storage::ObLS *ls_;
  storage::ObLSTxService *ls_tx_srv_;

  ObTxLogBlock log_block_;
  int16_t replay_queue_;
  int64_t replaying_log_entry_no_;
  palf::LSN lsn_;
  share::SCN log_ts_ns_;

  memtable::ObMemtableMutatorIterator * mmi_ptr_;
  memtable::ObMemtableCtx *mt_ctx_;
  // storage::ObTableHandleV2 mem_handle_;
  bool first_created_ctx_;
  bool has_redo_;

  int64_t tx_part_log_no_;
  // memtable::ObMemtable * mem_store_;
  int64_t mvcc_row_count_;
  int64_t table_lock_row_count_;
  const logservice::ObLogBaseHeader &base_header_;
};
}
} // namespace oceanbase

#endif
