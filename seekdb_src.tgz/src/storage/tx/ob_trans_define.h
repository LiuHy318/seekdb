/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_TRANSACTION_OB_TRANS_DEFINE_
#define OCEANBASE_TRANSACTION_OB_TRANS_DEFINE_

#include <cstdint>
#include "lib/time/ob_clock_generator.h"
#include "share/transaction/ob_tx_id.h"
#include "common/ob_range.h"
#include "common/storage/ob_sequence.h"
#include "common/ob_tablet_id.h"
#include "lib/core_local/ob_core_local_storage.h"
#include "lib/list/ob_list.h"
#include "lib/trace/ob_trace_event.h"
#include "share/log/palf/lsn.h"
#include "share/log/ob_log_base_header.h"
#include "share/scn.h"
#include "share/allocator/ob_reserve_arena.h"
#include "query/ob_sql_define.h"
#include "share/statement/ob_stmt_type.h"
#include "data_plane/transaction/ob_transaction_isolation.h"
#include "data_plane/transaction/ob_transaction_version.h"
#include "storage/tx/ob_committer_define.h"
#include "storage/tx/ob_trans_result.h"
#include "storage/tx/ob_multi_data_source_tx_buffer_node.h"
#include "storage/tx/ob_tx_on_demand_print.h"
#include "storage/tx/ob_tx_seq.h"

namespace oceanbase
{
namespace share
{
namespace schema
{
class ObSchemaGetterGuard;
}
namespace detector
{
class ObDetectorInnerReportInfo;
}
}
namespace common
{
class ObAddr;
template<int64_t N> class ObFixedLengthString;
class ObString;
class ObStoreRowkey;
class ObTabletID;
}

namespace storage
{
struct ObStoreRowLockState;
}

namespace sql
{
class ObBasicSessionInfo;
struct ObAuditRecordData;
}

namespace clog
{
class ObAggreBuffer;
}

namespace memtable
{
class ObMvccAccessCtx;
class ObMemtableCtx;
}

namespace transaction
{
class ObLSTxCtxMgr;
class ObTransCtx;
class ObTxCtx;
class ObMemtableKeyInfo;
class AggreLogTask;
class ObITxCallback;
class ObTxMultiDataSourceLog;
enum class NotifyType : int64_t;
typedef palf::LSN LogOffSet;
enum { MAX_CALLBACK_LIST_COUNT = 64 };
class ObReserveAllocator : public ObIAllocator
{
public:
  ObReserveAllocator() : pos_(0), size_(0) {}
  ~ObReserveAllocator() { reset(); }
  void *alloc(const int64_t sz)
  {
    return alloc_from_buf_(sz);
  }
  void* alloc(const int64_t sz, const ObMemAttr &attr)
  {
    UNUSED(attr);
    return alloc_from_buf_(sz);
  }
  void free(void *p)
  {
    // do nothing
  }
public:
  bool is_contain(void *p) const
  {
    return ((int64_t)p >= (int64_t)buf_) && ((int64_t)p < (int64_t)buf_ + size_);
  }
  void reset()
  {
    pos_ = 0;
    size_ = 0;
  }
  void reuse()
  {
    pos_ = 0;
  }
private:
  void *alloc_from_buf_(const int64_t sz)
  {
    void *ptr = NULL;
    const int64_t aligned_sz = ob_aligned_to2(sz, 16);
    if (pos_ + aligned_sz < size_) {
      ptr = reinterpret_cast<void *>(buf_ + pos_);
      pos_ = pos_ + aligned_sz;
    }
    return ptr;
  }
private:
  static const int64_t RESERVED_MEM_SIZE = 256;
private:
  char buf_[RESERVED_MEM_SIZE];
  int64_t pos_;
  int64_t size_;
};

class TransModulePageAllocator : public common::ModulePageAllocator
{
public:
  TransModulePageAllocator(const lib::ObLabel &label = "TransModulePage",
                           int64_t ctx_id = 0)
    : ModulePageAllocator(label, ctx_id) {}
  explicit TransModulePageAllocator(common::ObIAllocator &allocator)
    : ModulePageAllocator(allocator) {}
  virtual ~TransModulePageAllocator() {}
  void *alloc(const int64_t sz)
  {
    return inner_alloc_(sz, attr_);
  }
  void *alloc(const int64_t sz, const ObMemAttr &attr)
  {
    return inner_alloc_(sz, attr);
  }
  void free(void *ptr)
  {
    if (NULL != ptr) {
      inner_free_(ptr);
    }
  }
  void reset()
  {
    common::ModulePageAllocator::reset();
    reserve_allocator_.reset();
  }
protected:
  void *inner_alloc_(const int64_t sz, const ObMemAttr &attr)
  {
    void *ptr = ModulePageAllocator::alloc(sz, attr);
    if (NULL == ptr) {
      ptr = reserve_allocator_.alloc(sz);
    }
    return ptr;
  }
  void inner_free_(void *ptr)
  {
    if (reserve_allocator_.is_contain(ptr)) {
      reserve_allocator_.free(ptr);
    } else {
      ModulePageAllocator::free(ptr);
    }
  }
private:
  ObReserveAllocator reserve_allocator_;
};


struct ObLockForReadArg
{
  ObLockForReadArg(memtable::ObMvccAccessCtx &acc_ctx,
                   ObTransID data_trans_id,
                   ObTxSEQ data_sql_sequence,
                   bool read_latest,
                   bool read_uncommitted,
                   share::SCN scn)
    : mvcc_acc_ctx_(acc_ctx),
    data_trans_id_(data_trans_id),
    data_sql_sequence_(data_sql_sequence),
    read_latest_(read_latest),
    read_uncommitted_(read_uncommitted),
    scn_(scn) {}

  DECLARE_TO_STRING;

  memtable::ObMvccAccessCtx &mvcc_acc_ctx_;
  ObTransID data_trans_id_;
  ObTxSEQ data_sql_sequence_;
  bool read_latest_;
  bool read_uncommitted_;
  // SCN used for visibility checks; sstable uses end_scn, memtable uses ObMvccTransNode scn.
  share::SCN scn_;
};

class ObTransAccessMode
{
public:
  static const int32_t UNKNOWN = -1;
  static const int32_t READ_ONLY = 0;
  static const int32_t READ_WRITE = 1;
public:
  static bool is_valid(const int32_t mode)
  { return READ_ONLY == mode || READ_WRITE == mode; }
private:
  ObTransAccessMode() {}
  ~ObTransAccessMode() {}
};

class ObTransSnapshotGeneType
{
public:
  static const int32_t UNKNOWN = -1;
  static const int32_t CONSULT = 0;
  static const int32_t APPOINT = 1;
  static const int32_t NOTHING = 2;
public:
  static bool is_valid(const int32_t type)
  { return CONSULT == type
      || APPOINT == type
      || NOTHING == type; }
  static const char *cstr(int32_t type)
  {
    const char *ret_str = "UNKNOWN";
    switch (type) {
      case CONSULT:
        ret_str = "CONSULT";
        break;

      case APPOINT:
        ret_str = "APPOINT";
        break;

      case NOTHING:
        ret_str = "NOTHING";
        break;

      default:
        ret_str = "UNKNOWN";
        break;
    }
    return ret_str;
  }
public:
  ObTransSnapshotGeneType() {}
  ~ObTransSnapshotGeneType() {}
};

class ObTransType
{
public:
  static const int32_t UNKNOWN = -1;
  static const int32_t TRANS_NORMAL = 0;
  static const int32_t TRANS_MAJOR_FREEZE = 1;
  static const int32_t TRANS_SYSTEM = 2;
  static const int32_t TRANS_USER = 3;
public:
  static bool is_valid(const int32_t type)
  { return TRANS_NORMAL == type || TRANS_MAJOR_FREEZE == type
           || TRANS_SYSTEM == type || TRANS_USER == type; }
private:
  ObTransType() {}
  ~ObTransType() {}
};

/*
 *  +--------------------- +-------------------------------------+---------------------------------+
 *  |                      |            CURRENT_READ             |    BOUNDED_STALENESS_READ       |
 *  +--------------------- +-------------------------------------+---------------------------------+
 *  | TRANSACTION_SNAPSHOT | 1. Isolation Level: SERIALIZABLE    | Not Support                     |
 *  |                      | 2. GTS                              |                                 |
 *  |--------------------- +-------------------------------------+---------------------------------+
 *  | STATEMENT_SNAPSHOT   | 1. Isolation Level: READ-COMMITTED  | 1. READ-COMMITTED               |
 *  |                      | 2. GTS                              | 2. monotonic version            |
 *  |                      |                                     | 3. Statement version            |
 *  |                      |                                     | 4. Specified version            |
 *  +--------------------- +-------------------------------------+---------------------------------+
 *  | PARTICIPANT_SNAPSHOT | 1. Isolation Level: READ-COMMITTED  | 1.  READ-COMMITTED              |
 *  |                      | 2. Participant Snaspthot Version    | 2.  Participant version         |
 *  |--------------------- +-------------------------------------+---------------------------------+
 */

class ObTransConsistencyType
{
public:
  static const int32_t UNKNOWN = -1;
  static const int32_t CURRENT_READ = 0;
  static const int32_t BOUNDED_STALENESS_READ = 1;
public:
  static bool is_valid(const int64_t consistency_type)
  { return CURRENT_READ == consistency_type || BOUNDED_STALENESS_READ == consistency_type; }
  static bool is_bounded_staleness_read(const int64_t consistency_type)
  {
    return BOUNDED_STALENESS_READ == consistency_type;
  }
  static bool is_current_read(const int64_t consistency_type)
  {
    return CURRENT_READ == consistency_type;
  }
  static const char *cstr(const int64_t consistency_type)
  {
    const char *str = "UNKNOWN";
    switch (consistency_type) {
      case UNKNOWN:
        str = "UNKNOWN";
        break;
      case CURRENT_READ:
        str = "CURRENT_READ";
        break;
      case BOUNDED_STALENESS_READ:
        str = "BOUNDED_STALENESS_READ";
        break;
      default:
        str = "INVALID";
        break;
    }
    return str;
  }
private:
  ObTransConsistencyType() {}
  ~ObTransConsistencyType() {}
};

class ObTransReadSnapshotType
{
public:
  static const int32_t UNKNOWN = -1;
  static const int32_t TRANSACTION_SNAPSHOT = 0;
  static const int32_t STATEMENT_SNAPSHOT = 1;
  static const int32_t PARTICIPANT_SNAPSHOT = 2;
public:
  static bool is_valid(const int32_t type)
  {
    return TRANSACTION_SNAPSHOT == type
        || STATEMENT_SNAPSHOT == type
        || PARTICIPANT_SNAPSHOT == type;
  }
  static bool is_consistent_snapshot(const int32_t type)
  {
    return TRANSACTION_SNAPSHOT == type || STATEMENT_SNAPSHOT == type;
  }
  static const char *cstr(const int64_t type)
  {
    const char *str = "UNKNOWN";
    switch (type) {
      case UNKNOWN:
        str = "UNKNOWN";
        break;
      case TRANSACTION_SNAPSHOT:
        str = "TRANSACTION_SNAPSHOT";
        break;
      case STATEMENT_SNAPSHOT:
        str = "STATEMENT_SNAPSHOT";
        break;
      case PARTICIPANT_SNAPSHOT:
        str = "PARTICIPANT_SNAPSHOT";
        break;
      default:
        str = "INVALID";
        break;
    }
    return str;
  }
};

// transaction parameter
class ObStartTransParam  // unreferenced, need remove
{
  OB_UNIS_VERSION(1);
public:
  ObStartTransParam() { reset(); }
  ~ObStartTransParam() { magic_ = INVALID_MAGIC_NUM; }
  void reset();
public:
  void set_expire_ts(const int64_t expired_ts)
  { expired_ts_ = expired_ts; }
  int64_t get_expire_ts() const { return expired_ts_; }
  int32_t get_access_mode() const { return access_mode_; }
  int32_t get_type() const { return type_; }
  int32_t get_isolation() const { return isolation_; }
  void set_autocommit(const bool autocommit) { autocommit_ = autocommit; }
  bool is_autocommit() const { return autocommit_; }
  void set_consistency_type(const int32_t consistency_type)
  { consistency_type_ = consistency_type; }
  int32_t get_consistency_type() const { return consistency_type_; }
  bool is_bounded_staleness_read() const
  { return ObTransConsistencyType::is_bounded_staleness_read(consistency_type_); }
  bool is_current_read() const
  { return ObTransConsistencyType::is_current_read(consistency_type_); }
  void set_read_snapshot_type(const int32_t type) { read_snapshot_type_ = type; }
  int32_t get_read_snapshot_type() const { return read_snapshot_type_; }
  void set_inner_trans(const bool is_inner_trans) { is_inner_trans_ = is_inner_trans; }
  bool is_inner_trans() const { return is_inner_trans_; }
  bool need_consistent_snapshot() const
  {
    return ObTransReadSnapshotType::is_consistent_snapshot(read_snapshot_type_);
  }
  bool need_strong_consistent_snapshot() const
  {
    return ObTransConsistencyType::CURRENT_READ == consistency_type_ && need_consistent_snapshot();
  }
  bool is_serializable_isolation() const;
public:
  bool is_readonly() const { return ObTransAccessMode::READ_ONLY == access_mode_; }

  int64_t to_string(char *buf, const int64_t buf_len) const;
private:
  static const uint64_t MAGIC_NUM = 0xF0F0F0F0F0F0F0F0;
  static const uint64_t INVALID_MAGIC_NUM = 0x4348454E4D494E47;
private:
  // READONLY or READ_WRITE
  int32_t access_mode_;
  // transaction type: TRANS_NORMAL
  int32_t type_;
  // isolation level: READ-COMMITTED
  int32_t isolation_;
  uint64_t magic_;
  bool autocommit_;
  int32_t consistency_type_;    // ObTransConsistencyType
  int32_t read_snapshot_type_;  // ObTransReadSnapshotType
  bool is_inner_trans_;
  int64_t expired_ts_;
};

//record the info from user to db
class ObTraceInfo
{
public:
  ObTraceInfo():
    app_trace_id_(sizeof(app_trace_id_buffer_), 0, app_trace_id_buffer_) { }
  ~ObTraceInfo() {}
  void reset();
  //app trace id
  int set_app_trace_id(const common::ObString &app_trace_id);
  const common::ObString &get_app_trace_id() const { return app_trace_id_; }
  common::ObString &get_app_trace_id() { return app_trace_id_; }
  TO_STRING_KV(K_(app_trace_id));
private:
  char app_trace_id_buffer_[common::OB_MAX_TRACE_ID_BUFFER_SIZE + 1];
  common::ObString app_trace_id_;
};

class ObTransConsistencyLevel
{
public:
  static const int64_t UNKNOWN = -1;
  static const int64_t STRONG = 0;
  static const int64_t WEAK = 1;
public:
  static bool is_valid(const int64_t type)
  { return STRONG == type || WEAK == type; }
private:
  ObTransConsistencyLevel() {}
  ~ObTransConsistencyLevel() {}
};

typedef common::ObReserveArenaAllocator<1024> ObTxReserveArenaAllocator;

class ObTransTraceLog : public common::ObTraceEventRecorder
{
public:
  ObTransTraceLog()
      : common::ObTraceEventRecorder::ObTraceEventRecorderBase(
          true, common::ObLatchIds::TRANS_TRACE_RECORDER_LOCK) {}
  ~ObTransTraceLog() {}
  void destroy() {}
  int64_t to_string(char *buf, const int64_t buf_len) const
  {
    int64_t ret = 0;
    check_lock();
    ret = ObTraceEventRecorder::to_string(buf, buf_len);
    check_unlock();
    return ret;
  }
};

class ObStmtInfo  // unreferenced, need remove
{
  OB_UNIS_VERSION(1);
public:
  ObStmtInfo() : nested_sql_(false), start_stmt_cnt_(0), end_stmt_cnt_(0) { }
  ~ObStmtInfo() {}
  void reset();
  int set_nested_sql() { nested_sql_ = true; return common::OB_SUCCESS; }
  bool is_nested_sql() const { return nested_sql_; }
  int inc_start_stmt_cnt() { start_stmt_cnt_++; return common::OB_SUCCESS; }
  int64_t get_start_stmt_cnt() const { return start_stmt_cnt_; }
  int inc_end_stmt_cnt() { end_stmt_cnt_++; return common::OB_SUCCESS; }
  int64_t get_end_stmt_cnt() const { return end_stmt_cnt_; }
  void reset_stmt_info();
  TO_STRING_KV(K_(nested_sql), K_(start_stmt_cnt), K_(end_stmt_cnt));
private:
  bool nested_sql_;
  int64_t start_stmt_cnt_;
  int64_t end_stmt_cnt_;
};

class ObTransNeedWaitWrap
{
public:
  ObTransNeedWaitWrap() { reset(); }
  ~ObTransNeedWaitWrap() { destroy(); }
  void reset()
  {
    receive_gts_ts_.reset();
    need_wait_interval_us_ = 0;
  }
  void destroy() { reset(); }
  int64_t get_remaining_wait_interval_us() const;
  void set_trans_need_wait_wrap(const MonotonicTs receive_gts_ts,
                                const int64_t need_wait_interval_us);
  MonotonicTs get_receive_gts_ts() const { return receive_gts_ts_; }
  int64_t get_need_wait_interval_us() const { return need_wait_interval_us_; }
  bool need_wait() const { return get_remaining_wait_interval_us() > 0; }
  TO_STRING_KV(K(receive_gts_ts_), K_(need_wait_interval_us));
private:
  MonotonicTs receive_gts_ts_;
  int64_t need_wait_interval_us_;
};

class ObTransSnapInfo //unused , to be removed
{
  OB_UNIS_VERSION(1);
public:
  ObTransSnapInfo() { reset(); }
  ~ObTransSnapInfo() { destroy(); }
  int64_t get_snapshot_version() const { return snapshot_version_; }
  void set_snapshot_version(const int64_t snapshot_version)
  {
    snapshot_version_ = snapshot_version;
  }
  void set_read_seq_no(const int64_t seq_no) { read_seq_no_ = sql_no_ = seq_no; }
  int64_t get_read_seq_no() const { return read_seq_no_; }
  void set_trans_id(const ObTransID &trans_id)
  {
    trans_id_ = trans_id;
  }
  const ObTransID &get_trans_id() const { return trans_id_; }
  void set_is_cursor_or_nested(const bool is_cursor_or_nested)
  {
    is_cursor_or_nested_ = is_cursor_or_nested;
  }
  bool is_cursor_or_nested() const { return is_cursor_or_nested_; }
  void reset()
  {
    snapshot_version_ = common::OB_INVALID_VERSION;
    read_seq_no_ = 0;
    sql_no_ = 0;
    trans_id_.reset();
    is_cursor_or_nested_ = false;
  }
  void destroy() { reset(); }
public:
  bool is_valid() const;
  TO_STRING_KV(K_(snapshot_version), K_(read_seq_no), K_(sql_no), K_(trans_id), K_(is_cursor_or_nested));
private:
  int64_t snapshot_version_;
  int64_t read_seq_no_;
  int64_t sql_no_; // deprecated, for compact reason only
  ObTransID trans_id_;
  bool is_cursor_or_nested_;
};

class ObStmtPair //unused , to be removed
{
  OB_UNIS_VERSION(1);
public:
  ObStmtPair() : from_(0), to_(0) {}
  ObStmtPair(const int64_t from, const int64_t to) : from_(from), to_(to) {}
  ~ObStmtPair() {}
  bool is_valid() const { return (from_ > to_) && (to_ >= 0); }
  int64_t get_from() const { return from_; }
  int64_t &get_from() { return from_; }
  int64_t get_to() const { return to_; }
  TO_STRING_KV(K_(from), K_(to));
private:
  int64_t from_;
  int64_t to_;
};

class ObStmtRollbackInfo //unused , to be removed
{
  OB_UNIS_VERSION(1);
public:
  ObStmtRollbackInfo() {}
  ~ObStmtRollbackInfo() {}
  void reset();
public:
  int push(const ObStmtPair &stmt_pair);
  int search(const int64_t sql_no, ObStmtPair &stmt_pair) const;
  int assign(const ObStmtRollbackInfo &other);
  TO_STRING_KV(K_(stmt_pair_array));
private:
  common::ObSArray<ObStmtPair> stmt_pair_array_;
};

class ObTransDesc;

class ObSQLTransAction
{
public:
  static const int64_t UNKNOWN = -1;
  static const int64_t START_TRANS = 0;
  static const int64_t END_TRANS = 1;
  static const int64_t MAX = 2;
public:
  static bool is_valid(const int64_t action)
  { return action >= START_TRANS && action <= END_TRANS; }
  static bool is_in_transaction(const int64_t action)
  { return action == START_TRANS; }
};

static const int64_t DEFAULT_BLOCKED_TRANS_ID_COUNT = 1;
typedef common::ObSEArray<ObTransID, DEFAULT_BLOCKED_TRANS_ID_COUNT> ObBlockedTransArray;

class ObTransDesc
{
  OB_UNIS_VERSION(1);
public:
  void reset() {}
  void destroy() {}
  bool is_valid() const { return false; }
  TO_STRING_KV("hello", "world");
  int a_;
};

struct ObTransExecResult {};

class ObPartTransAction
{
public:
  static const int64_t UNKNOWN = -1;
  static const int64_t INIT = 1;
  static const int64_t START = 2;
  static const int64_t COMMIT = 3;
  static const int64_t ABORT = 4;
  static const int64_t DIED = 5;
  static const int64_t END = 6;
public:
  static bool is_valid(const int64_t state)
  { return state >= START && state < END; }
private:
  ObPartTransAction() {}
  ~ObPartTransAction() {}
};

class ObRunningState
{
public:
  static const int64_t UNKNOWN = -1;
  static const int64_t INIT = 0;
  static const int64_t ABORT = 200;
public:
  static bool is_valid(const int64_t state)
  { return INIT == state || ABORT == state; }
private:
  ObRunningState() {}
  ~ObRunningState() {}
};

// runtime state is volatile state of tx ctx
class ObTxRuntimeState
{
public:
  ObTxRuntimeState() : flag_() {}
  ~ObTxRuntimeState() {}
  void reset() { flag_.reset(); }

  bool is_info_log_submitted() const { return flag_.info_log_submitted_; }
  void set_info_log_submitted() { flag_.info_log_submitted_ = 1; }
  void clear_info_log_submitted() { flag_.info_log_submitted_ = 0; }

  bool is_state_log_submitting() const { return flag_.state_log_submitting_; }
  void set_state_log_submitting() { flag_.state_log_submitting_ = 1; }
  void clear_state_log_submitting() { flag_.state_log_submitting_ = 0; }

  bool is_state_log_submitted() const { return flag_.state_log_submitted_; }
  void set_state_log_submitted() { flag_.state_log_submitted_ = 1; }
  void clear_state_log_submitted() { flag_.state_log_submitted_ = 0; }

  bool is_force_abort() const { return flag_.force_abort_; }
  void set_force_abort() { flag_.force_abort_ = 1; }
  void clear_force_abort() { flag_.force_abort_ = 0; }

  bool is_gts_waiting() const { return flag_.gts_waiting_; }
  void set_gts_waiting() { flag_.gts_waiting_ = 1; }
  void clear_gts_waiting() { flag_.gts_waiting_ = 0; }

  DECLARE_ON_DEMAND_TO_STRING
  TO_STRING_KV("info_log_submitted",
               flag_.info_log_submitted_,
               "state_log_submitting",
               flag_.state_log_submitting_,
               "state_log_submitted",
               flag_.state_log_submitted_,
               "force_abort",
               flag_.force_abort_,
               "gts_waiting",
               flag_.gts_waiting_);

  bool is_valid() const { return flag_.is_valid(); }
private:
  struct BitFlag
  {
    unsigned int info_log_submitted_ : 1;
    unsigned int state_log_submitting_ : 1;
    unsigned int state_log_submitted_ : 1;
    unsigned int force_abort_ : 1;
    unsigned int gts_waiting_ : 1;

    void reset()
    {
      info_log_submitted_ = 0;
      state_log_submitting_ = 0;
      state_log_submitted_ = 0;
      force_abort_ = 0;
      gts_waiting_ = 0;
    }

    bool is_valid() const
    {
      return info_log_submitted_ > 0 || state_log_submitted_ > 0
          || state_log_submitting_ > 0 || force_abort_ > 0 || gts_waiting_ > 0;
    }

    BitFlag() { reset(); }
  } flag_;
};

class ObTransSubmitLogState
{
public:
  static const int64_t INIT = 0;
  static const int64_t SUBMIT_LOG = 1;
  static const int64_t SUBMIT_LOG_PENDING = 2;
  static const int64_t SUBMIT_LOG_SUCCESS = 3;
public:
  bool is_valid(const int64_t state)
  { return INIT == state || SUBMIT_LOG == state
      || SUBMIT_LOG_PENDING == state || SUBMIT_LOG_SUCCESS == state; }
};

class ObTransRetryTaskType
{
public:
  static const int64_t UNKNOWN = -1;
  static const int64_t END_TRANS_CB_TASK = 0;
  static const int64_t MAX = 1;
public:
  static bool is_valid(const int64_t task_type)
  { return END_TRANS_CB_TASK == task_type; }
};

class ObMemtableKeyInfo
{
public:
  ObMemtableKeyInfo() { reset(); };
  ~ObMemtableKeyInfo() {};
  int init(const uint64_t hash_val);
  void reset();
  char *get_buf() { return buf_; }
  const char *read_buf() const { return buf_; }
  common::ObTabletID get_tablet_id() const { return tablet_id_; }
  uint64_t get_hash_val() const { return hash_val_; }
  const void *get_row_lock() const { return row_lock_; }
  void set_row_lock(void *row_lock) { row_lock_ = row_lock; }
  void set_tablet_id(const common::ObTabletID &tablet_id) { tablet_id_ = tablet_id; }

  TO_STRING_KV(K_(buf));

public:
  static const int MEMTABLE_KEY_INFO_BUF_SIZE = 128;

private:
  ObTabletID tablet_id_;
  uint64_t hash_val_;
  void *row_lock_;
  char buf_[MEMTABLE_KEY_INFO_BUF_SIZE];
};

class ObElrTransInfo final
{
  OB_UNIS_VERSION(1);
public:
  ObElrTransInfo() { reset(); }
  void reset();
  const ObTransID &get_trans_id() const { return trans_id_; }
  uint32_t get_ctx_id() const { return ctx_id_; }
  share::SCN get_commit_version() const { return commit_version_; }
  int set_result(const int result) { result_ = result; return common::OB_SUCCESS; }
  uint64_t hash() const { return trans_id_.hash(); }
  int get_result() const { return ATOMIC_LOAD(&result_); }
  bool cas_result(int o, int n) { return ATOMIC_BCAS(&result_, o, n); }
  TO_STRING_KV(K_(trans_id), K_(commit_version), K_(result), K_(ctx_id));
private:
  ObTransID trans_id_;
  share::SCN commit_version_;
  int result_;
  uint32_t ctx_id_;
};

class ObTransResultState
{
public:
  static const int INVALID = -1;
  static const int UNKNOWN = 0;
  static const int COMMIT = 1;
  static const int ABORT = 2;
  static const int MAX = 3;
public:
  static bool is_valid(const int state)
  { return state > INVALID && state < MAX; }
  static bool is_unknown(const int state)
  { return UNKNOWN == state; }
  static bool is_commit(const int state)
  { return COMMIT == state; }
  static bool is_abort(const int state)
  { return ABORT == state; }
  static bool is_decided_state(const int state)
  { return COMMIT == state || ABORT == state; }
};

class ObTransTask : public common::LinkTask
{
public:
  ObTransTask() : retry_interval_us_(0), next_handle_ts_(0), task_type_(ObTransRetryTaskType::UNKNOWN) {}
  ObTransTask(int64_t task_type) : retry_interval_us_(0), next_handle_ts_(0), task_type_(task_type) {}
  virtual ~ObTransTask() { destroy(); }
  void reset();
  void destroy() { reset(); }
  int make(const int64_t task_type);
  int64_t get_task_type() const { return task_type_; }
  bool ready_to_handle();
  TO_STRING_KV(K_(task_type), K_(retry_interval_us), K_(next_handle_ts));
public:
  static const int64_t RP_TOTAL_NUM = 512;
  static const int64_t RP_RESERVE_NUM = 64;
  static const int64_t RETRY_SLEEP_TIME_US = 100;
protected:
  int64_t retry_interval_us_;
  int64_t next_handle_ts_;
  int64_t task_type_;
};

enum ObPartitionAuditOperator
{
  PART_AUDIT_SET_BASE_ROW_COUNT = 0,
  PART_AUDIT_INSERT_ROW,
  PART_AUDIT_DELETE_ROW,
  PART_AUDIT_UPDATE_ROW, // put included
  PART_AUDIT_QUERY_ROW,
  PART_AUDIT_INSERT_SQL,
  PART_AUDIT_DELETE_SQL,
  PART_AUDIT_UPDATE_SQL,
  PART_AUDIT_QUERY_SQL,
  PART_AUDIT_TRANS,
  PART_AUDIT_SQL,
  PART_AUDIT_ROLLBACK_INSERT_ROW,
  PART_AUDIT_ROLLBACK_DELETE_ROW,
  PART_AUDIT_ROLLBACK_UPDATE_ROW,
  PART_AUDIT_ROLLBACK_INSERT_SQL,
  PART_AUDIT_ROLLBACK_DELETE_SQL,
  PART_AUDIT_ROLLBACK_UPDATE_SQL,
  PART_AUDIT_ROLLBACK_TRANS,
  PART_AUDIT_ROLLBACK_SQL,
  PART_AUDIT_OP_MAX
};

struct ObPartitionAuditInfoCache
{
public:
  ObPartitionAuditInfoCache(){ reset(); }
  ~ObPartitionAuditInfoCache(){}
  void reset() {
    insert_row_count_ = 0;
    delete_row_count_ = 0;
    update_row_count_ = 0;
    cur_insert_row_count_ = 0;
    cur_delete_row_count_ = 0;
    cur_update_row_count_ = 0;
    query_row_count_ = 0;
    insert_sql_count_ = 0;
    delete_sql_count_ = 0;
    update_sql_count_ = 0;
    query_sql_count_ = 0;
    sql_count_ = 0;
    rollback_insert_row_count_ = 0;
    rollback_delete_row_count_ = 0;
    rollback_update_row_count_ = 0;
    rollback_insert_sql_count_ = 0;
    rollback_delete_sql_count_ = 0;
    rollback_update_sql_count_ = 0;
    rollback_sql_count_ = 0;
  }
public:
  int32_t insert_row_count_;
  int32_t delete_row_count_;
  int32_t update_row_count_;
  int32_t cur_insert_row_count_;
  int32_t cur_delete_row_count_;
  int32_t cur_update_row_count_;
  int32_t query_row_count_;
  int32_t insert_sql_count_;
  int32_t delete_sql_count_;
  int32_t update_sql_count_;
  int32_t query_sql_count_;
  int32_t sql_count_;
  int32_t rollback_insert_row_count_;
  int32_t rollback_delete_row_count_;
  int32_t rollback_update_row_count_;
  int32_t rollback_insert_sql_count_;
  int32_t rollback_delete_sql_count_;
  int32_t rollback_update_sql_count_;
  int32_t rollback_sql_count_;
};

struct ObPartitionAuditInfo
{
public:
  ObPartitionAuditInfo() : lock_(common::ObLatchIds::PARTITION_AUDIT_SPIN_LOCK) { reset(); }
  ~ObPartitionAuditInfo(){}
  void reset() {
    base_row_count_ = 0;
    insert_row_count_ = 0;
    delete_row_count_ = 0;
    update_row_count_ = 0;
    query_row_count_ = 0;
    insert_sql_count_ = 0;
    delete_sql_count_ = 0;
    update_sql_count_ = 0;
    query_sql_count_ = 0;
    trans_count_ = 0;
    sql_count_ = 0;
    rollback_insert_row_count_ = 0;
    rollback_delete_row_count_ = 0;
    rollback_update_row_count_ = 0;
    rollback_insert_sql_count_ = 0;
    rollback_delete_sql_count_ = 0;
    rollback_update_sql_count_ = 0;
    rollback_trans_count_ = 0;
    rollback_sql_count_ = 0;
  }
  void destroy() { reset(); }
  void set_base_row_count(int64_t count) { ATOMIC_SET(&base_row_count_, count); }
public:
  common::ObSpinLock lock_;
  int64_t base_row_count_;
  int64_t insert_row_count_;
  int64_t delete_row_count_;
  int64_t update_row_count_;
  int64_t query_row_count_;
  int64_t insert_sql_count_;
  int64_t delete_sql_count_;
  int64_t update_sql_count_;
  int64_t query_sql_count_;
  int64_t trans_count_;
  int64_t sql_count_;
  int64_t rollback_insert_row_count_;
  int64_t rollback_delete_row_count_;
  int64_t rollback_update_row_count_;
  int64_t rollback_insert_sql_count_;
  int64_t rollback_delete_sql_count_;
  int64_t rollback_update_sql_count_;
  int64_t rollback_trans_count_;
  int64_t rollback_sql_count_;
};

class ObCoreLocalPartitionAuditInfo : public common::ObCoreLocalStorage<ObPartitionAuditInfo*>
{
public:
  ObCoreLocalPartitionAuditInfo() {}
  ~ObCoreLocalPartitionAuditInfo() { destroy(); }
  void reset();
  void destroy() { reset(); }
};

class ObAddrLogId
{
public:
  ObAddrLogId(const common::ObAddr &addr, const uint64_t log_id)
    : addr_(addr), log_id_(log_id) {}
  ObAddrLogId() { reset(); }
  ~ObAddrLogId() { destroy(); }
  void reset();
  void destroy() { reset(); }
  const common::ObAddr &get_addr() const { return addr_; }
  uint64_t get_log_id() const { return log_id_; }
  TO_STRING_KV(K_(addr), K_(log_id));

private:
  common::ObAddr addr_;
  uint64_t log_id_;
};

enum class ObTransTableStatusType:int64_t
{
  RUNNING = 0,
  COMMIT,
  ABORT
};

/*
 * Undo range : (to, from]
 */
class ObUndoAction
{
  OB_UNIS_VERSION(1);
public:
  ObUndoAction() { reset(); }
  ObUndoAction(const ObTxSEQ undo_from, const ObTxSEQ undo_to)
      : undo_from_(undo_from), undo_to_(undo_to) {}
  ~ObUndoAction() { destroy(); }
  void reset()
  {
    undo_from_.reset();
    undo_to_.reset();
  }
  void destroy() { reset(); }
  bool is_valid() const
  {
    return (undo_from_.is_valid()
            && undo_to_.is_valid()
            && undo_from_.get_branch() == undo_to_.get_branch()
            && undo_from_ > undo_to_);
  }

  bool is_contain(const ObTxSEQ seq_no) const
  {
    const bool can_cmp = undo_to_.get_branch() == 0
      || undo_to_.get_branch() == seq_no.get_branch();
    return can_cmp
      && seq_no.get_seq() > undo_to_.get_seq()
      && seq_no.get_seq() <= undo_from_.get_seq();
  }

  bool is_contain(const ObUndoAction &other) const
  {
    const bool can_cmp = undo_to_.get_branch() == 0
      || undo_to_.get_branch() == other.undo_to_.get_branch();
    return can_cmp &&
      undo_from_.get_seq() >= other.undo_from_.get_seq()
      && undo_to_.get_seq() <= other.undo_to_.get_seq();
  }
  TO_STRING_KV(K_(undo_from), K_(undo_to));
public:
  // from > to
  ObTxSEQ undo_from_; // inclusive
  ObTxSEQ undo_to_;   // exclusive
};

typedef common::ObSEArray<ObElrTransInfo, 1, TransModulePageAllocator> ObElrTransInfoArray;
typedef common::ObSEArray<int64_t, 10, TransModulePageAllocator> ObRedoLogIdArray;
typedef common::ObSEArray<palf::LSN, 10, ModulePageAllocator> ObRedoLSNArray;

struct CtxInfo final
{
  CtxInfo() : ctx_(NULL) {}
  CtxInfo(ObTransCtx *ctx) : ctx_(ctx) {}
  TO_STRING_KV(KP(ctx_));
  ObTransCtx *ctx_;
};

typedef common::ObSEArray<ObMemtableKeyInfo, 16, TransModulePageAllocator> ObMemtableKeyArray;
typedef common::ObSEArray<ObAddrLogId, 10, TransModulePageAllocator> ObAddrLogIdArray;
const int64_t OB_TRANS_REDO_LOG_RESERVE_SIZE = 128 * 1024;
const int64_t MAX_ONE_PC_TRANS_SIZE = 1500000;
// parmeters config transaction related
const int64_t TRANS_ACCESS_STAT_INTERVAL = 60 * 1000 * 1000; // 60s
const int64_t TRANS_MEM_STAT_INTERVAL = 5 * 1000 * 1000;  // 60s

// in elr transaction, curr_trans_commit_version - prev_trans_commit_version <= 400ms;
#ifdef ERRSIM
static const int64_t MAX_ELR_TRANS_INTERVAL = 20 * 1000 * 1000;
#else
static const int64_t MAX_ELR_TRANS_INTERVAL = 400 * 1000;
#endif

// max scheudler context in single server
static const int64_t MAX_TX_CTX_COUNT = 700 * 1000;

#define TRANS_AGGRE_LOG_TIMESTAMP OB_INVALID_TIMESTAMP



enum class TxCtxSource
{
  UNKNOWN = 0,
  MVCC_WRITE = 1,
  REGISTER_MDS = 2,
  REPLAY = 3,
  RECOVER = 4,
};

static const char * to_str_ctx_source(const TxCtxSource & ctx_src)
{
  const char * str = "INVALID";
  switch(ctx_src)
  {
    TRX_ENUM_CASE_TO_STR(TxCtxSource, UNKNOWN);
    TRX_ENUM_CASE_TO_STR(TxCtxSource, MVCC_WRITE);
    TRX_ENUM_CASE_TO_STR(TxCtxSource, REGISTER_MDS);
    TRX_ENUM_CASE_TO_STR(TxCtxSource, REPLAY);
    TRX_ENUM_CASE_TO_STR(TxCtxSource, RECOVER);
  }
  return str;
}


class ObTxMDSCache;

static const int64_t MAX_TABLET_MODIFY_RECORD_COUNT = 16;
// exec info need to be persisted by "trans context table"
struct ObTxExecInfo
{
  OB_UNIS_VERSION(2);
public:
  ObTxExecInfo() {}
  explicit ObTxExecInfo(TransModulePageAllocator &allocator)
    : redo_lsns_(OB_MALLOC_NORMAL_BLOCK_SIZE, ModulePageAllocator(allocator, "REDO_LSNS")),
      multi_data_source_(OB_MALLOC_NORMAL_BLOCK_SIZE, ModulePageAllocator(allocator, "MDS_ARRAY")),
      checksum_(OB_MALLOC_NORMAL_BLOCK_SIZE, ModulePageAllocator(allocator, "TX_CHECKSUM")),
      checksum_scn_(OB_MALLOC_NORMAL_BLOCK_SIZE, ModulePageAllocator(allocator, "TX_CHECKSUM"))
  {
    checksum_.push_back(0);
    checksum_scn_.push_back(share::SCN());
  }
public:
  int generate_mds_buffer_ctx_array();
  int merge_buffer_ctx_array_to_multi_data_source() const;
  void clear_buffer_ctx_in_multi_data_source();
  void reset();
  // can not destroy in tx_ctx_table
  void destroy(ObTxMDSCache &mds_cache);
  int assign(const ObTxExecInfo &exec_info);
  bool has_write_state() const { return has_write_state_; }
  void mark_write_state() { has_write_state_ = true; }

private:
  ObTxExecInfo &operator=(const ObTxExecInfo &info);

public:
  DECLARE_ON_DEMAND_TO_STRING

  DECLARE_TO_STRING {
//    const_cast<ObIArray<uint64_t>>(checksum_).set_max_print_count(512);
//    const_cast<ObIArray<share::SCN>>(checksum_scn_).set_max_print_count(512);
    int64_t pos = 0;
    J_KV(K_(state),
               K_(has_write_state),
               K_(prev_record_lsn),
               K_(redo_lsns),
               "redo_log_no", redo_lsns_.count(),
               K_(multi_data_source),
               K_(prepare_version),
               K_(next_log_entry_no),
               K_(max_applied_log_ts),
               K_(max_applying_log_ts),
               K_(max_applying_part_log_no),
               K_(max_submitted_seq_no),
               K_(checksum),
               K_(checksum_scn),
               K_(max_durable_lsn),
               K_(data_complete),
               //K_(touched_pkeys),
               K_(need_checksum),
               K_(serial_final_scn),
               K_(serial_final_seq_no));
    return pos;
  }
  ObTxState state_;
  bool has_write_state_;
  LogOffSet prev_record_lsn_;
  ObRedoLSNArray redo_lsns_;
  ObTxBufferNodeArray multi_data_source_;
  ObTxBufferCtxArray mds_buffer_ctx_array_;
  share::SCN prepare_version_;
  int64_t next_log_entry_no_;
  share::SCN max_applied_log_ts_;
  share::SCN max_applying_log_ts_;
  int64_t max_applying_part_log_no_;
  ObTxSEQ max_submitted_seq_no_;
  ObSEArray<uint64_t,1> checksum_;
  ObSEArray<share::SCN,1> checksum_scn_;
  palf::LSN max_durable_lsn_;
  bool data_complete_;
  bool need_checksum_;
  // since this scn
  share::SCN serial_final_scn_;
  // the logic time of serial final log submitted
  // used to decide whether a branch level savepoint rollback log
  // need set pre-barrier to wait previous redo replayed
  ObTxSEQ serial_final_seq_no_;
};

// Undefine macOS system macro to avoid conflict
#ifdef USEC_PER_SEC
#undef USEC_PER_SEC
#endif
static const int64_t USEC_PER_SEC = 1000 * 1000;

struct ObMulSourceDataNotifyArg
{
  ObTransID tx_id_;
  share::SCN scn_; // the log ts of current notify type
  // in case of abort transaction, trans_version_ is invalid
  share::SCN trans_version_;
  NotifyType notify_type_;
  bool for_replay_;
  bool redo_submitted_;
  bool redo_synced_;
  bool willing_to_commit_;
  // force kill trans without abort scn
  bool is_force_kill_;
  bool is_incomplete_replay_;

  ObMulSourceDataNotifyArg() { reset(); }
  void reset();

  TO_STRING_KV(K_(tx_id),
               K_(scn),
               K_(trans_version),
               K_(for_replay),
               K_(notify_type),
               K_(redo_submitted),
               K_(redo_synced),
               K_(is_incomplete_replay),
               K_(willing_to_commit),
               K_(is_force_kill));

  // The redo log of current buf_node has been submitted;
  // The redo log of current buf_node has been confirmed by the majority but possibly not yet
  // callbacked by ON_REDO;
  // The redo log of current buf_node has been callbacked by ON_REDO;
};

enum class TxEndAction : int8_t
{
  COMMIT_TX,
  ABORT_TX,
  DELAY_ABORT_TX,
  KILL_TX_FORCEDLY
};

inline bool IS_CORNER_IMPL(const char *func, const int64_t line, const int64_t ppm)
{
  int ret = common::OB_SUCCESS;
  bool bool_ret = false;
#ifdef ENABLE_DEBUG_LOG
  bool_ret = (ObRandom::rand(0, 999999) < ppm);
  TRANS_LOG(WARN, "IS_CORNER", K(func), K(line));
#endif
  UNUSED(ret);
  return bool_ret;
}

#define IS_CORNER(ppm) IS_CORNER_IMPL(__FUNCTION__, __LINE__, ppm)

inline bool is_effective_trans_version(const share::SCN trans_version)
{
  return trans_version.is_valid()
    && !trans_version.is_min()
    && !trans_version.is_max();
}

inline bool is_effective_trans_version(const int64_t trans_version)
{
  return -1 != trans_version
    && 0 != trans_version
    && INT64_MAX != trans_version;
}

template<typename T>
struct ObIArraySerDeTrait {
  ObIArray<T> &arr_;
  ObIArraySerDeTrait(ObIArray<T> &arr): arr_(arr) {}
  int64_t get_serialize_size() const
  {
    int64_t size = 0;
    size += serialization::encoded_length_vi64(arr_.count());
    for (int64_t i = 0; i < arr_.count(); i ++) {
      size += serialization::encoded_length(arr_.at(i));
    }
    return size;
  }
  int serialize(char *buf, const int64_t buf_len, int64_t &pos) const
  {
    int ret = OB_SUCCESS;
    int i = -1;
    if (OB_SUCC(serialization::encode_vi64(buf, buf_len, pos, arr_.count()))) {
      for (i = 0; i < arr_.count() && OB_SUCC(ret); i ++) {
        ret = serialization::encode(buf, buf_len, pos, arr_.at(i));
      }
    }
    if (OB_FAIL(ret)) {
    }
    return ret;
  }
  int deserialize(const char *buf, int64_t data_len, int64_t &pos)
  {
    int ret = OB_SUCCESS;
    arr_.reuse();
    bool need_push_back = true;
    int64_t count = 0;
    if (OB_FAIL(serialization::decode_vi64(buf, data_len, pos, &count))) {
    } else if (OB_FAIL(arr_.prepare_allocate(count))) {
      if (OB_NOT_SUPPORTED == ret) {
        ret = arr_.reserve(count);
      }
      if (OB_FAIL(ret)) {
      }
    } else { need_push_back = false; }
    for (int i = 0; i < count && OB_SUCC(ret); i++) {
      if (need_push_back) {
        T it;
        if (OB_FAIL(serialization::decode(buf, data_len, pos, it))) {
        } else if (OB_FAIL(arr_.push_back(it))) {
        }
      } else if (OB_FAIL(serialization::decode(buf, data_len, pos, arr_.at(i)))) {
      }
    }
    return ret;
  }
};

} // transaction
} // oceanbase

#include "ob_trans_define_v4.h"

#endif // OCEANBASE_TRANSACTION_OB_TRANS_DEFINE_
