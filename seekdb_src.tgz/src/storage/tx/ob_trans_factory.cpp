/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#include "ob_trans_factory.h"
#include "lib/objectpool/ob_server_object_pool.h"
#include "share/rc/ob_server_runtime.h"
#include "share/ob_server_struct.h"
#include "ob_tx_ctx.h"

namespace oceanbase
{

using namespace common;

namespace transaction
{
int64_t ObTxCtxFactory::active_tx_ctx_count_ CACHE_ALIGNED = 0;
int64_t ObTxCtxFactory::total_release_tx_ctx_count_ CACHE_ALIGNED = 0;
const char *ObTxCtxFactory::mod_type_ = "OB_TX_CTX";

int64_t ObLSTxCtxMgrFactory::alloc_count_ = 0;
int64_t ObLSTxCtxMgrFactory::release_count_ = 0;
const char *ObLSTxCtxMgrFactory::mod_type_ = "OB_PARTITION_TRANS_CTX_MGR";


//static TransObjFactory<TransRpcTask> trans_rpc_task_factory("OB_TRANS_RPC_TASK");

#define RP_FREE(object, LABEL) rp_free(object, LABEL)
#define RP_ALLOC(object, LABEL) rp_alloc(object, LABEL)

#define MAKE_FACTORY_CLASS_IMPLEMENT(object_name, LABEL, allocator_type, arg...)  \
  int64_t object_name##Factory::alloc_count_ = 0; \
  int64_t object_name##Factory::release_count_ = 0; \
  const char *object_name##Factory::mod_type_ = #LABEL; \
  object_name *object_name##Factory::alloc(arg)  \
  {  \
    object_name *object = NULL;    \
    if (REACH_TIME_INTERVAL(TRANS_MEM_STAT_INTERVAL)) {  \
      TRANS_LOG(INFO, "trans factory statistics",  \
                "object_name", #object_name,       \
                "label", #LABEL,                   \
                K_(alloc_count), K_(release_count), "used", alloc_count_ - release_count_);  \
    }  \
    if (NULL != (object = allocator_type##_ALLOC(object_name, LABEL))) { \
      (void)ATOMIC_FAA(&alloc_count_, 1);  \
    }  \
    return object;  \
  }                                             \
  void object_name##Factory::release(object_name *object)  \
  {\
    if (OB_ISNULL(object)) {\
      TRANS_LOG_RET(WARN, OB_ERR_UNEXPECTED, "object is null", KP(object));\
    } else {\
      object->destroy();  \
      allocator_type##_FREE(object, LABEL);        \
      object = NULL;\
      (void)ATOMIC_FAA(&release_count_, 1);\
    }\
  }\
  int64_t object_name##Factory::get_alloc_count()  \
  {  \
    return alloc_count_;  \
  }  \
  int64_t object_name##Factory::get_release_count()\
  {\
    return release_count_;\
  }\
  const char *object_name##Factory::get_mod_type()\
  {\
    return mod_type_;\
  }\

#define MAKE_FACTORY_CLASS_IMPLEMENT_USE_RP_ALLOC(object_name, LABEL, arg...) MAKE_FACTORY_CLASS_IMPLEMENT(object_name, LABEL, RP, arg)

ObTxCtx *ObTxCtxFactory::alloc()
{
  int tmp_ret = OB_SUCCESS;
  ObTxCtx *ctx = NULL;

  // During restart, the number of transaction contexts is relatively large
  // and cannot be limited, otherwise there will be circular dependencies.
  if (ATOMIC_LOAD(&active_tx_ctx_count_) > MAX_TX_CTX_COUNT && GCTX.status_ == ObServiceStatus::SS_SERVING) {
    TRANS_LOG_RET(ERROR, tmp_ret, "transaction context memory alloc failed", K_(active_tx_ctx_count));
    tmp_ret = OB_TRANS_CTX_COUNT_REACH_LIMIT;
  } else if (NULL != (ctx = sop_borrow(ObTxCtx))) {
    (void)ATOMIC_FAA(&active_tx_ctx_count_, 1);
  } else {
    // do nothing
  }
  if (REACH_TIME_INTERVAL(TRANS_MEM_STAT_INTERVAL)) {
    TRANS_LOG(INFO, "ObTxCtx statistics", K_(active_tx_ctx_count), K_(total_release_tx_ctx_count));
    (void)ATOMIC_STORE(&total_release_tx_ctx_count_, 0);
  }

  (void) tmp_ret; // make compiler happy
  return ctx;
}

void ObTxCtxFactory::release(ObTransCtx *ctx)
{
  if (OB_ISNULL(ctx)) {
    TRANS_LOG_RET(ERROR, OB_ERR_UNEXPECTED, "context pointer is null when released", KP(ctx));
  } else {
    ObTxCtx *tx_ctx = static_cast<ObTxCtx *>(ctx);
    tx_ctx->destroy();
    sop_return(ObTxCtx, tx_ctx);
    (void)ATOMIC_FAA(&active_tx_ctx_count_, -1);
    (void)ATOMIC_FAA(&total_release_tx_ctx_count_, 1);
    ctx = NULL;
  }
}

//ObLSTxCtxMgrFactory
ObLSTxCtxMgr *ObLSTxCtxMgrFactory::alloc()
{
  void *ptr = NULL;
  ObLSTxCtxMgr *partition_trans_ctx_mgr = NULL;
  ObMemAttr memattr(ObModIds::OB_PARTITION_TRANS_CTX_MGR, ObCtxIds::TRANS_CTX_MGR_ID);
  if (REACH_TIME_INTERVAL(TRANS_MEM_STAT_INTERVAL)) {
    TRANS_LOG(INFO, "ObLSTxCtxMgr statistics",
      K_(alloc_count), K_(release_count), "used", alloc_count_ - release_count_);
  }
  if (NULL != (ptr = ob_malloc(sizeof(ObLSTxCtxMgr), memattr))) {
    partition_trans_ctx_mgr = new(ptr) ObLSTxCtxMgr;
    (void)ATOMIC_FAA(&alloc_count_, 1);
  }
  TRANS_LOG(INFO, "alloc ls tx ctx mgr", KP(partition_trans_ctx_mgr));
  return partition_trans_ctx_mgr;
}

void ObLSTxCtxMgrFactory::release(ObLSTxCtxMgr *partition_trans_ctx_mgr)
{
  if (OB_ISNULL(partition_trans_ctx_mgr)) {
    TRANS_LOG_RET(ERROR, OB_ERR_UNEXPECTED, "ObLSTxCtxMgr pointer is null when released",
      KP(partition_trans_ctx_mgr));
  } else {
    partition_trans_ctx_mgr->~ObLSTxCtxMgr();
    ob_free(partition_trans_ctx_mgr);
    TRANS_LOG(INFO, "release ls tx ctx mgr", KP(partition_trans_ctx_mgr));
    partition_trans_ctx_mgr = NULL;
    (void)ATOMIC_FAA(&release_count_, 1);
  }
}

int64_t ObLSTxCtxMgrFactory::get_alloc_count()
{
  return alloc_count_;
}

int64_t ObLSTxCtxMgrFactory::get_release_count()
{
  return release_count_;
}

const char *ObLSTxCtxMgrFactory::get_mod_type()
{
  return mod_type_;
}

/*
//TransRpcTaskFactory
TransRpcTask *TransRpcTaskFactory::alloc()
{
  return trans_rpc_task_factory.alloc();
}

void TransRpcTaskFactory::release(TransRpcTask *task)
{
  if (OB_ISNULL(task)) {
    // ignore ret
    TRANS_LOG(ERROR, "TransRpcTask pointer is null when released", KP(task));
  } else {
    trans_rpc_task_factory.release(task);
    task = NULL;
  }
}

int64_t TransRpcTaskFactory::get_alloc_count()
{
  return trans_rpc_task_factory.get_alloc_count();
}

int64_t TransRpcTaskFactory::get_release_count()
{
  return trans_rpc_task_factory.get_release_count();
}

const char *TransRpcTaskFactory::get_mod_type()
{
  return trans_rpc_task_factory.get_mod_type();
}
*/

MAKE_FACTORY_CLASS_IMPLEMENT_USE_RP_ALLOC(ClogBuf, ObModIds::OB_TRANS_CLOG_BUF)
MAKE_FACTORY_CLASS_IMPLEMENT_USE_RP_ALLOC(MutatorBuf, ObModIds::OB_TRANS_MUTATOR_BUF)
MAKE_FACTORY_CLASS_IMPLEMENT_USE_RP_ALLOC(ObTransTraceLog, ObModIds::OB_TRANS_AUDIT_RECORD)
MAKE_FACTORY_CLASS_IMPLEMENT_USE_RP_ALLOC(ObPartitionAuditInfo, ObModIds::OB_PARTITION_AUDIT_INFO)
MAKE_FACTORY_CLASS_IMPLEMENT_USE_RP_ALLOC(ObCoreLocalPartitionAuditInfo, ObModIds::OB_CORE_LOCAL_STORAGE)
MAKE_FACTORY_CLASS_IMPLEMENT_USE_RP_ALLOC(ObTxCommitCallbackTask, ObModIds::OB_END_TRANS_CB_TASK)

void *MultiTxDataFactory::alloc(const int64_t len)
{
  return server_malloc(len, "MultiTxData");
}

void MultiTxDataFactory::free(void *ptr)
{
  if (NULL != ptr) {
    server_free(ptr);
  }
}

} // transaction
} // oceanbase
