/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "storage/tx/ob_tx_ctx.h"

namespace oceanbase
{

namespace transaction
{

IMPL_ON_DEMAND_PRINT_FUNC(ObTxRuntimeState)
{
  int ret = OB_SUCCESS;
  int tmp_pos = 0;

  // if (flag_.is_valid()) {
    ON_DEMAND_START_PRINT(RuntimeState);

    TX_KV_PRINT_WITH_ERR(flag_.info_log_submitted_ > 0, info_log_submitted,
                         flag_.info_log_submitted_, " ");
    TX_KV_PRINT_WITH_ERR(flag_.state_log_submitting_ > 0, state_log_submitting,
                         flag_.state_log_submitting_, " ");
    TX_KV_PRINT_WITH_ERR(flag_.state_log_submitted_ > 0, state_log_submitted,
                         flag_.state_log_submitted_, " ");
    TX_KV_PRINT_WITH_ERR(flag_.force_abort_ > 0, force_abort, flag_.force_abort_, " ");

    ON_DEMAND_END_PRINT(RuntimeState);
  // }
  return ret;
}

IMPL_ON_DEMAND_PRINT_FUNC(ObTxExecInfo)
{
  int ret = OB_SUCCESS;
  int tmp_pos = 0;

  ON_DEMAND_START_PRINT(ExecInfo);

  TX_KV_PRINT_WITH_ERR(true, downstream_state, to_str_tx_state(state_), ", ");
  TX_KV_PRINT_WITH_ERR(true, has_write_state, has_write_state_, ", ");
  TX_KV_PRINT_WITH_ERR(true, redo_log_no, redo_lsns_.count(), ", ");
  TX_KV_PRINT_WITH_ERR(true, prepare_version, prepare_version_, ", ");
  TX_KV_PRINT_WITH_ERR(true, next_log_entry_no, next_log_entry_no_, ", ");
  TX_KV_PRINT_WITH_ERR(true, max_applied_log_ts, max_applied_log_ts_, ", ");
  TX_KV_PRINT_WITH_ERR(true, max_appling_log_ts, max_applying_log_ts_, ", ");
  TX_KV_PRINT_WITH_ERR(true, max_applying_part_log_no, max_applying_part_log_no_, ", ");
  TX_KV_PRINT_WITH_ERR(true, max_submitted_seq_no, max_submitted_seq_no_, ", ");
  TX_KV_PRINT_WITH_ERR(true, checksum, checksum_, ", ");
  TX_KV_PRINT_WITH_ERR(true, checksum_scn, checksum_scn_, ", ");
  TX_KV_PRINT_WITH_ERR(true, need_checksum, need_checksum_, ", ");
  TX_KV_PRINT_WITH_ERR(true, data_complete, data_complete_, ", ");


  TX_KV_PRINT_WITH_ERR(prev_record_lsn_.is_valid(), prev_record_lsn, prev_record_lsn_, ", ");
  TX_KV_PRINT_WITH_ERR(!redo_lsns_.empty(), redo_lsns, redo_lsns_, ", ");
  TX_KV_PRINT_WITH_ERR(!multi_data_source_.empty(), multi_data_source, multi_data_source_, ", ");
  TX_KV_PRINT_WITH_ERR(max_durable_lsn_.is_valid(),max_durable_lsn , max_durable_lsn_, ", ");
  TX_KV_PRINT_WITH_ERR(serial_final_scn_.is_valid(), serial_final_scn, serial_final_scn_, ", ");
  TX_KV_PRINT_WITH_ERR(serial_final_seq_no_.is_valid(), serial_final_seq_no,serial_final_seq_no_, ", ");


  ON_DEMAND_END_PRINT(ExecInfo);

  return ret;
}

IMPL_ON_DEMAND_PRINT_FUNC(ObTxCtx)
{
  int ret = OB_SUCCESS;
  int tmp_pos = 0;

  ON_DEMAND_START_PRINT(TxCtxExtra);

  TX_KV_PRINT_WITH_ERR(!busy_cbs_.is_empty(), busy_cbs_cnt, busy_cbs_.get_size(), ", ");
  TX_KV_PRINT_WITH_ERR(!busy_cbs_.is_empty(), oldest_busy_cb, busy_cbs_.get_first(), ", ");

  TX_PRINT_FUNC_WITH_ERR(runtime_state_.is_valid(), runtime_state_.on_demand_print_, ", ");

  // TX_KV_PRINT_WITH_ERR(OB_NOT_NULL(block_frozen_memtable_), block_frozen_memtable,
  //                      block_frozen_memtable_, ", ");
  //
  TX_PRINT_FUNC_WITH_ERR(true,
                       exec_info_.on_demand_print_, " ");
  ON_DEMAND_END_PRINT(TxCtxExtra);

  return ret;
}

} // namespace transaction

} // namespace oceanbase
