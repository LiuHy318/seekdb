/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ob_trans_submit_log_cb.h"
#include "share/rc/ob_server_runtime.h"
#include "ob_tx_ctx.h"
#include "storage/allocator/ob_shared_memory_allocator_mgr.h"

namespace oceanbase
{
using namespace common;
using namespace share;
using namespace storage;
using namespace palf;

namespace transaction
{

void ObTxBaseLogCb::reset()
{
  AppendCb::reset();
  base_ts_.reset();
  log_ts_.reset();
  lsn_.reset();
  submit_ts_ = 0;

  log_size_ = 0; 
}

void ObTxBaseLogCb::reuse()
{
  base_ts_.reset();
  log_ts_.reset();
  lsn_.reset();
  submit_ts_ = 0;

  log_size_ = 0;
}

int ObTxBaseLogCb::set_log_ts(const SCN &log_ts)
{
  int ret = OB_SUCCESS;

  if (!log_ts.is_valid()) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid argument", K(ret), K(log_ts));
  } else {
    log_ts_ = log_ts;
  }

  return ret;
}

int ObTxBaseLogCb::set_lsn(const LSN &lsn)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(!lsn.is_valid())) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid argument", K(ret), K(lsn));
  } else {
    lsn_ = lsn;
  }
  return ret;
}

int ObTxLogCb::init(ObTxCtx *tx_ctx)
{
  int ret = OB_SUCCESS;

  if (OB_ISNULL(tx_ctx)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid arguments", K(ret), KPC(tx_ctx));
  } else if (OB_NOT_NULL(tx_ctx_)) {
    ret = OB_INIT_TWICE;
    TRANS_LOG(WARN, "init ObTxLogCb twice", K(ret), KPC(tx_ctx), KPC(tx_ctx_));
  } else {
    tx_ctx_ = tx_ctx;
  }

  return ret;
}

void ObTxLogCb::reset_tx_op_array()
{
  if (OB_NOT_NULL(tx_op_array_)) {
    for (int64_t idx = 0; idx < tx_op_array_->count(); idx++) {
      tx_op_array_->at(idx).release();
    }
    tx_op_array_->~ObTxOpArray();
    server_free(tx_op_array_);
    tx_op_array_ = nullptr;
  }
}

void ObTxLogCb::reset_undo_node()
{
  if (OB_NOT_NULL(undo_node_)) {
    ::oceanbase::share::server_service<::oceanbase::share::ObSharedMemAllocMgr>()->tx_data_allocator().free(undo_node_);
    undo_node_ = NULL;
  }
}

void ObTxLogCb::reset()
{
  ObTxBaseLogCb::reset();
  ObDLinkBase<ObTxLogCb>::reset();
  tx_ctx_ = nullptr;
  tx_data_guard_.reset();
  callbacks_.reset();
  is_callbacked_ = false;
  is_busy_ = false;
  cb_arg_array_.reset();
  mds_range_.reset();

  // is_callbacking_ = false;
  first_part_scn_.invalid_scn();
  reset_tx_op_array();
  reset_undo_node();
}

void ObTxLogCb::reuse()
{
  ObTxBaseLogCb::reuse();
  tx_data_guard_.reset();
  callbacks_.reset();
  is_callbacked_ = false;
  is_busy_ = false;
  cb_arg_array_.reset();
  mds_range_.reset();

  first_part_scn_.invalid_scn();
  reset_tx_op_array();
  reset_undo_node();
}

ObTxLogType ObTxLogCb::get_last_log_type() const
{
  ObTxLogType log_type = ObTxLogType::UNKNOWN;
  if (cb_arg_array_.count() > 0) {
    log_type = cb_arg_array_.at(cb_arg_array_.count() - 1).get_log_type();
  }
  return log_type;
}

bool ObTxLogCb::is_valid() const
{
  return cb_arg_array_.count() > 0;
}

int ObTxLogCb::on_success()
{
  int ret = OB_SUCCESS;

  if (OB_ISNULL(tx_ctx_)) {
    ret = OB_NOT_INIT;
    TRANS_LOG(WARN, "ObTxLogCb not inited", K(ret));
  } else {
    ObTxCtx *part_ctx = tx_ctx_;
    if (NULL == part_ctx) {
      ret = OB_ERR_UNEXPECTED;
      TRANS_LOG(ERROR, "ctx is null", K(ret), KPC(part_ctx));
    } else {
      if (OB_FAIL(part_ctx->on_success(this))) {
      }
    }
  }

  return ret;
}

int ObTxLogCb::on_failure()
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(tx_ctx_)) {
    ret = OB_NOT_INIT;
    TRANS_LOG(WARN, "ObTxLogCb not inited", K(*this));
  } else {
    ObTxCtx *part_ctx = tx_ctx_;
    ObTransID tx_id;
    const share::SCN log_ts = log_ts_;
    if (NULL == part_ctx) {
      ret = OB_ERR_UNEXPECTED;
      TRANS_LOG(ERROR, "ctx is null", KR(ret), K(*this));
    } else {
      tx_id = part_ctx->get_trans_id();
      if (OB_FAIL(part_ctx->on_failure(this))) {
      }
    }
    TRANS_LOG(INFO, "ObTxLogCb::on_failure end", KR(ret), K(tx_id), K(log_ts));
  }
  return ret;
}

int ObTxLogCb::copy(const ObTxLogCb &other)
{
  int ret = OB_SUCCESS;
  log_ts_ = other.log_ts_;
  lsn_ = other.lsn_;
  submit_ts_ = other.submit_ts_;
  if (OB_FAIL(callbacks_.assign(other.callbacks_))) {
  } else if (FALSE_IT(is_callbacked_ = other.is_callbacked_)) {
  // without txdata
  } else if (OB_FAIL(mds_range_.assign(other.mds_range_))) {
  } else if (OB_FAIL(cb_arg_array_.assign(other.cb_arg_array_))) {
  }
  first_part_scn_ = other.first_part_scn_;

  return ret;
}

} // transaction
} // oceanbase
