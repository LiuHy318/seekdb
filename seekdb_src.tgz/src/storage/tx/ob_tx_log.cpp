/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "storage/tx/ob_tx_log.h"
#include "storage/memtable/ob_memtable_mutator.h"

namespace oceanbase
{

using namespace common;
using namespace share;
namespace transaction
{

logservice::ObReplayBarrierType
ObTxLogTypeChecker::need_replay_barrier(const ObTxLogType log_type,
                                        const ObTxDataSourceType data_source_type)
{

  logservice::ObReplayBarrierType barrier_flag = logservice::ObReplayBarrierType::NO_NEED_BARRIER;

  // multi data source trans's redo log
  if (ObTxLogType::TX_MULTI_DATA_SOURCE_LOG == log_type) {
    if (data_source_type == ObTxDataSourceType::CREATE_TABLET_NEW_MDS
        || data_source_type == ObTxDataSourceType::DELETE_TABLET_NEW_MDS
        || data_source_type == ObTxDataSourceType::UNBIND_TABLET_NEW_MDS
        || data_source_type == ObTxDataSourceType::TABLET_BINDING
        || data_source_type == ObTxDataSourceType::UNBIND_LOB_TABLET
        || data_source_type == ObTxDataSourceType::DDL_COMPLETE_MDS) {
      barrier_flag = logservice::ObReplayBarrierType::PRE_BARRIER;
    }
  }

  return barrier_flag;
}
int ObTxLogTypeChecker::decide_final_barrier_type(
    const logservice::ObReplayBarrierType tmp_log_barrier_type,
    logservice::ObReplayBarrierType &final_barrier_type)
{

  int ret = OB_SUCCESS;
  if (logservice::ObReplayBarrierType::NO_NEED_BARRIER == final_barrier_type
      || logservice::ObReplayBarrierType::INVALID_BARRIER == final_barrier_type) {
    final_barrier_type = tmp_log_barrier_type;

  } else if (logservice::ObReplayBarrierType::NO_NEED_BARRIER == tmp_log_barrier_type) {
    // do nothing
  } else if (logservice::ObReplayBarrierType::PRE_BARRIER == tmp_log_barrier_type) {
    if (logservice::ObReplayBarrierType::PRE_BARRIER == final_barrier_type
        || logservice::ObReplayBarrierType::STRICT_BARRIER == final_barrier_type) {
      // do nothing
    } else {
      ret = OB_ERR_UNEXPECTED;
      TRANS_LOG(ERROR, "Unkown final barrier type", K(ret), K(final_barrier_type),
                K(tmp_log_barrier_type));
    }

  } else if (logservice::ObReplayBarrierType::STRICT_BARRIER == tmp_log_barrier_type) {

    if (logservice::ObReplayBarrierType::PRE_BARRIER == final_barrier_type) {
      final_barrier_type = tmp_log_barrier_type;
    } else if (logservice::ObReplayBarrierType::STRICT_BARRIER == final_barrier_type) {
      // do nothing
    } else {
      ret = OB_ERR_UNEXPECTED;
      TRANS_LOG(ERROR, "Unkown final barrier type", K(ret), K(final_barrier_type),
                K(tmp_log_barrier_type));
    }
  }
  return ret;
}

ObTxLogType ObTxPrevLogType::convert_to_tx_log_type()
{
  ObTxLogType tx_log_type = ObTxLogType::UNKNOWN;
  if (TypeEnum::COMMIT_INFO == prev_log_type_) {
    tx_log_type = ObTxLogType::TX_COMMIT_INFO_LOG;
  }
  return tx_log_type;
}

int ObTxPrevLogType::serialize(char *buf, const int64_t buf_len, int64_t &pos) const
{
  int8_t prev_val;
  memcpy(&prev_val, &prev_log_type_, 1);
  return serialization::encode_i8(buf, buf_len, pos, prev_val);
}

int ObTxPrevLogType::deserialize(const char *buf, const int64_t data_len, int64_t &pos)
{
  int ret = OB_SUCCESS;
  int8_t prev_val = 0;
  int64_t tmp_pos = pos;

  if (OB_SUCC(serialization::decode_i8(buf, data_len, pos, &prev_val))) {
    memcpy(&prev_log_type_, &prev_val, 1);
    pos = tmp_pos;
  }
  return ret;
}

int64_t ObTxPrevLogType::get_serialize_size(void) const
{
  int8_t prev_val;
  memcpy(&prev_val, &prev_log_type_, 1);
  return serialization::encoded_length_i8(prev_val);
}


// ============================== Tx Log Header =============================

DEFINE_SERIALIZE(ObTxLogHeader)
{
  int ret = OB_SUCCESS;
  int64_t tmp_pos = pos;

  if (OB_ISNULL(buf) || buf_len <= 0) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_FAIL(serialization::encode_i64(buf, buf_len, tmp_pos, static_cast<int64_t>(tx_log_type_)))) {
  } else {
    pos = tmp_pos;
  }
  return ret;
}

DEFINE_DESERIALIZE(ObTxLogHeader)
{
  int ret = OB_SUCCESS;
  int64_t tmp_pos = pos;

  int64_t log_type = 0;
  if (OB_ISNULL(buf) || data_len <= 0) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_FAIL(serialization::decode_i64(buf, data_len, tmp_pos, &log_type))) {
  } else {
    tx_log_type_ = static_cast<ObTxLogType>(log_type);
    pos = tmp_pos;
  }

  return ret;
}

DEFINE_GET_SERIALIZE_SIZE(ObTxLogHeader)
{
  int64_t size = 0;
  size += serialization::encoded_length_i64(static_cast<int64_t>(tx_log_type_));
  return size;
}

// ============================== Tx Log serialization =============================

// RedoLogBody serialize mutator_buf in log block
OB_DEF_SERIALIZE(ObTxRedoLog)
{
  int ret = OB_SUCCESS;
  uint32_t tmp_size = 0;
  int64_t tmp_pos = pos;
  if (mutator_size_ < 0) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(ERROR, "INVALID mutator_buf_");
  } else if ((tmp_size = static_cast<uint32_t>(mutator_size_))
             && OB_FAIL(serialization::encode_i32(buf, buf_len, tmp_pos, tmp_size))) {
    TRANS_LOG(WARN, "encode mutator_size_ error", K(ret));
  } else {
    pos = tmp_pos + mutator_size_;
  }
  return ret;
}

OB_DEF_DESERIALIZE(ObTxRedoLog)
{
  int ret = OB_SUCCESS;
  int64_t org_pos = pos;
  int32_t tmp_size = 0;

  if (OB_FAIL(serialization::decode_i32(buf, data_len, pos, &tmp_size))) {
  } else {
    mutator_size_ = static_cast<int64_t>(tmp_size);
    replay_mutator_buf_ = buf + pos;
    pos = pos + mutator_size_;
  }
  if (OB_FAIL(ret)) {
    pos = org_pos;
  }
  return ret;
}

OB_DEF_SERIALIZE_SIZE(ObTxRedoLog)
{
  int64_t len = 0;
  if (mutator_size_ < 0) {
    len = mutator_size_;
    TRANS_LOG_RET(WARN, OB_ERR_UNEXPECTED, "mutator_buf_ has not set");
  } else {
    len = len + MUTATOR_SIZE_NEED_BYTES;
    len = len + mutator_size_;
  }
  return len;
}

// Other LogBody
OB_SERIALIZE_MEMBER(ObTxCommitInfoLog,
                       /* 1 */ can_elr_,
                       /* 2 */ app_trace_id_str_,
                       /* 3 */ obsolete_trace_payload_,
                       /* 4 */ prev_record_lsn_,
                       /* 5 */ redo_lsns_);

OB_SERIALIZE_MEMBER(ObTxCommitLog,
                    /* 1 */ commit_version_,
                    /* 2 */ checksum_,
                    /* 3 */ multi_source_data_,
                    /* 4 */ tx_data_backup_,
                    /* 5 */ prev_lsn_,
                    /* 6 */ checksum_sig_serde_,
                    /* 7 */ prev_log_type_);

OB_SERIALIZE_MEMBER(ObTxClearLog);

OB_SERIALIZE_MEMBER(ObTxAbortLog,
                    /* 1 */ multi_source_data_,
                    /* 2 */ tx_data_backup_);

OB_SERIALIZE_MEMBER(ObTxRecordLog, /* 1 */ prev_record_lsn_, /* 2 */ redo_lsns_);

OB_SERIALIZE_MEMBER(ObTxRollbackToLog, /* 1 */ from_, /* 2 */ to_);

OB_SERIALIZE_MEMBER(ObTxMultiDataSourceLog, /* 1 */ data_);

ObTxCommitInfoLog::ObTxCommitInfoLog(bool is_elr,
                                     common::ObString &app_trace_id,
                                     const LogOffSet &prev_record_lsn,
                                     ObRedoLSNArray &redo_lsns)
    : can_elr_(is_elr),
      app_trace_id_str_(app_trace_id), obsolete_trace_payload_(),
      prev_record_lsn_(prev_record_lsn), redo_lsns_(redo_lsns)
{}

ObTxCommitLog::ObTxCommitLog(share::SCN commit_version,
                             uint64_t checksum,
                             ObIArray<uint8_t> &checksum_sig,
                             ObTxBufferNodeArray &multi_source_data,
                             LogOffSet prev_lsn,
                             ObTxPrevLogType prev_log_type)
    : checksum_(checksum), checksum_sig_(checksum_sig), checksum_sig_serde_(checksum_sig_),
      multi_source_data_(multi_source_data), prev_lsn_(prev_lsn), prev_log_type_(prev_log_type)
{
  commit_version_ = commit_version;
}

ObTxClearLog::ObTxClearLog() {}


// ============================== Tx Log Body ===========================

const ObTxLogType ObTxRedoLog::LOG_TYPE = ObTxLogType::TX_REDO_LOG;
const ObTxLogType ObTxCommitInfoLog::LOG_TYPE = ObTxLogType::TX_COMMIT_INFO_LOG;
const ObTxLogType ObTxCommitLog::LOG_TYPE = ObTxLogType::TX_COMMIT_LOG;
const ObTxLogType ObTxClearLog::LOG_TYPE = ObTxLogType::TX_CLEAR_LOG;
const ObTxLogType ObTxAbortLog::LOG_TYPE = ObTxLogType::TX_ABORT_LOG;
const ObTxLogType ObTxRecordLog::LOG_TYPE = ObTxLogType::TX_RECORD_LOG;
// const ObTxLogType ObTxKeepAliveLog::LOG_TYPE = ObTxLogType::TX_KEEP_ALIVE_LOG;
const ObTxLogType ObTxRollbackToLog::LOG_TYPE = ObTxLogType::TX_ROLLBACK_TO_LOG;
const ObTxLogType ObTxMultiDataSourceLog::LOG_TYPE = ObTxLogType::TX_MULTI_DATA_SOURCE_LOG;

int ObTxRedoLog::set_mutator_buf(char *buf)
{
  int ret = OB_SUCCESS;
  if (nullptr == buf || mutator_size_ >= 0) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(ERROR, "invalid mutator buf", KP(buf), K(mutator_size_));
  } else {
    mutator_buf_ = buf;
  }
  return ret;
}

int ObTxRedoLog::set_mutator_size(const int64_t size, const bool after_fill)
{
  int ret = OB_SUCCESS;
  if (size < 0 || OB_ISNULL(mutator_buf_) || (!after_fill && mutator_size_ >= 0)
      || (after_fill && mutator_size_ < size)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(ERROR, "invalid argument when set mutator size", K(after_fill), K(size),
               K(mutator_size_), KP(mutator_buf_));
  } else if (!after_fill) {
    int len = 0;
    SERIALIZE_SIZE_HEADER(UNIS_VERSION);
    len = len + MUTATOR_SIZE_NEED_BYTES;
    if (size <= len) {
      ret = OB_SIZE_OVERFLOW;
      TRANS_LOG(WARN, "mutator buf is not enough", K(len), K(size));
    } else {
      mutator_size_ = size - len;
      mutator_buf_ = mutator_buf_ + len;
    }
  } else {
    mutator_size_ = size;
  }
  return ret;
}

void ObTxRedoLog::reset_mutator_buf()
{
  mutator_buf_ = nullptr;
  mutator_size_ = -1;
}

int ObTxRedoLog::ob_admin_dump(memtable::ObMemtableMutatorIterator *iter_ptr,
                               ObAdminMutatorStringArg &arg,
                               const char *block_name,
                               palf::LSN lsn,
                               int64_t tx_id,
                               SCN scn,
                               bool &has_dumped_tx_id)
{
  int ret = OB_SUCCESS;
  int64_t pos = 0;

    arg.log_stat_->tx_redo_log_size_ += get_serialize_size();
  if (OB_ISNULL(iter_ptr) || OB_ISNULL(arg.writer_ptr_) || OB_ISNULL(arg.buf_)
      || OB_NOT_NULL(mutator_buf_) || OB_ISNULL(replay_mutator_buf_)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid argument", KP(iter_ptr), KP(arg.writer_ptr_), KP(arg.buf_),
              KP(mutator_buf_), KP(replay_mutator_buf_));
  } else if (OB_FAIL(iter_ptr->deserialize(replay_mutator_buf_, mutator_size_, pos))) {
  } else {
    bool has_output = false;
    arg.log_stat_->mutator_size_ += get_mutator_size();
    if (!arg.filter_.is_tablet_id_valid()) {
      arg.writer_ptr_->dump_key("###<TxRedoLog>");
      arg.writer_ptr_->start_object();
      arg.writer_ptr_->dump_key("txctxinfo");
      ObCStringHelper helper;
      arg.writer_ptr_->dump_string(helper.convert(*this));
      arg.writer_ptr_->dump_key("MutatorMeta");
      arg.writer_ptr_->dump_string(helper.convert(iter_ptr->get_meta()));

      arg.writer_ptr_->dump_key("MutatorRows");
      arg.writer_ptr_->start_object();
      has_output = true;
    } else {
      if (!has_dumped_tx_id) {
        databuff_printf(arg.buf_, arg.buf_len_, arg.pos_, "{BlockID: %s; LSN:%ld, TxID:%ld; SCN:",
                        block_name, lsn.val_, tx_id);
        databuff_printf(arg.buf_, arg.buf_len_, arg.pos_, scn);
      }
      databuff_printf(arg.buf_, arg.buf_len_, arg.pos_, "<TxRedoLog>: {TxCtxInfo: {");
      databuff_printf(arg.buf_, arg.buf_len_, arg.pos_, *this);
      databuff_printf(arg.buf_, arg.buf_len_, arg.pos_, "}; MutatorMeta: {");
      databuff_printf(arg.buf_, arg.buf_len_, arg.pos_, iter_ptr->get_meta());
      databuff_printf(arg.buf_, arg.buf_len_, arg.pos_, "}; MutatorRows: {");
      //fill info in buf
    }
    bool has_dumped_meta_info = false;
    while (OB_SUCC(iter_ptr->iterate_next_row())) {
      // arg.writer_ptr_->start_object();
      if (arg.filter_.is_tablet_id_valid()) {
        if (arg.filter_.get_tablet_id() != iter_ptr->get_row_head().tablet_id_) {
          TRANS_LOG(INFO, "just skip according to tablet_id", K(arg), K(iter_ptr->get_row_head()));
          continue;
        } else if (!has_dumped_meta_info) {
          arg.writer_ptr_->dump_string(arg.buf_);
          has_dumped_meta_info = true;
          has_dumped_tx_id = true;
          //print tx_id and RedoLog related info in arg
        }
      }
      has_output = true;
      arg.writer_ptr_->dump_key("RowHeader");
      ObCStringHelper helper;
      arg.writer_ptr_->dump_string(helper.convert(iter_ptr->get_row_head()));

      switch (iter_ptr->get_row_head().mutator_type_) {
        case memtable::MutatorType::MUTATOR_ROW: {
          arg.writer_ptr_->dump_key("NORMAL_ROW");
          arg.writer_ptr_->start_object();
          arg.log_stat_->normal_row_count_++;
          if (OB_FAIL(format_mutator_row_(iter_ptr->get_mutator_row(), arg))) {
          }
          arg.writer_ptr_->end_object();
          break;
        }
        case memtable::MutatorType::MUTATOR_TABLE_LOCK: {
          arg.log_stat_->table_lock_count_++;
          arg.writer_ptr_->dump_key("TableLock");
          helper.reset();
          arg.writer_ptr_->dump_string(helper.convert(iter_ptr->get_table_lock_row()));
          break;
        }
        case memtable::MutatorType::MUTATOR_ROW_EXT_INFO: {
          arg.writer_ptr_->dump_key("ExtInfo");
          arg.writer_ptr_->start_object();
          arg.log_stat_->ext_info_log_count_++;
          if (OB_FAIL(format_mutator_row_(iter_ptr->get_mutator_row(), arg))) {
          }
          arg.writer_ptr_->end_object();
          break;
        }
        default: {
          arg.writer_ptr_->dump_key("ERROR:unknown mutator type");
          const int64_t mutator_type = static_cast<int64_t>(iter_ptr->get_row_head().mutator_type_);
          arg.writer_ptr_->dump_int64(mutator_type);
          ret = OB_NOT_SUPPORTED;
          TRANS_LOG(WARN, "ERROR:unknown mutator type", K(ret));
          break;
        }
      }
    }
    if (has_output) {
      //mutator row
      arg.writer_ptr_->end_object();
      //TxRedoLog
      arg.writer_ptr_->end_object();
    }
    if (OB_ITER_END != ret) {
      TRANS_LOG(WARN, "iterate_next_row failed", K(ret));
    } else {
      ret = OB_SUCCESS;
    }
  }

  return ret;
}

int ObTxRedoLog::format_mutator_row_(const memtable::ObMemtableMutatorRow &row,
                                          ObAdminMutatorStringArg &arg)
{
  int ret = OB_SUCCESS;

  uint64_t table_id = OB_INVALID_ID;
  int64_t table_version = 0;
  uint32_t modify_count = 0;
  uint32_t acc_checksum = 0;
  int64_t version = 0;
  int32_t flag = 0;
  transaction::ObTxSEQ seq_no;
  int64_t column_cnt = 0;
  ObStoreRowkey rowkey;
  memtable::ObRowData new_row;
  memtable::ObRowData old_row;
  ObCStringHelper helper;
  blocksstable::ObDmlFlag dml_flag = blocksstable::ObDmlFlag::DF_NOT_EXIST;

  if (OB_FAIL(row.copy(table_id, rowkey, table_version, new_row, old_row, dml_flag,
                       modify_count, acc_checksum, version, flag, seq_no, column_cnt))) {
  } else {
    arg.log_stat_->new_row_size_ += new_row.size_;
    arg.log_stat_->old_row_size_ += old_row.size_;
    arg.writer_ptr_->dump_key("RowKey");
    (void)smart_dump_rowkey_(rowkey, arg);
    arg.writer_ptr_->dump_key("TableVersion");
    arg.writer_ptr_->dump_int64(table_version);

    // new row
    arg.writer_ptr_->dump_key("NewRow Cols");
    arg.writer_ptr_->start_object();
    if (OB_FAIL(format_row_data_(new_row, arg))) {
    }
    arg.writer_ptr_->end_object();

    // old row
    arg.writer_ptr_->dump_key("OldRow Cols");
    arg.writer_ptr_->start_object();
    if (OB_SUCC(ret) && OB_FAIL(format_row_data_(old_row, arg))) {
      TRANS_LOG(WARN, "format old_row failed", K(ret));
    }
    arg.writer_ptr_->end_object();

    arg.writer_ptr_->dump_key("DmlFlag");
    arg.writer_ptr_->dump_string(get_dml_str(dml_flag));
    arg.writer_ptr_->dump_key("ModifyCount");
    arg.writer_ptr_->dump_uint64(modify_count);
    arg.writer_ptr_->dump_key("AccChecksum");
    arg.writer_ptr_->dump_uint64(acc_checksum);
    arg.writer_ptr_->dump_key("Version");
    arg.writer_ptr_->dump_int64(version);
    arg.writer_ptr_->dump_key("Flag");
    arg.writer_ptr_->dump_int64(flag);
    arg.writer_ptr_->dump_key("SeqNo");
    arg.writer_ptr_->dump_string(helper.convert(seq_no));
    arg.writer_ptr_->dump_key("NewRowSize");
    arg.writer_ptr_->dump_int64(new_row.size_);
    arg.writer_ptr_->dump_key("OldRowSize");
    arg.writer_ptr_->dump_int64(old_row.size_);
    arg.writer_ptr_->dump_key("ColumnCnt");
    arg.writer_ptr_->dump_int64(column_cnt);
  }
  return ret;
}

int ObTxRedoLog::smart_dump_rowkey_(const ObStoreRowkey &rowkey, ObAdminMutatorStringArg &arg)
{
  int ret = OB_SUCCESS;
  int64_t pos = rowkey.to_smart_string(arg.buf_ + arg.pos_, arg.buf_len_ - arg.pos_);
  if (pos > 0) {
    arg.writer_ptr_->dump_string(arg.buf_ + arg.pos_);
  }
  return ret;
}

int ObTxRedoLog::format_row_data_(const memtable::ObRowData &row_data, ObAdminMutatorStringArg &arg)
{
  int ret = OB_SUCCESS;

  blocksstable::ObDatumRow datum_row;
  blocksstable::ObRowReader row_reader;
  const blocksstable::ObRowHeader *row_header = nullptr;
  if (row_data.size_ > 0) {
    if (OB_FAIL(row_reader.read_row(row_data.data_, row_data.size_, nullptr, datum_row))) {
    }
    for (int64_t i = 0; OB_SUCC(ret) && i < datum_row.get_column_count(); i++) {
      int64_t pos = 0;
      if (nullptr != arg.writer_ptr_) {
        sprintf(arg.buf_ + arg.pos_, "%lu", i);
        arg.writer_ptr_->dump_key(arg.buf_ + arg.pos_);
        pos = datum_row.storage_datums_[i].storage_to_string(arg.buf_ + arg.pos_, arg.buf_len_ - arg.pos_);
        arg.writer_ptr_->dump_string(arg.buf_ + arg.pos_);
      }
    }
  } else if (NULL == row_data.data_ && 0 == row_data.size_) {
  }
  return ret;
}

void ObTxMultiDataSourceLog::reset()
{
  data_.reset();
}

int ObTxMultiDataSourceLog::fill_MDS_data(const ObTxBufferNode &node)
{
  int ret = OB_SUCCESS;
  if (node.get_serialize_size() + data_.get_serialize_size() >= MAX_MDS_LOG_SIZE) {
    ret = OB_SIZE_OVERFLOW;
    TRANS_LOG(WARN, "MDS log is overflow", K(*this), K(node));
  }

  if (OB_SUCC(ret)) {
    data_.push_back(node);
  }
  return ret;
}

OB_SERIALIZE_MEMBER(ObTxDataBackup, start_log_ts_);

int ObTxCommitInfoLog::ob_admin_dump(ObAdminMutatorStringArg &arg)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(arg.writer_ptr_)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid arg writer is NULL", K(arg), K(ret));
  } else {
    arg.writer_ptr_->dump_key("###<TxCommitInfoLog>");
    arg.writer_ptr_->start_object();
    arg.writer_ptr_->dump_key("Size");
    arg.writer_ptr_->dump_int64(get_serialize_size());
    arg.writer_ptr_->dump_key("Members");
    ObCStringHelper helper;
    arg.writer_ptr_->dump_string(helper.convert(*this));
    arg.writer_ptr_->end_object();
  }
  return ret;
}

int ObTxCommitLog::ob_admin_dump(ObAdminMutatorStringArg &arg)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(arg.writer_ptr_)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid arg writer is NULL", K(arg), K(ret));
  } else {
    arg.writer_ptr_->dump_key("###<TxCommitLog>");
    arg.writer_ptr_->start_object();
    arg.writer_ptr_->dump_key("Size");
    arg.writer_ptr_->dump_int64(get_serialize_size());
    arg.writer_ptr_->dump_key("Members");
    ObCStringHelper helper;
    arg.writer_ptr_->dump_string(helper.convert(*this));
    arg.writer_ptr_->end_object();
  }
  return ret;
}

int ObTxClearLog::ob_admin_dump(ObAdminMutatorStringArg &arg)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(arg.writer_ptr_)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid arg writer is NULL", K(arg), K(ret));
  } else {
    arg.writer_ptr_->dump_key("###<TxClearLog>");
    arg.writer_ptr_->start_object();
    arg.writer_ptr_->dump_key("Members");
    ObCStringHelper helper;
    arg.writer_ptr_->dump_string(helper.convert(*this));
    arg.writer_ptr_->end_object();
  }
  return ret;
}

int ObTxAbortLog::ob_admin_dump(ObAdminMutatorStringArg &arg)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(arg.writer_ptr_)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid arg writer is NULL", K(arg), K(ret));
  } else {
    arg.writer_ptr_->dump_key("###<TxAbortLog>");
    arg.writer_ptr_->start_object();
    arg.writer_ptr_->dump_key("Members");
    ObCStringHelper helper;
    arg.writer_ptr_->dump_string(helper.convert(*this));
    arg.writer_ptr_->end_object();
  }
  return ret;
}

int ObTxRecordLog::ob_admin_dump(ObAdminMutatorStringArg &arg)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(arg.writer_ptr_)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid arg writer is NULL", K(arg), K(ret));
  } else {
    arg.writer_ptr_->dump_key("###<TxRecordLog>");
    arg.writer_ptr_->start_object();
    arg.writer_ptr_->dump_key("Members");
    ObCStringHelper helper;
    arg.writer_ptr_->dump_string(helper.convert(*this));
    arg.writer_ptr_->end_object();
  }
  return ret;
}

int ObTxRollbackToLog::ob_admin_dump(ObAdminMutatorStringArg &arg)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(arg.writer_ptr_)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid arg writer is NULL", K(arg), K(ret));
  } else {
    arg.writer_ptr_->dump_key("<TxRollbackToLog>");
    arg.writer_ptr_->start_object();
    arg.writer_ptr_->dump_key("Members");
    ObCStringHelper helper;
    arg.writer_ptr_->dump_string(helper.convert(*this));
    arg.writer_ptr_->end_object();
  }
  return ret;
}

int ObTxMultiDataSourceLog::ob_admin_dump(ObAdminMutatorStringArg &arg)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(arg.writer_ptr_)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid arg writer is NULL", K(arg), K(ret));
  } else {
    arg.writer_ptr_->dump_key("<TxMultiDataSourceLog>");
    arg.writer_ptr_->start_object();
    arg.writer_ptr_->dump_key("mds_count");
    ObCStringHelper helper;
    arg.writer_ptr_->dump_string(helper.convert(data_.count()));

    arg.writer_ptr_->dump_key("mds_array");
    arg.writer_ptr_->start_object();
    for (int64_t i = 0; i < data_.count(); i++) {
      arg.writer_ptr_->dump_key("type");
        helper.reset();
        arg.writer_ptr_->dump_string(ObMultiDataSourcePrinter::to_str_mds_type(data_[i].get_data_source_type()));
        arg.writer_ptr_->dump_key("buf_len");
        arg.writer_ptr_->dump_string(helper.convert(data_[i].get_data_size()));
        arg.writer_ptr_->dump_key("content");
        helper.reset();
        arg.writer_ptr_->dump_string(
            ObMulSourceTxDataDump::dump_buf(data_[i].get_data_source_type(),
                                            static_cast<char *>(data_[i].get_ptr()),
                                            data_[i].get_data_size(),
                                            helper));
    }
    arg.writer_ptr_->end_object();

    arg.writer_ptr_->end_object();
  }
  return ret;
}

ObTxDataBackup::ObTxDataBackup() { reset(); }

int ObTxDataBackup::init(const share::SCN &start_scn)
{
  int ret = OB_SUCCESS;
  start_log_ts_ = start_scn;
  return ret;
}

void ObTxDataBackup::reset() { start_log_ts_.reset(); }

int ObTxCommitLog::init_tx_data_backup(const share::SCN &start_scn)
{
  int ret = OB_SUCCESS;

  if (OB_FAIL(tx_data_backup_.init(start_scn))) {
  }

  // TRANS_LOG(INFO, "init tx_data_backup_", K(ret), K(tx_data_backup_));
  return ret;
}

int ObTxAbortLog::init_tx_data_backup(const share::SCN &start_scn)
{
  int ret = OB_SUCCESS;

  if (OB_FAIL(tx_data_backup_.init(start_scn))) {
  }

  // TRANS_LOG(INFO, "init tx_data_backup_", K(ret), K(tx_data_backup_));
  return ret;
}

// ============================== Tx Log Block =============================
OB_SERIALIZE_MEMBER(ObTxLogBlockHeader,
                    __log_entry_no_,
                    tx_id_,
                    flags_);

const logservice::ObLogBaseType ObTxLogBlock::DEFAULT_LOG_BLOCK_TYPE =
    logservice::ObLogBaseType::TRANS_SERVICE_LOG_BASE_TYPE; // TRANS_LOG
const int32_t ObTxLogBlock::DEFAULT_BIG_ROW_BLOCK_SIZE =
    62 * 1024 * 1024; // 62M redo log buf for big row

const int64_t ObTxLogBlock::BIG_SEGMENT_SPILT_SIZE = common::OB_MAX_LOG_ALLOWED_SIZE; //256 * 1024

void ObTxLogBlock::reset()
{
  inited_ = false;
  log_base_header_.reset();
  header_.reset();
  fill_buf_.reset();
  replay_buf_ = nullptr;
  len_ = pos_ = 0;
  cur_log_type_ = ObTxLogType::UNKNOWN;
  cb_arg_array_.reset();
  big_segment_buf_ = nullptr;
}

int ObTxLogBlock::reuse_for_fill()
{
  int ret = OB_SUCCESS;
  log_base_header_.reset();
  cur_log_type_ = ObTxLogType::UNKNOWN;
  cb_arg_array_.reset();
  big_segment_buf_ = nullptr;
  pos_ = 0;
  // reserve place for headers, header will be filled back
  pos_ += log_base_header_.get_serialize_size(); // assume FIXED size
  pos_ += header_.get_serialize_size();
  return ret;
}

ObTxLogBlock::ObTxLogBlock()
    : inited_(false), log_base_header_(), header_(),
      replay_buf_(nullptr), len_(0), pos_(0), cur_log_type_(ObTxLogType::UNKNOWN), cb_arg_array_(),
      big_segment_buf_(nullptr)
{
  // do nothing
}

int ObTxLogBlock::init_for_fill(const int64_t suggested_buf_size)
{
  int ret = OB_SUCCESS;
  // accept the suggested buffer size
  const int64_t buf_size = suggested_buf_size;
  if (OB_NOT_NULL(replay_buf_)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(ERROR, "invalid argument", K(*this), K_(header));
  } else if (OB_FAIL(fill_buf_.init(buf_size))) {
  } else {
    len_ = fill_buf_.get_length();
    pos_ = 0;
    // reserve place for headers, header will be filled back
    pos_ += log_base_header_.get_serialize_size(); // assume FIXED size
    pos_ += header_.get_serialize_size();
    inited_ = true;
  }
  return ret;
}

int ObTxLogBlock::init_for_replay(const char *buf, const int64_t &size)
{
  int ret = OB_SUCCESS;
  if (inited_) {
    ret = OB_INIT_TWICE;
  } else if (OB_NOT_NULL(replay_buf_)
      || OB_ISNULL(buf)
      || size <= 0) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(ERROR, "invalid argument", KP(buf), K(size), K(*this));
  } else {
    replay_buf_ = buf;
    len_ = size;
    pos_ = 0;
    if (OB_FAIL(deserialize_log_block_header_())) {
      ret = OB_DESERIALIZE_ERROR;
      TRANS_LOG(WARN, "deserialize log block header error", K(ret), K(*this));
    } else {
      inited_ = true;
    }
  }
  return ret;
}

int ObTxLogBlock::init_for_replay(const char *buf, const int64_t &size, int skip_pos)
{
  int ret = OB_SUCCESS;
  if (inited_) {
    ret = OB_INIT_TWICE;
  } else if (OB_ISNULL(buf) || size <= 0) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(ERROR, "invalid argument", KP(buf), K(size), K(*this));
  } else {
    replay_buf_ = buf;
    len_ = size;
    pos_ = skip_pos;

    if (OB_FAIL(header_.deserialize(replay_buf_, len_, pos_))) {
    } else {
      inited_ = true;
    }
  }
  return ret;
}

int ObTxLogBlock::seal(const int64_t replay_hint, const ObReplayBarrierType barrier_type)
{
  int ret = OB_SUCCESS;
  log_base_header_ = logservice::ObLogBaseHeader(logservice::ObLogBaseType::TRANS_SERVICE_LOG_BASE_TYPE,
                                                 barrier_type, replay_hint);
  int64_t pos_bk = pos_;
  pos_ = 0;
  if (OB_FAIL(serialize_log_block_header_())) {
  } else {
    pos_ = pos_bk;
  }
  return ret;
}

int ObTxLogBlock::set_prev_big_segment_scn(const share::SCN prev_scn)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(big_segment_buf_)) {
    ret = OB_NOT_INIT;
    TRANS_LOG(WARN, "invalid big segment buf", K(ret), KPC(this));
  } else if (OB_FAIL(
                 big_segment_buf_->set_prev_part_id(prev_scn.get_val_for_inner_table_field()))) {
  }
  return ret;
}

int ObTxLogBlock::acquire_segment_log_buf(const ObTxLogType big_segment_log_type, ObTxBigSegmentBuf *big_segment_buf)
{
  int ret = OB_SUCCESS;
  bool need_fill_part_scn = false;
  ObTxBigSegmentBuf *tmp_segment_buf = nullptr;
  ObTxLogHeader log_type_header(ObTxLogType::TX_BIG_SEGMENT_LOG);
  if (OB_ISNULL(big_segment_buf_) && OB_NOT_NULL(big_segment_buf) && big_segment_buf->is_active()) {
    big_segment_buf_ = big_segment_buf;
  }

  if (OB_ISNULL(big_segment_buf_) || OB_ISNULL(fill_buf_.get_buf())) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid argument", K(ret), KPC(big_segment_buf), KPC(this));
  } else if (OB_ISNULL(big_segment_buf_)) {
    ret = OB_ERR_UNEXPECTED;
    TRANS_LOG(WARN, " big segment_buf", K(ret), KPC(this));
  } else if (OB_FALSE_IT(tmp_segment_buf = big_segment_buf_)) {
  } else if (OB_FAIL(reuse_for_fill())) {
  } else if (OB_FAIL(log_type_header.serialize(fill_buf_.get_buf(), len_, pos_))) {
  } else if (OB_FAIL(cb_arg_array_.push_back(ObTxCbArg(ObTxLogType::TX_BIG_SEGMENT_LOG, NULL)))) {
  } else if (OB_FAIL(cb_arg_array_.push_back(ObTxCbArg(big_segment_log_type, NULL)))) {
  } else if (OB_FAIL(tmp_segment_buf->split_one_part(fill_buf_.get_buf(), BIG_SEGMENT_SPILT_SIZE, pos_,
                                                     need_fill_part_scn))) {
  } else if (tmp_segment_buf->is_completed()) {
    // tmp_segment_buf->reset();
    // reset big_segment buf after set prev scn
    ret = OB_ITER_END;
  } else {
    big_segment_buf_ = tmp_segment_buf;
    cb_arg_array_.pop_back();
    ret = OB_EAGAIN;
  }

  return ret;
}

int ObTxLogBlock::serialize_log_block_header_()
{
  int ret = OB_SUCCESS;
  char *serialize_buf = nullptr;
  if (OB_ISNULL(fill_buf_.get_buf()) || pos_ != 0) {
    ret = OB_INVALID_ARGUMENT;
  } else {
    serialize_buf = fill_buf_.get_buf();
  }

  if (OB_FAIL(ret)) {
    // do nothing
  } else if (OB_ISNULL(serialize_buf)) {
    ret = OB_ERR_UNEXPECTED;
    TRANS_LOG(WARN, "unexpected empty serialize_buf", K(*this));
  } else if (OB_FAIL(log_base_header_.serialize(serialize_buf, len_, pos_))) {
  } else if (OB_FAIL(header_.serialize(serialize_buf, len_, pos_))) {
  }

  return ret;
}

int ObTxLogBlock::deserialize_log_block_header_()
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(replay_buf_) || pos_ != 0) {
    ret = OB_INVALID_ARGUMENT;
  } else if (OB_FAIL(log_base_header_.deserialize(replay_buf_, len_, pos_))) {
  } else if (OB_FAIL(header_.deserialize(replay_buf_, len_, pos_))) {
  }
  return ret;
}

int ObTxLogBlock::get_next_log(ObTxLogHeader &header,
                               ObTxBigSegmentBuf *big_segment_buf,
                               bool *contain_big_segment)
{
  int ret = OB_SUCCESS;
  int64_t tmp_pos = pos_;
  if (OB_NOT_NULL(contain_big_segment)) {
    *contain_big_segment = false;
  }

  if (OB_ISNULL(replay_buf_)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(ERROR, "invalid argument", K(*this));
  } else if (OB_SUCC(update_next_log_pos_())) {
    if (OB_FAIL(header.deserialize(replay_buf_, len_, pos_))) {
    } else {
      cur_log_type_ = header.get_tx_log_type();

      if (ObTxLogType::TX_BIG_SEGMENT_LOG == cur_log_type_) {
        if (OB_NOT_NULL(contain_big_segment)) {
          *contain_big_segment = true;
        }

        if (OB_ISNULL(big_segment_buf)) {
          ret = OB_LOG_ALREADY_SPLIT;
          TRANS_LOG(WARN, "the tx log entry has been split, need big_segment_buf", K(ret),
                    KPC(big_segment_buf), KPC(this));
        } else if (OB_NOT_NULL(big_segment_buf_)) {
          ret = OB_ERR_UNEXPECTED;
          TRANS_LOG(WARN, "A completed big segment need be serialized", K(ret), KPC(this),
                    K(big_segment_buf));
        } else if (big_segment_buf->is_completed()) {
          ret = OB_NO_NEED_UPDATE;
          TRANS_LOG(WARN, "collect all part of big segment", K(ret));
        } else if (OB_FAIL(big_segment_buf->collect_one_part(replay_buf_, len_, pos_))) {
          TRANS_LOG(WARN, "merge one part of big segment failed", K(ret), KPC(this));
          // rollback to the start position
          pos_ = tmp_pos;
        } else {
          if (big_segment_buf->is_completed()) {
            big_segment_buf_ = big_segment_buf;
            // deserialize log_header
            if (OB_FAIL(big_segment_buf_->deserialize_object(header))) {
            } else {
              cur_log_type_ = header.get_tx_log_type();
            }
          } else {
            TRANS_LOG(INFO, "collect one part of big segment buf, need continue", K(ret),
                      KPC(big_segment_buf), KPC(this));
            ret = OB_LOG_TOO_LARGE;
          }
        }

        if (OB_FAIL(ret)) {
          if (OB_LOG_TOO_LARGE != ret) {
            pos_ = tmp_pos;
          }
          cur_log_type_ = ObTxLogType::UNKNOWN;
        }
      }
    }
  }
  return ret;
}

int ObTxLogBlock::prepare_mutator_buf(ObTxRedoLog &redo)
{
  int ret = OB_SUCCESS;
  char *tmp_buf = get_buf();
  if (OB_ISNULL(tmp_buf)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(ERROR, "invalid argument", K(*this));
  } else if (ObTxLogType::UNKNOWN != cur_log_type_) {
    ret = OB_EAGAIN;
    TRANS_LOG(WARN, "MutatorBuf is using", K(ret), KPC(this));
  } else if (OB_FAIL(redo.set_mutator_buf(tmp_buf + pos_ + ObTxLogHeader::TX_LOG_HEADER_SIZE))) {
  } else if (OB_FAIL(
                 redo.set_mutator_size(len_ - pos_ - ObTxLogHeader::TX_LOG_HEADER_SIZE, false))) {
  } else {
    cur_log_type_ = ObTxLogType::TX_REDO_LOG;
  }
  return ret;
}

int ObTxLogBlock::finish_mutator_buf(ObTxRedoLog &redo, const int64_t &mutator_size)
{
  int ret = OB_SUCCESS;
  int64_t tmp_pos = pos_;
  char * tmp_buf = get_buf();
  ObTxLogHeader header(ObTxLogType::TX_REDO_LOG);
  if (OB_ISNULL(tmp_buf)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(ERROR, "invalid argument", K(*this));
  } else if (ObTxLogType::TX_REDO_LOG != cur_log_type_) {
    ret = OB_EAGAIN;
    TRANS_LOG(WARN, "MutatorBuf not prepare");
  } else if (0 == mutator_size) {
    cur_log_type_ = ObTxLogType::UNKNOWN;
    redo.reset_mutator_buf();
  } else if (OB_FAIL(redo.set_mutator_size(mutator_size, true))) {
  } else if (OB_FAIL(header.serialize(tmp_buf, len_, tmp_pos))) {
  } else if (OB_FAIL(redo.serialize(tmp_buf, len_, tmp_pos))) {
  } else {
    pos_ = tmp_pos;
    cur_log_type_ = ObTxLogType::UNKNOWN;
  }
  return ret;
}

int ObTxLogBlock::extend_log_buf()
{
  int ret = OB_SUCCESS;
  if (OB_FAIL(fill_buf_.extend_and_copy(pos_))) {
  } else {
    len_ = fill_buf_.get_length();
  }
  return ret;
}

int ObTxLogBlock::update_next_log_pos_()
{
  int ret = OB_SUCCESS;
  int64_t version = 0;
  int64_t body_size = 0;
  // use in DESERIALIZE_HEADER
  int64_t tmp_pos = pos_;

  if (ObTxLogType::UNKNOWN != cur_log_type_) {
    if (OB_FAIL(serialization::decode(replay_buf_, len_, tmp_pos, version))) {
    } else if (OB_FAIL(serialization::decode(replay_buf_, len_, tmp_pos, body_size))) {
    } else if (tmp_pos + body_size > len_) {
      ret = OB_SIZE_OVERFLOW;
      TRANS_LOG(WARN, "has not enough space for deserializing tx_log_body", K(body_size),
                K(tmp_pos), K(*this));
    } else {
      // skip log_body if cur_log_type_ isn't UNKNOWN
      // if deserialize_log_body success, cur_log_type_ will be UNKNOWN
      pos_ = tmp_pos + body_size;
    }
  }

  if (pos_ >= len_) {
    cur_log_type_ = ObTxLogType::UNKNOWN;
    ret = OB_ITER_END;
  }
  return ret;
}

} // namespace transaction
} // namespace oceanbase
