/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "share/rc/ob_server_runtime.h"
#include "storage/tx/ob_tx_big_segment_buf.h"

namespace oceanbase
{

namespace transaction
{

OB_SERIALIZE_MEMBER(BigSegmentPartHeader, prev_part_id_, remain_length_, part_length_);

void ObTxBigSegmentBuf::reset()
{
  if (OB_NOT_NULL(segment_buf_)) {
    share::server_free(segment_buf_);
  }
  segment_buf_ = nullptr;
  segment_buf_len_ = 0;
  segment_data_len_ = 0;
  segment_pos_ = 0;
  is_complete_ = false;
  for_serialize_ = false;
  prev_part_id_ = UINT64_MAX;
}

int ObTxBigSegmentBuf::init_for_serialize(int64_t segment_len)
{
  int ret = OB_SUCCESS;

  if (OB_FAIL(basic_init_(segment_len, true))) {
  }

  return ret;
}









int ObTxBigSegmentBuf::split_one_part(char *part_buf,
                                      const int64_t part_buf_len,
                                      int64_t &part_buf_pos,
                                      bool &need_fill_id_into_next_part)
{
  int ret = OB_SUCCESS;
  int64_t tmp_pos = 0;

  need_fill_id_into_next_part = false;

  BigSegmentPartHeader part_header;
  part_header.part_length_ = part_buf_len - part_buf_pos;
  part_header.remain_length_ = segment_data_len_ - segment_pos_;

  // const int64_t max_part_data_len = part_buf_len - part_header.get_serialize_size();
  part_header.part_length_ = part_buf_len - part_header.get_serialize_size() - part_buf_pos;

  if (OB_ISNULL(part_buf) || part_buf_len <= 0 || !for_serialize_) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid argument", K(ret), KP(part_buf), K(part_buf_len), KPC(this));
  } else if (!is_inited() || !is_active()) {
    ret = OB_NOT_INIT;
    TRANS_LOG(WARN, "big segment buf is not inited", K(ret), KPC(this));
  } else if (is_completed()) {
    ret = OB_ITER_END;
  } else {
    if (segment_pos_ == 0) {
      if (prev_part_id_ != INVALID_SEGMENT_PART_ID) {
        ret = OB_ERR_UNEXPECTED;
        TRANS_LOG(WARN, "init prev_part_id_ twice", K(ret), KPC(this));
      } else if (segment_data_len_ <= part_header.part_length_) {
        // only one part
        need_fill_id_into_next_part = false;
        part_header.part_length_ = segment_data_len_;
      } else {
        // data size  = part_header.part_length_
        need_fill_id_into_next_part = true;
      }
    } else {
      if (prev_part_id_ == INVALID_SEGMENT_PART_ID) {
        ret = OB_ERR_UNEXPECTED;
        TRANS_LOG(WARN, "invalid prev_part_id_", K(ret), KPC(this));
      // } else if (OB_FALSE_IT(need_set_prev_id = false)) {
      } else if (part_header.remain_length_ <= part_header.part_length_) {
        // the last part
        part_header.prev_part_id_ = prev_part_id_;
        part_header.part_length_ = part_header.remain_length_;
        need_fill_id_into_next_part = false;
      } else {
        // data size  = part_header.part_length_
        part_header.prev_part_id_ = prev_part_id_;
        need_fill_id_into_next_part = true;
      }
    }


    tmp_pos = part_buf_pos;
    if (OB_FAIL(ret)) {
    } else if (OB_FAIL(part_header.serialize(part_buf, part_buf_len, tmp_pos))) {
    } else if (tmp_pos + part_header.part_length_ > part_buf_len
               || segment_pos_ + part_header.part_length_ > segment_data_len_) {
      ret = OB_ERR_UNEXPECTED;
      TRANS_LOG(WARN, "unexpected part buf len", K(ret), KP(part_buf), K(part_buf_len),
                K(part_buf_pos), K(part_header), KPC(this));
    } else {
      MEMCPY(part_buf + tmp_pos, segment_buf_ + segment_pos_, part_header.part_length_);
      segment_pos_ += part_header.part_length_;
      tmp_pos += part_header.part_length_;
      part_buf_pos = tmp_pos;
      prev_part_id_ = INVALID_SEGMENT_PART_ID;

      if (segment_pos_ < segment_data_len_) {
        is_complete_ = false;
      } else if (segment_pos_ == segment_data_len_) {
        is_complete_ = true;
      } else {
        ret = OB_ERR_UNEXPECTED;
        TRANS_LOG(ERROR, "unexpected segment postition", K(ret), K(part_header), KPC(this));
      }
    }
  }
  return ret;
}

int ObTxBigSegmentBuf::collect_one_part(const char *part_buf,
                                        const int64_t part_buf_len,
                                        int64_t &part_buf_pos)
{
  int ret = OB_SUCCESS;

  int64_t tmp_pos = part_buf_pos;

  BigSegmentPartHeader part_header;

  if (OB_ISNULL(part_buf) || part_buf_len <= 0 || for_serialize_) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid argument", K(ret), KP(part_buf), K(part_buf_len), KPC(this));
  } else if (is_active() && is_completed()) {
    ret = OB_ITER_END;
  } else if (OB_FAIL(part_header.deserialize(part_buf, part_buf_len, tmp_pos))) {
  } else {
    if (OB_ISNULL(segment_buf_) || segment_data_len_ <= 0) {
      // is not inited
      if (!part_header.is_first_part()) {
        ret = OB_START_LOG_CURSOR_INVALID;
        TRANS_LOG(WARN, "We need merge from the first part", K(ret), K(part_header), KPC(this));
      } else if (OB_FAIL(basic_init_(part_header.remain_length_, false))) {
      }
    } else {
      // is inited
      if (part_header.is_first_part()) {
        ret = OB_ERR_UNEXPECTED;
        TRANS_LOG(WARN, "We can not merge from the first part without reset", K(ret),
                  K(part_header), KPC(this));
      }
    }
  }


  if (OB_FAIL(ret)) {
    // do nothing
  } else if (part_header.remain_length_ != segment_buf_len_ - segment_data_len_
             || part_header.remain_length_ > segment_buf_len_) {
    ret = OB_ERR_UNEXPECTED;
    TRANS_LOG(WARN, "invalid remain_length in replay buf", K(ret), K(part_header), KPC(this));
  } else if (segment_data_len_ + part_header.part_length_ > segment_buf_len_) {
    ret = OB_ERR_UNEXPECTED;
    TRANS_LOG(WARN, "the buf of segment is not enough", K(ret), K(part_header), KPC(this));
  } else {
    MEMCPY(segment_buf_ + segment_data_len_, part_buf + tmp_pos, part_header.part_length_);
    segment_data_len_ += part_header.part_length_;
    tmp_pos += part_header.part_length_;
    prev_part_id_ = part_header.prev_part_id_;

    if (segment_data_len_ < segment_buf_len_) {
      is_complete_ = false;
    } else if (segment_data_len_ == segment_buf_len_) {
      is_complete_ = true;
    }
  }

  if (OB_SUCC(ret)) {
    part_buf_pos = tmp_pos;
  }

  return ret;
}



bool ObTxBigSegmentBuf::is_completed() { return is_complete_; }

bool ObTxBigSegmentBuf::is_inited() { return OB_NOT_NULL(segment_buf_); }

bool ObTxBigSegmentBuf::is_active() { return is_inited() && segment_data_len_ > 0; }

int ObTxBigSegmentBuf::set_prev_part_id(const uint64_t prev_part_id)
{
  int ret = OB_SUCCESS;

  if (prev_part_id_ != INVALID_SEGMENT_PART_ID) {
    ret = OB_EAGAIN;
    TRANS_LOG(WARN, "the valid prev_part_id_ can not be rewritten", K(ret), K(prev_part_id),
              KPC(this));
  } else {
    prev_part_id_ = prev_part_id;
  }

  return ret;
}

int ObTxBigSegmentBuf::basic_init_(const int64_t segment_len, bool for_serialize)
{
  int ret = OB_SUCCESS;

  if (is_inited()) {
    ret = OB_INIT_TWICE;
    TRANS_LOG(WARN, "init segment twice", K(ret), KPC(this));
  } else if (segment_len <= 0) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid serialize size", K(ret), KPC(this), K(segment_len));
  } else if (OB_ISNULL(segment_buf_ =
                           static_cast<char *>(share::server_malloc(segment_len, "BigSegment")))) {
    ret = OB_ALLOCATE_MEMORY_FAILED;
    TRANS_LOG(WARN, "alloc memory for big segment", K(ret), KPC(this), K(segment_len));
  } else {
    segment_buf_len_ = segment_len;
    segment_data_len_ = 0;
    segment_data_len_ = 0;
    segment_pos_ = 0;
    is_complete_ = false;
    for_serialize_ = for_serialize;
  }

  return ret;
}

} // namespace transaction

} // namespace oceanbase
