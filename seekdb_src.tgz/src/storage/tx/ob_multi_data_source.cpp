/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "storage/tablet/ob_batch_create_tablet_arg.h"
#include "ob_multi_data_source.h"
#include "storage/tx/ob_tx_ctx.h"
#define NEED_MDS_REGISTER_DEFINE
#include "storage/multi_data_source/compile_utility/mds_register.h"
#undef NEED_MDS_REGISTER_DEFINE
#include "storage/allocator/ob_shared_memory_allocator_mgr.h"

namespace oceanbase
{

using namespace common;
using namespace memtable;
using namespace storage;
using namespace transaction::tablelock;

namespace transaction
{

//#####################################################
// ObMulSourceTxDataNotifier
//#####################################################

int ObMulSourceTxDataNotifier::notify_table_lock(const ObTxBufferNodeArray &array,
                                                 const ObMulSourceDataNotifyArg &arg,
                                                 ObTxCtx *part_ctx,
                                                 int64_t &total_time)
{
  int ret = OB_SUCCESS;
  ObMemtableCtx *mt_ctx = nullptr;
  ObMulSourceDataNotifyArg tmp_notify_arg = arg;
  const NotifyType notify_type = NotifyType::TX_END;
  if (OB_ISNULL(part_ctx)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid argument", KR(ret), K(part_ctx));
  } else if (OB_ISNULL(mt_ctx = part_ctx->get_memtable_ctx())) {
    ret = OB_ERR_UNEXPECTED;
    TRANS_LOG(WARN, "memtable ctx should not null", KR(ret), K(part_ctx));
  } else {
    for (int64_t i = 0; OB_SUCC(ret) && i < array.count(); ++i) {
      ObTimeGuard notify_time;
      const ObTxBufferNode &node = array.at(i);
      const char *buf = node.data_.ptr();
      const int64_t len = node.data_.length();

      tmp_notify_arg.redo_submitted_ = node.is_submitted();
      tmp_notify_arg.redo_synced_ = node.is_synced();

      if (ObTxDataSourceType::TABLE_LOCK == node.type_) {
        if (OB_FAIL(notify_table_lock(notify_type, buf, len, tmp_notify_arg, mt_ctx))) {
        }
      }
      if (notify_time.get_diff() > 1 * 1000 * 1000) {
        TRANS_LOG(INFO, "notify one data source with too much time", K(ret), K(notify_type), K(i), K(node),
                  K(arg), K(notify_time.get_diff()));
      }
      total_time += notify_time.get_diff();
    }
  }

  return ret;
}

int ObMulSourceTxDataNotifier::notify(const ObTxBufferNodeArray &array,
                                      const NotifyType notify_type,
                                      const ObMulSourceDataNotifyArg &arg,
                                      ObTxCtx *part_ctx,
                                      int64_t &total_time)
{
  int ret = OB_SUCCESS;
  const char *can_not_do_tx_end_reason = nullptr;
  bool can_do_tx_end = true;
  ObMulSourceDataNotifyArg tmp_notify_arg = arg;
  if (OB_ISNULL(part_ctx)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid argument", KR(ret), K(part_ctx));
  } else {
    for (int64_t i = 0; OB_SUCC(ret) && i < array.count(); ++i) {
      ObTimeGuard notify_time;
      const ObTxBufferNode &node = array.at(i);
      const char *buf = node.data_.ptr();
      const int64_t len = node.data_.length();

      tmp_notify_arg.redo_submitted_ = node.is_submitted();
      tmp_notify_arg.redo_synced_ = node.is_synced();

      if (i > 0) {
        const ObTxBufferNode &prev_node = array.at(i - 1);
        if (ObTxBufferNode::is_valid_register_no(prev_node.get_register_no())
            && ObTxBufferNode::is_valid_register_no(node.get_register_no())
            && prev_node.get_register_no() >= node.get_register_no()) {
          ret = OB_ERR_UNEXPECTED;
          TRANS_LOG(ERROR, "unexpected register no for the mds_node", K(ret), K(i), K(array.count()),
                    K(arg), K(node), K(prev_node));
        }
      }

      if(OB_FAIL(ret)) {
        //do nothing
      } else if (uses_builtin_mds_notifier(node.type_)) {
        switch (node.type_) {
        case ObTxDataSourceType::TABLE_LOCK: {
          ret = notify_table_lock(
              notify_type, buf, len, tmp_notify_arg, part_ctx->get_memtable_ctx());
          break;
        }
        case ObTxDataSourceType::LS_TABLE: {
          ret = notify_ls_table(notify_type, buf, len, tmp_notify_arg);
          break;
        }
        case ObTxDataSourceType::DDL_TRANS: {
          ret = notify_ddl_trans(notify_type, buf, len, tmp_notify_arg);
          break;
        }
        default: {
          ret = OB_ERR_UNEXPECTED;
          break;
        }
        }
      } else {
        mds::TLOCAL_MDS_INFO.notify_type_ = notify_type;
        mds::BufferCtx &buffer_ctx = *const_cast<mds::BufferCtx*>(node.get_buffer_ctx_node().get_ctx());
        if (arg.is_incomplete_replay_) {
          // pass incomplete replay arg
          buffer_ctx.set_incomplete_replay(arg.is_incomplete_replay_);
        }
        switch (node.type_) {
          #define NEED_GENERATE_MDS_FRAME_CODE_FOR_TRANSACTION
          #define _GENERATE_MDS_FRAME_CODE_FOR_TRANSACTION_(HELPER_CLASS, BUFFER_CTX_TYPE, ID, ENUM_NAME) \
          case ObTxDataSourceType::ENUM_NAME:\
            switch (notify_type) {\
              case NotifyType::REGISTER_SUCC:\
              {\
                if (std::is_base_of<mds::MdsCtx, BUFFER_CTX_TYPE>::value ||\
                    std::is_same<mds::MdsCtx, BUFFER_CTX_TYPE>::value) {\
                  static_cast<mds::MdsCtx&>(buffer_ctx).set_seq_no(node.get_seq_no());\
                }\
                if (!arg.for_replay_) {\
                  if (OB_FAIL(HELPER_CLASS::on_register(buf, len, buffer_ctx))) {\
                    MDS_LOG(WARN, "call user helper on_register failed", KR(ret));\
                  } else {\
                    MDS_LOG(INFO, "buffer ctx on_register", K(node), KP(&buffer_ctx), K(buffer_ctx));\
                  }\
                } else {\
                  if (OB_FAIL(HELPER_CLASS::on_replay(buf, len, arg.scn_, buffer_ctx))) {\
                    MDS_LOG(WARN, "call user helper on_replay failed", KR(ret));\
                  } else {\
                    MDS_LOG(INFO, "buffer ctx on_replay", K(node), KP(&buffer_ctx), K(buffer_ctx));\
                  }\
                }\
              }\
              break;\
              case NotifyType::ON_REDO:\
              MDS_LOG(INFO, "buffer ctx on_redo", K(node), KP(&buffer_ctx), K(buffer_ctx));\
              buffer_ctx.on_redo(arg.scn_);\
              break;\
              case NotifyType::TX_END:\
              can_do_tx_end = common::meta::MdsCheckCanDoTxEndWrapper<HELPER_CLASS>::\
                              check_can_do_tx_end(arg.willing_to_commit_,\
                                                  arg.for_replay_,\
                                                  arg.scn_,\
                                                  buf,\
                                                  len,\
                                                  *const_cast<mds::BufferCtx*>(node.get_buffer_ctx_node().get_ctx()),\
                                                  can_not_do_tx_end_reason);\
              if (!can_do_tx_end) {\
                ret = OB_EAGAIN;\
                MDS_ASSERT(OB_NOT_NULL(can_not_do_tx_end_reason));\
                MDS_LOG(INFO, "check can do tx end return false", KR(ret), K(node), K(can_not_do_tx_end_reason));\
              } else {\
                MDS_LOG(INFO, "buffer ctx before_prepare", K(node), KP(&buffer_ctx), K(buffer_ctx));\
                buffer_ctx.before_prepare();\
              }\
              break;\
              case NotifyType::ON_PREPARE:\
              MDS_LOG(INFO, "buffer ctx on_prepare", K(node), KP(&buffer_ctx), K(buffer_ctx));\
              buffer_ctx.on_prepare(arg.trans_version_);\
              break;\
              case NotifyType::ON_COMMIT:\
              MDS_LOG(INFO, "buffer ctx on_commit", K(node), KP(&buffer_ctx), K(buffer_ctx));\
              if (arg.for_replay_ && !common::meta::MdsCheckCanReplayWrapper<HELPER_CLASS>::\
                                            check_can_replay_commit(buf,\
                                                                    len,\
                                                                    arg.scn_,\
                                                                    buffer_ctx)) {\
                ret = OB_EAGAIN;\
                MDS_LOG(INFO, "check can replay commit return false", KR(ret), K(node));\
              } else {\
                buffer_ctx.on_commit(arg.trans_version_, arg.scn_);\
              }\
              break;\
              case NotifyType::ON_ABORT:\
              MDS_LOG(INFO, "buffer ctx on_abort", K(node), KP(&buffer_ctx), K(buffer_ctx));\
              buffer_ctx.on_abort(arg.scn_);\
              break;\
              default:\
              ob_abort();\
            }\
          break;
          #include "storage/multi_data_source/compile_utility/mds_register.h"
          #undef _GENERATE_MDS_FRAME_CODE_FOR_TRANSACTION_
          #undef NEED_GENERATE_MDS_FRAME_CODE_FOR_TRANSACTION
          default:
            ob_abort();
        }
        mds::TLOCAL_MDS_INFO.reset();
      }
      if (OB_FAIL(ret)) {
      }

      if (notify_time.get_diff() > 1 * 1000 * 1000) {
        TRANS_LOG(INFO, "notify one data source with too much time", K(ret), K(notify_type), K(i), K(node),
                  K(arg), K(notify_time.get_diff()));
      }

      total_time += notify_time.get_diff();
    }
  }

  return ret;
}

void ObMulSourceTxDataNotifier::ob_abort_log_cb_notify_(const NotifyType type,
                                                        int err_code,
                                                        bool for_replay)
{
  bool need_core = false;

  if (NotifyType::ON_REDO == type || NotifyType::ON_PREPARE == type || NotifyType::ON_COMMIT == type
      || NotifyType::ON_ABORT == type) {
    if (for_replay) {
      if (OB_SUCCESS != err_code && OB_SERVER_RUNTIME_OUT_OF_MEM != err_code
          && OB_ALLOCATE_MEMORY_FAILED != err_code && OB_EAGAIN != err_code) {
        need_core = true;
      }
    } else {
      if (OB_SUCCESS != err_code) {
        need_core = true;
      }
    }
  }

  if (need_core) {
    TRANS_LOG_RET(ERROR, OB_ERROR, "data source can not return error in log_cb on_success", K(type), K(err_code), K(for_replay));
    ob_usleep(1000 * 1000);
    ob_abort();

  }
}

int ObMulSourceTxDataNotifier::notify_table_lock(
    const NotifyType type,
    const char *buf,
    const int64_t len,
    const ObMulSourceDataNotifyArg &arg,
    ObMemtableCtx *mt_ctx)
{
  int ret = OB_SUCCESS;
  tablelock::ObTableLockOp lock_op;
  bool need_replay = false;
  const bool is_replay_multi_source = true;
  const bool is_committed = true;
  int64_t pos = 0;
  const int64_t curr_timestamp = ObTimeUtility::current_time();
  if (OB_ISNULL(buf) || OB_UNLIKELY(len <= 0) || OB_ISNULL(mt_ctx)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid argument", K(ret), K(buf), K(len), K(mt_ctx));
  } else if (NotifyType::TX_END != type) {
    // TABLELOCK only deal with tx_end type, but not redo/prepare/commit/abort.
  } else if (!arg.for_replay_) {
    // TABLELOCK only need deal with replay process, but not apply.
    // the replay process will produce a lock op and will be dealt at trans end.
  } else if (OB_FAIL(lock_op.deserialize(buf, len, pos))) {
  } else if (FALSE_IT(lock_op.create_timestamp_ = OB_MIN(curr_timestamp,
                                                         lock_op.create_timestamp_))) {
  } else if (OB_FAIL(mt_ctx->replay_lock(lock_op,
                                         arg.scn_))) {
  } else {
    // do nothing
  }

  ob_abort_log_cb_notify_(type, ret, arg.for_replay_);

  return ret;
}

int ObMulSourceTxDataNotifier::notify_ls_table(const NotifyType type,
                                               const char *buf, const int64_t len,
                                               const ObMulSourceDataNotifyArg &arg)
{
  int ret = OB_SUCCESS;
  ob_abort_log_cb_notify_(type, ret, arg.for_replay_);

  return ret;
}

int ObMulSourceTxDataNotifier::notify_ddl_trans(const NotifyType type,
                                                const char *buf, const int64_t len,
                                                const ObMulSourceDataNotifyArg &arg)
{
  int ret = OB_SUCCESS;

  ob_abort_log_cb_notify_(type, ret, arg.for_replay_);

  return ret;
}

//#####################################################
// ObMulSourceTxDataDump
//#####################################################
const char *
ObMulSourceTxDataDump::dump_buf(
    ObTxDataSourceType source_type,
    const char *buf,
    const int64_t len,
    ObCStringHelper &helper)
{
  int ret = OB_SUCCESS;
  const char *dump_str = "Unkown Multi Data Source";
  int64_t pos = 0;

  if (OB_ISNULL(buf) || OB_UNLIKELY(len <= 0)) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid argument", K(ret), K(buf), K(len));
  } else {
    switch (source_type) {
    case ObTxDataSourceType::TABLE_LOCK: {
      tablelock::ObTableLockOp lock_op;
      if (OB_FAIL(lock_op.deserialize(buf, len, pos))) {
      } else if (pos > len) {
        ret = OB_ERR_UNEXPECTED;
        TRANS_LOG(WARN, "deserialize error", KR(ret), K(pos), K(len));
      } else {
        dump_str = helper.convert(lock_op);
      }
      break;
    }
    case ObTxDataSourceType::LS_TABLE: {
      ret = OB_NOT_SUPPORTED;
      TRANS_LOG(WARN, "not supported in lite version", KR(ret));
      break;
    }
    case ObTxDataSourceType::CREATE_TABLET_NEW_MDS: {
      obcall::ObBatchCreateTabletArg create_arg;
      if (OB_FAIL(create_arg.deserialize(buf, len, pos))) {
      } else if (pos > len) {
        ret = OB_ERR_UNEXPECTED;
        TRANS_LOG(WARN, "deserialize error", KR(ret), K(pos), K(len));
      } else {
        dump_str = helper.convert(create_arg);
      }
      break;
    }
    case ObTxDataSourceType::DELETE_TABLET_NEW_MDS: {
      obcall::ObBatchRemoveTabletArg remove_arg;
      if (OB_FAIL(remove_arg.deserialize(buf, len, pos))) {
      } else if (pos > len) {
        ret = OB_ERR_UNEXPECTED;
        TRANS_LOG(WARN, "deserialize error", KR(ret), K(pos), K(len));
      } else {
        dump_str = helper.convert(remove_arg);
      }
      break;
    }
    case ObTxDataSourceType::UNBIND_TABLET_NEW_MDS: {
      ObBatchUnbindTabletArg modify_arg;
      if (OB_FAIL(modify_arg.deserialize(buf, len, pos))) {
      } else if (pos > len) {
        ret = OB_ERR_UNEXPECTED;
        TRANS_LOG(WARN, "deserialize error", KR(ret), K(pos), K(len));
      } else {
        dump_str = helper.convert(modify_arg);
      }
      break;
    }
    case ObTxDataSourceType::UNBIND_LOB_TABLET: {
      ObBatchUnbindLobTabletArg modify_arg;
      if (OB_FAIL(modify_arg.deserialize(buf, len, pos))) {
      } else if (pos > len) {
        ret = OB_ERR_UNEXPECTED;
        TRANS_LOG(WARN, "deserialize error", KR(ret), K(pos), K(len));
      } else {
        ObCStringHelper helper;
        dump_str = helper.convert(modify_arg);
      }
      break;
    }
    default: {
      // TRANS_LOG(ERROR, "Unkown Multi Data Source", K(source_type), KP(buf), K(len));
    }
    }
  }

  return dump_str;
}

//#####################################################
// ObRegisterMdsArg
//#####################################################
OB_SERIALIZE_MEMBER(ObRegisterMdsFlag, need_flush_redo_instantly_, mds_base_scn_);

//#####################################################
// ObMDSStr
//#####################################################

OB_SERIALIZE_MEMBER(ObMDSInnerSQLStr, mds_str_, type_, register_flag_);

ObMDSInnerSQLStr::ObMDSInnerSQLStr() { reset(); }

ObMDSInnerSQLStr::~ObMDSInnerSQLStr() {}

void ObMDSInnerSQLStr::reset()
{
  mds_str_.reset();
  type_ = ObTxDataSourceType::UNKNOWN;
  register_flag_.reset();
}

int ObMDSInnerSQLStr::set(const char *msd_buf,
                          const int64_t msd_buf_len,
                          const ObTxDataSourceType &type,
                          const ObRegisterMdsFlag &register_flag)
{
  int ret = OB_SUCCESS;
  if (OB_ISNULL(msd_buf) || 0 == msd_buf_len || ObTxDataSourceType::UNKNOWN == type) {
    ret = OB_INVALID_ARGUMENT;
    TRANS_LOG(WARN, "invalid arguments", K(ret), KP(msd_buf), K(msd_buf_len), K(type));
  } else if (!mds_str_.empty()) {
    TRANS_LOG(WARN, "MSD str is not empty", K(ret), K(*this));
  } else {
    mds_str_.assign_ptr(msd_buf, msd_buf_len);
    type_ = type;
    register_flag_ = register_flag;
  }
  return ret;
}

} // transaction

} // oceanbase
