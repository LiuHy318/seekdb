/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_STORAGE_TABLE_GUARD
#define OCEANBASE_STORAGE_OB_STORAGE_TABLE_GUARD

#include <stdint.h>
#include "share/scn.h"
#include "storage/throttle/ob_share_throttle_define.h"

namespace oceanbase
{
namespace share
{
class ObThrottleInfoGuard;
}

namespace common{
class ObTabletID;
}

namespace memtable {
class ObMemtable;
}

namespace storage
{
struct ObStoreCtx;
class ObTablet;
class ObIMemtable;
class ObRelativeTable;
class ObTableStoreIterator;

class ObStorageTableGuard
{
public:
  ObStorageTableGuard(
      ObTablet *tablet,
      ObStoreCtx &store_ctx,
      const bool need_control_mem,
      const bool for_replay = false,
      const share::SCN replay_scn = share::SCN());
  ~ObStorageTableGuard();

  ObStorageTableGuard(const ObStorageTableGuard&) = delete;
  ObStorageTableGuard &operator=(const ObStorageTableGuard&) = delete;
public:
  // refresh and get/create the memtable for write
  int refresh_and_protect_memtable_for_write(ObRelativeTable &relative_table);
  // refresh and get/create the memtable for replay
  int refresh_and_protect_memtable_for_replay();
  int get_memtable_for_replay(ObIMemtable *&memtable);

  TO_STRING_KV(KP(tablet_),
               K(need_control_mem_),
               K(for_replay_),
               K(replay_scn_),
               KP(memtable_),
               K(retry_count_),
               K(last_ts_),
               K(init_ts_));

private:
  void reset();
  void double_check_inc_write_ref(
      const uint32_t old_freeze_flag,
      const bool is_tablet_freeze,
      memtable::ObMemtable *memtable,
      bool &bool_ret);
  int check_freeze_to_inc_write_ref(memtable::ObMemtable *table, bool &bool_ret);
  int create_data_memtable_for_replay_(const common::ObTabletID &tablet_id,
                                       bool &no_need_create);
  bool need_to_refresh_table(ObTableStoreIterator &iter);
  void check_if_need_log_(bool &need_log, bool &need_log_error);
  void throttle_if_needed_();
  int double_check_get_memtable_for_replay_(const share::SCN replay_scn,
                                            bool &need_retry);

private:
  static const int64_t LOG_INTERVAL_US = 10 * 1000 * 1000;        // 10s
  static const int64_t LOG_ERROR_INTERVAL_US = 60 * 1000 * 1000;  // 1min
  static const int64_t GET_TS_INTERVAL = 10 * 1000;
  static const int64_t SLEEP_INTERVAL_PER_TIME = 20 * 1000; // 20ms

  ObTablet *tablet_;
  ObStoreCtx &store_ctx_;
  bool need_control_mem_;
  ObIMemtable *memtable_;
  int64_t retry_count_;
  int64_t last_ts_;
  // record write latency
  int64_t init_ts_;
  bool for_replay_;
  share::SCN replay_scn_;
};
} // namespace storage
} // namespace oceanbase

#endif // OCEANBASE_STORAGE_OB_STORAGE_TABLE_GUARD
