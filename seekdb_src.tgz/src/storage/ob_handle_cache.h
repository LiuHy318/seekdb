/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_HANDLE_CACHE_H_
#define OCEANBASE_STORAGE_OB_HANDLE_CACHE_H_

#include "lib/list/ob_dlist.h"
#include "lib/hash/ob_hashtable.h"


namespace oceanbase
{
namespace storage
{

template<typename Key, typename Handle>
class ObHandleCacheNode : public common::ObDLinkBase<ObHandleCacheNode<Key, Handle>>
{
public:
  ObHandleCacheNode() : bucket_idx_(-1) {}
  virtual ~ObHandleCacheNode() { reset(); }

  void reset()
  {
    ObDLinkBase<ObHandleCacheNode<Key, Handle>>::reset();
    handle_.reset();
    bucket_idx_ = -1;
  }

  Handle handle_;
  Key key_;
  int16_t bucket_idx_;
};

template<typename Key, typename Handle, int64_t N>
class ObHandleCache
{
  typedef ObHandleCacheNode<Key, Handle> CacheNode;
  typedef common::ObDList<CacheNode> LRUList;
public:
  ObHandleCache()
  {
    STATIC_ASSERT(N <= 8192, "number of bucket is larger than 8192");
    reset();
  }

  virtual ~ObHandleCache() {}

  void reset()
  {
    lru_list_.reset();
    for (int64_t i = 0; i < N; ++i) {
      nodes_[i].reset();
    }
    MEMSET(buckets_, -1, sizeof(buckets_));
    MEMSET(chain_, -1, sizeof(chain_));
    hold_size_ = 0;
  }

  int get_handle(const Key &key, Handle &handle)
  {
    int ret = common::OB_SUCCESS;
    int16_t idx = buckets_[key.hash() & MASK];
    while (-1 < idx) {
      if (nodes_[idx].key_ == key) {
        handle = nodes_[idx].handle_;
        break;
      } else {
        idx = chain_[idx];
      }
    }
    if (-1 == idx) {
      ret = common::OB_ENTRY_NOT_EXIST;
    } else {
      lru_list_.remove(&nodes_[idx]);
      lru_list_.add_first(&nodes_[idx]);
    }
    return ret;
  }

  int put_handle(const Key &key, Handle &handle)
  {
    int ret = common::OB_SUCCESS;
    CacheNode *node = lru_list_.get_size() >= N ? lru_list_.remove_last() : nodes_ + lru_list_.get_size();
    const int16_t node_idx = static_cast<int16_t>(node - nodes_);
    int16_t *idx_ptr = NULL;
    int16_t idx = 0;
    if (-1 < node->bucket_idx_) {
      idx_ptr = &buckets_[node->bucket_idx_];
      idx = buckets_[node->bucket_idx_];
      while (OB_LIKELY(-1 < idx) && (node_idx != idx)) {
        idx_ptr = &chain_[idx];
        idx = chain_[idx];
      }
      if (OB_UNLIKELY(-1 == idx)) {
        ret = common::OB_ERR_UNEXPECTED;
        lru_list_.add_last(node);
        STORAGE_LOG(WARN, "idx can not be -1, the entry must exist", K(ret), K(key), K(node->bucket_idx_));
      } else {
        *idx_ptr = chain_[idx];
        chain_[idx] = -1;
      }
    }
    if (OB_SUCC(ret)) {
      hold_size_ += handle.get_handle_size() - node->handle_.get_handle_size();
      node->reset();
      node->key_ = key;
      node->handle_ = handle;
      node->bucket_idx_ = key.hash() & MASK;
      idx_ptr = &buckets_[node->bucket_idx_];
      chain_[node_idx] = *idx_ptr;
      *idx_ptr = node_idx;
      lru_list_.add_first(node);
    }
    return ret;
  }
  OB_INLINE int64_t hold() const { return hold_size_; }
private:
  static const uint64_t BUCKET_SIZE = common::next_pow2(N * 2);
  static const uint64_t MASK = BUCKET_SIZE - 1;
  CacheNode nodes_[N];
  int16_t buckets_[BUCKET_SIZE];
  int16_t chain_[N];
  LRUList lru_list_;
  int64_t hold_size_;
};


}
}




#endif /* OCEANBASE_STORAGE_OB_HANDLE_CACHE_H_ */
