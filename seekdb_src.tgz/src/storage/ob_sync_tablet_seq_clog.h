/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OCEANBASE_STORAGE_OB_SYNC_TABLET_SEQ_CLOG_H_
#define OCEANBASE_STORAGE_OB_SYNC_TABLET_SEQ_CLOG_H_

#include "common/ob_tablet_id.h"
#include "logservice/palf/palf_callback.h"
#include "logservice/ob_append_callback.h"
#include "share/ob_tablet_autoincrement_param.h"
#include "storage/ddl/ob_ddl_clog.h"
#include "storage/multi_data_source/mds_ctx.h"
#include "storage/meta_mem/ob_tablet_handle.h"

namespace oceanbase
{
namespace storage
{

class ObSyncTabletSeqLog final
{
public:
  ObSyncTabletSeqLog() : tablet_id_(), autoinc_seq_(0) {}
  ~ObSyncTabletSeqLog() = default;
public:
  int init(const common::ObTabletID &tablet_id, const uint64_t autoinc_seq);

  bool is_valid() const { return tablet_id_.is_valid() && autoinc_seq_ >= 0; }
  common::ObTabletID get_tablet_id() const { return tablet_id_; }
  uint64_t get_autoinc_seq() const { return autoinc_seq_; }

  int serialize(char *buf, const int64_t len, int64_t &pos) const;
  int deserialize(const char *buf, const int64_t len, int64_t &pos);
  int64_t get_serialize_size() const;

  TO_STRING_KV(K_(tablet_id), K_(autoinc_seq));
private:
  common::ObTabletID tablet_id_;
  uint64_t autoinc_seq_;
};

class ObSyncTabletSeqMdsLogCb : public logservice::AppendCb
{
public:
  ObSyncTabletSeqMdsLogCb();
  virtual ~ObSyncTabletSeqMdsLogCb() = default;

  int init(const common::ObTabletID &tablet_id, const int64_t writer_id);
  virtual int on_success() override;
  virtual int on_failure() override;
  void try_release();
  inline bool is_success() const { return state_ == ObDDLClogState::STATE_SUCCESS; }
  inline bool is_failed() const { return state_ == ObDDLClogState::STATE_FAILED; }
  inline bool is_finished() const { return state_ != ObDDLClogState::STATE_INIT; }
  inline int get_ret_code() const { return ret_code_; }
  mds::MdsCtx &get_mds_ctx() { return mds_ctx_; }
  const char *get_cb_name() const override { return "SyncTabletSeqMdsLogCb"; }
private:
  ObDDLClogState state_;
  bool the_other_release_this_;
  int ret_code_;
  ObTabletHandle tablet_handle_;
  mds::MdsCtx mds_ctx_;
};

} // namespace storage
} // namespace oceanbase
#endif
