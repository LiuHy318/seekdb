/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <gtest/gtest.h>

#include "tools/ob_error/src/ob_error.h"

using namespace oceanbase::common;
namespace oceanbase {
namespace unittest {
class TestObError : public ::testing::Test {
public:
  virtual void SetUp()
  {}
  virtual void TearDown()
  {}
};

TEST_F(TestObError, test_mgr)
{
  ObErrorInfoMgr mgr;

  EXPECT_FALSE(mgr.insert_os_error(nullptr, "abc", 1));
  EXPECT_FALSE(mgr.insert_os_error("abc", nullptr, 1));
  EXPECT_FALSE(mgr.insert_mysql_error(nullptr, "abc", 1, "abc", "abc", "abc", 1));
  EXPECT_FALSE(mgr.insert_mysql_error("abc", nullptr, 1, "abc", "abc", "abc", 1));
  EXPECT_FALSE(mgr.insert_mysql_error("abc", "abc", 1, nullptr, "abc", "abc", 1));
  EXPECT_FALSE(mgr.insert_mysql_error("abc", "abc", 1, "abc", nullptr, "abc", 1));
  EXPECT_FALSE(mgr.insert_mysql_error("abc", "abc", 1, "abc", "abc", nullptr, 1));
  EXPECT_FALSE(mgr.insert_ob_error(nullptr, "abc", "abc", "abc", 1));
  EXPECT_FALSE(mgr.insert_ob_error("abc", nullptr, "abc", "abc", 1));
  EXPECT_FALSE(mgr.insert_ob_error("abc", "abc", nullptr, "abc", 1));
  EXPECT_FALSE(mgr.insert_ob_error("abc", "abc", "abc", nullptr, 1));
}

TEST_F(TestObError, test_adder)
{
#ifdef __APPLE__
  // Skip on macOS: This test accesses uninitialized error code entries which
  // causes null pointer dereference on macOS (stricter memory protection).
  GTEST_SKIP() << "Skipping test_adder on macOS due to platform-specific behavior";
#endif
  ObErrorInfoMgr mgr;
  EXPECT_TRUE(init_global_info());
  // test_add_os_info
  EXPECT_FALSE(add_os_info(-1, &mgr));
  EXPECT_FALSE(add_os_info(OS_MAX_ERROR_CODE, &mgr));

  EXPECT_TRUE(add_os_info(1, nullptr));
  EXPECT_TRUE(add_os_info(100, &mgr));
  EXPECT_TRUE(add_os_info(0, &mgr));

  // test_add_mysql_info
  EXPECT_FALSE(add_mysql_info(-1, &mgr));
  EXPECT_FALSE(add_mysql_info(OB_MAX_ERROR_CODE, &mgr));
  EXPECT_FALSE(add_mysql_info(1000, &mgr));
  EXPECT_FALSE(add_mysql_info(6300, &mgr));

  EXPECT_TRUE(add_mysql_info(1017, &mgr));

  // test_add_ob_info
  EXPECT_FALSE(add_ob_info(-1, &mgr));
  EXPECT_FALSE(add_ob_info(OB_MAX_ERROR_CODE, &mgr));
  EXPECT_FALSE(add_ob_info(1000, &mgr));
  EXPECT_FALSE(add_ob_info(6500, &mgr));

  EXPECT_TRUE(add_ob_info(4100, &mgr));
}

TEST_F(TestObError, test_parser)
{
  // test_parse_error_code
  int error_code = -1;
  parse_error_code("abc123", error_code);
  EXPECT_EQ(-1, error_code);
  parse_error_code(nullptr, error_code);
  EXPECT_EQ(-1, error_code);
  parse_error_code("9999999999999", error_code);  // overflow
  EXPECT_EQ(-1, error_code);
  parse_error_code("123", error_code);
  EXPECT_EQ(123, error_code);

  // test_parse_facility
  Fac facility = NONE;
  parse_facility("ABC", facility);
  EXPECT_EQ(NONE, facility);

  facility = NONE;
  parse_facility("OBE", facility);
  EXPECT_EQ(NONE, facility);

  facility = NONE;
  parse_facility("mY", facility);
  EXPECT_EQ(MY, facility);
}
}  // end namespace unittest
}  // end namespace oceanbase

int main(int argc, char** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
