/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OBERROR_ERROR_H
#define OBERROR_ERROR_H

#include "share/ob_errno.h"
#include "os_errno.h"
#include <iostream>
#include <cstdio>
using namespace oceanbase::common;

// code error print define
#define ERROR_PRINT(fmt, ...) printf("%s[%d]-<%s>: " #fmt, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__)

enum Fac {
  MY,   // mysql mode
  NONE
};

struct OSErrorInfo {
public:
  OSErrorInfo() : error_name_(nullptr), error_msg_(nullptr), error_code_(-1)
  {}
  virtual ~OSErrorInfo()
  {}
  void free_space()
  {
    if (nullptr != error_name_) {
      free(error_name_);
      error_name_ = nullptr;
    }
    if (nullptr != error_msg_) {
      free(error_msg_);
      error_msg_ = nullptr;
    }
  }

  char* error_name_;
  char* error_msg_;
  int error_code_;
};

struct MySQLErrorInfo {
public:
  MySQLErrorInfo()
      : error_name_(nullptr),
        error_msg_(nullptr),
        mysql_errno_(-1),
        sqlstate_(nullptr),
        cause_(nullptr),
        solution_(nullptr),
        ob_error_(-1)
  {}
  virtual ~MySQLErrorInfo()
  {}
  void free_space()
  {
    if (nullptr != error_name_) {
      free(error_name_);
      error_name_ = nullptr;
    }
    if (nullptr != error_msg_) {
      free(error_msg_);
      error_msg_ = nullptr;
    }
    if (nullptr != sqlstate_) {
      free(sqlstate_);
      sqlstate_ = nullptr;
    }
    if (nullptr != cause_) {
      free(cause_);
      cause_ = nullptr;
    }
    if (nullptr != solution_) {
      free(solution_);
      solution_ = nullptr;
    }
  }

  char* error_name_;
  char* error_msg_;
  int mysql_errno_;
  char* sqlstate_;
  char* cause_;
  char* solution_;
  int ob_error_;
};

struct OBErrorInfo {
public:
  OBErrorInfo() : error_name_(nullptr), error_msg_(nullptr), cause_(nullptr), solution_(nullptr), error_code_(-1)
  {}
  virtual ~OBErrorInfo()
  {}
  void free_space()
  {
    if (nullptr != error_name_) {
      free(error_name_);
      error_name_ = nullptr;
    }
    if (nullptr != error_msg_) {
      free(error_msg_);
      error_msg_ = nullptr;
    }
    if (nullptr != cause_) {
      free(cause_);
      cause_ = nullptr;
    }
    if (nullptr != solution_) {
      free(solution_);
      solution_ = nullptr;
    }
  }

  char* error_name_;
  char* error_msg_;
  char* cause_;
  char* solution_;
  int error_code_;
};

// The length of the second dimension, in order to solve the conflict of multiple identical error codes
constexpr int OB_MAX_SAME_ERROR_COUNT = 11;
constexpr float OB_ERROR_VERSION = 1.0;

static const char* facility_str[NONE] = {"MY"};

class ObErrorInfoMgr {
public:
  ObErrorInfoMgr();
  virtual ~ObErrorInfoMgr();

  bool insert_os_error(const char* name, const char* msg, int error_code);
  void print_os_error();
  bool is_os_error_exist()
  {
    return 0 < os_error_count_;
  }

  bool insert_mysql_error(const char* name, const char* msg, int mysql_errno, const char* sqlstate, const char* cause,
      const char* solution, int ob_error);
  void print_mysql_error();
  bool is_mysql_error_exist()
  {
    return 0 < mysql_error_count_;
  }

  bool insert_ob_error(const char* name, const char* msg, const char* cause, const char* solution, int error_code);
  void print_ob_error();
  bool is_ob_error_exist()
  {
    return 0 < ob_error_count_;
  }

private:
  int os_error_count_;
  OSErrorInfo os_error_[OS_MAX_SAME_ERROR_COUNT];
  int mysql_error_count_;
  MySQLErrorInfo mysql_error_[OB_MAX_SAME_ERROR_COUNT];
  int ob_error_count_;
  OBErrorInfo ob_error_[OB_MAX_SAME_ERROR_COUNT];
};

// mysql error code -> ob error map // Maximum number of identical error codes is OB_MAX_SAME_ERROR_COUNT
static int g_mysql_error[OB_MAX_ERROR_CODE][OB_MAX_SAME_ERROR_COUNT];
// os error code -> ob error map // Maximum number of identical error codes is OS_MAX_SAME_ERROR_COUNT
static int g_os_error[OS_MAX_ERROR_CODE][OS_MAX_SAME_ERROR_COUNT];

// adder
bool add_os_info(int error_code, ObErrorInfoMgr* mgr);
bool add_ob_info(int error_code, ObErrorInfoMgr* mgr);
bool add_mysql_info(int error_code, ObErrorInfoMgr* mgr);

// parser
void parse_error_code(const char* argv, int& error_code);
void parse_facility(const char* argv, Fac& facility);
bool parse_param(int args, char* argv[]);

// printer
bool print_error_info(Fac facility, int error_code, int argument);

// init
bool init_global_info();

#endif /* OBERROR_ERROR_H */
